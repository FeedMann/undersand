"""
vtf.py -- minimal but real reader/writer for Valve Texture Format (.vtf).

Why this exists: Alyx's phong mask is *not* a separate file. It is the ALPHA
CHANNEL of alyx_head_normal.vtf, and the phong exponent lives in the RED channel
of alyx_head_exponent.vtf. To prove that to yourself you have to actually read
the container, so here is the container.

Supported on READ :  RGBA8888, ABGR8888, RGB888, BGR888, BGRA8888, BGRX8888,
                     ARGB8888, I8, A8, IA88, RGB565, BGR565, DXT1, DXT3, DXT5
Supported on WRITE:  BGRA8888 (uncompressed -- 'alpha' is what we care about)

Format:  https://developer.valvesoftware.com/wiki/VTF
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
import numpy as np

VTF_SIGNATURE = b"VTF\0"

# ImageFormat enum (VTF_IMAGE_FORMAT)
RGBA8888 = 0
ABGR8888 = 1
RGB888 = 2
BGR888 = 3
RGB565 = 4
I8 = 5
IA88 = 6
P8 = 7
A8 = 8
RGB888_BLUESCREEN = 9
BGR888_BLUESCREEN = 10
ARGB8888 = 11
BGRA8888 = 12
DXT1 = 13
DXT3 = 14
DXT5 = 15
BGRX8888 = 16
BGR565 = 17
BGRX5551 = 18
BGRA4444 = 19
DXT1_ONEBITALPHA = 20
BGRA5551 = 21
UV88 = 22
UVWQ8888 = 23
RGBA16161616F = 24
RGBA16161616 = 25
UVLX8888 = 26
NONE = 0xFFFFFFFF

FORMAT_NAMES = {v: k for k, v in list(globals().items())
                if isinstance(v, int) and k.isupper() and not k.startswith("VTF")}


@dataclass
class VTF:
    """One frame, one mip level is enough for our purposes, but we keep them all."""
    width: int
    height: int
    fmt: int
    frames: int = 1
    mipmaps: int = 1
    flags: int = 0
    bumpmap_scale: float = 1.0
    version: tuple[int, int] = (7, 2)
    mips: list[np.ndarray] = field(default_factory=list)  # each: (h, w, 4) uint8 RGBA

    # ---- convenience -----------------------------------------------------
    @property
    def rgba(self) -> np.ndarray:
        """Largest mip as float RGBA in [0,1], shape (h, w, 4)."""
        return self.mips[0].astype(np.float32) / 255.0

    def channels(self) -> dict[str, np.ndarray]:
        r = self.rgba
        return {"r": r[..., 0], "g": r[..., 1], "b": r[..., 2], "a": r[..., 3]}

    def save_png(self, path: str, which: str = "rgb") -> None:
        from PIL import Image
        r = self.rgba
        if which == "rgb":
            img = (np.clip(r[..., :3], 0, 1) * 255).astype(np.uint8)
        elif which in ("r", "g", "b", "a"):
            idx = "rgba".index(which)
            img = (np.clip(r[..., idx], 0, 1) * 255).astype(np.uint8)
        else:
            raise ValueError(which)
        Image.fromarray(img).save(path)


# ---------------------------------------------------------------------------
# DXT decoding (all four DXT variants share the same 4x4 block model)
# ---------------------------------------------------------------------------
def _expand565(c: np.ndarray) -> np.ndarray:
    """(N,) uint16 RGB565 -> (N,3) uint8."""
    r = ((c >> 11) & 0x1F).astype(np.uint16)
    g = ((c >> 5) & 0x3F).astype(np.uint16)
    b = (c & 0x1F).astype(np.uint16)
    r = (r << 3) | (r >> 2)
    g = (g << 2) | (g >> 4)
    b = (b << 3) | (b >> 2)
    return np.stack([r, g, b], axis=-1).astype(np.uint8)


def _dxt_color_palette(c0: np.ndarray, c1: np.ndarray) -> np.ndarray:
    """(N,2) RGB565 -> (N,4,3) uint8 palettes, DXT1 rule (c0>c1 => 4-colour)."""
    p = np.zeros((c0.shape[0], 4, 3), dtype=np.int16)
    e0 = _expand565(c0).astype(np.int16)
    e1 = _expand565(c1).astype(np.int16)
    p[:, 0] = e0
    p[:, 1] = e1
    four = (c0 > c1)
    p[:, 2] = np.where(four[:, None], (2 * e0 + e1) // 3, (e0 + e1) // 2)
    p[:, 3] = np.where(four[:, None], (e0 + 2 * e1) // 3, 0)
    return p.astype(np.uint8)


def _gather_indexed(pal: np.ndarray, idx: np.ndarray) -> np.ndarray:
    """pal (N,4,C), idx (N,16) -> (N,16,C)"""
    return np.take_along_axis(pal, idx[..., None], axis=1)


def _blocks_to_image(blocks: np.ndarray, w: int, h: int) -> np.ndarray:
    """(N,16,C) in block order -> (h,w,C), cropping partial edge blocks."""
    bw, bh = (w + 3) // 4, (h + 3) // 4
    img = blocks.reshape(bh, bw, 4, 4, blocks.shape[-1])
    img = img.transpose(0, 2, 1, 3, 4).reshape(bh * 4, bw * 4, blocks.shape[-1])
    return img[:h, :w]


def _decode_dxt1(data: bytes, w: int, h: int) -> np.ndarray:
    n = (w + 3) // 4 * ((h + 3) // 4)
    b = np.frombuffer(data, np.uint8, count=n * 8).reshape(n, 8)
    c0 = (b[:, 0].astype(np.uint16) | (b[:, 1].astype(np.uint16) << 8))
    c1 = (b[:, 2].astype(np.uint16) | (b[:, 3].astype(np.uint16) << 8))
    bits = (b[:, 4:8].astype(np.uint32) @ np.array([1, 1 << 8, 1 << 16, 1 << 24], np.uint32))
    idx = np.stack([(bits >> (2 * i)) & 3 for i in range(16)], axis=-1).astype(np.intp)
    pal = _dxt_color_palette(c0, c1)
    rgba = np.concatenate([_gather_indexed(pal, idx), np.full((n, 16, 1), 255, np.uint8)], axis=-1)
    return _blocks_to_image(rgba, w, h)


def _decode_dxt3(data: bytes, w: int, h: int) -> np.ndarray:
    n = (w + 3) // 4 * ((h + 3) // 4)
    b = np.frombuffer(data, np.uint8, count=n * 16).reshape(n, 16)
    # explicit 4-bit alpha, stored first
    ab = (b[:, 0:8].astype(np.uint32) @ np.array([1, 1 << 8, 1 << 16, 1 << 24, 2**32, 2**40, 2**48, 2**56], object).astype(object))
    ab = np.array([int(x) for x in ab], dtype=object)
    a = np.stack([((ab >> (4 * i)) & 0xF) for i in range(16)], axis=-1).astype(np.uint8)
    a = (a * 17).reshape(n, 16, 1)
    c = b[:, 8:16]
    c0 = (c[:, 0].astype(np.uint16) | (c[:, 1].astype(np.uint16) << 8))
    c1 = (c[:, 2].astype(np.uint16) | (c[:, 3].astype(np.uint16) << 8))
    bits = (c[:, 4:8].astype(np.uint32) @ np.array([1, 1 << 8, 1 << 16, 1 << 24], np.uint32))
    idx = np.stack([(bits >> (2 * i)) & 3 for i in range(16)], axis=-1).astype(np.intp)
    pal = _dxt_color_palette(c0, c1)
    return _blocks_to_image(np.concatenate([_gather_indexed(pal, idx), a], axis=-1), w, h)


def _decode_dxt5(data: bytes, w: int, h: int) -> np.ndarray:
    n = (w + 3) // 4 * ((h + 3) // 4)
    b = np.frombuffer(data, np.uint8, count=n * 16).reshape(n, 16)
    a0 = b[:, 0].astype(np.int16)
    a1 = b[:, 1].astype(np.int16)
    # 48-bit, 3 bits per texel, little endian
    acc = np.zeros(n, dtype=object)
    for i in range(6):
        acc += b[:, 2 + i].astype(object) * (1 << (8 * i))
    acc = np.array([int(x) for x in acc], dtype=object)
    ai = np.stack([(acc >> (3 * i)) & 7 for i in range(16)], axis=-1).astype(np.intp)
    apal = np.zeros((n, 8), dtype=np.int16)
    apal[:, 0] = a0
    apal[:, 1] = a1
    eight = a0 > a1
    for i in range(1, 7):
        lin = ((7 - i) * a0 + i * a1) // 7
        six = ((5 - i) * a0 + i * a1) // 5
        apal[:, 1 + i] = np.where(eight, lin, six)
    a = np.take_along_axis(apal, ai, axis=1).astype(np.uint8).reshape(n, 16, 1)
    c = b[:, 8:16]
    c0 = (c[:, 0].astype(np.uint16) | (c[:, 1].astype(np.uint16) << 8))
    c1 = (c[:, 2].astype(np.uint16) | (c[:, 3].astype(np.uint16) << 8))
    bits = (c[:, 4:8].astype(np.uint32) @ np.array([1, 1 << 8, 1 << 16, 1 << 24], np.uint32))
    idx = np.stack([(bits >> (2 * i)) & 3 for i in range(16)], axis=-1).astype(np.intp)
    pal = _dxt_color_palette(c0, c1)
    return _blocks_to_image(np.concatenate([_gather_indexed(pal, idx), a], axis=-1), w, h)


def _decode_uncompressed(data: bytes, w: int, h: int, fmt: int) -> np.ndarray:
    n = w * h
    if fmt in (RGBA8888, ):
        px = np.frombuffer(data, np.uint8, count=n * 4).reshape(h, w, 4)
        return px[..., [0, 1, 2, 3]]
    if fmt == ABGR8888:
        px = np.frombuffer(data, np.uint8, count=n * 4).reshape(h, w, 4)
        return px[..., [3, 2, 1, 0]]
    if fmt == ARGB8888:
        px = np.frombuffer(data, np.uint8, count=n * 4).reshape(h, w, 4)
        return px[..., [1, 2, 3, 0]]
    if fmt in (BGRA8888, BGRX8888):
        px = np.frombuffer(data, np.uint8, count=n * 4).reshape(h, w, 4)
        out = px[..., [2, 1, 0, 3]]
        if fmt == BGRX8888:
            out = out.copy()
            out[..., 3] = 255
        return out
    if fmt == RGB888:
        px = np.frombuffer(data, np.uint8, count=n * 3).reshape(h, w, 3)
        return np.concatenate([px, np.full((h, w, 1), 255, np.uint8)], -1)
    if fmt == BGR888:
        px = np.frombuffer(data, np.uint8, count=n * 3).reshape(h, w, 3)
        return np.concatenate([px[..., ::-1], np.full((h, w, 1), 255, np.uint8)], -1)
    if fmt == I8:
        px = np.frombuffer(data, np.uint8, count=n).reshape(h, w, 1)
        return np.concatenate([np.repeat(px, 3, -1), np.full((h, w, 1), 255, np.uint8)], -1)
    if fmt == A8:
        px = np.frombuffer(data, np.uint8, count=n).reshape(h, w, 1)
        return np.concatenate([np.full((h, w, 3), 255, np.uint8), px], -1)
    if fmt == IA88:
        px = np.frombuffer(data, np.uint8, count=n * 2).reshape(h, w, 2)
        return np.concatenate([np.repeat(px[..., :1], 3, -1), px[..., 1:2]], -1)
    if fmt in (RGB565, BGR565):
        px = np.frombuffer(data, np.uint8, count=n * 2).reshape(h, w, 2).astype(np.uint16)
        v = px[..., 0] | (px[..., 1] << 8)
        if fmt == RGB565:
            rgb = _expand565(v.reshape(-1)).reshape(h, w, 3)
        else:
            rgb = _expand565(v.reshape(-1)).reshape(h, w, 3)[..., ::-1]
        return np.concatenate([rgb, np.full((h, w, 1), 255, np.uint8)], -1)
    raise NotImplementedError(f"VTF image format {fmt} ({FORMAT_NAMES.get(fmt, '?')}) not implemented")


def decode(mip_data: bytes, w: int, h: int, fmt: int) -> np.ndarray:
    if fmt == DXT1 or fmt == DXT1_ONEBITALPHA:
        return _decode_dxt1(mip_data, w, h)
    if fmt == DXT3:
        return _decode_dxt3(mip_data, w, h)
    if fmt == DXT5:
        return _decode_dxt5(mip_data, w, h)
    return _decode_uncompressed(mip_data, w, h, fmt)


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------
def read(path: str) -> VTF:
    raw = open(path, "rb").read()
    if raw[:4] != VTF_SIGNATURE:
        raise ValueError("not a VTF")
    major, minor = struct.unpack_from("<II", raw, 4)
    (header_size,) = struct.unpack_from("<I", raw, 12)
    width, height = struct.unpack_from("<HH", raw, 16)
    (flags,) = struct.unpack_from("<I", raw, 20)
    frames, first_frame = struct.unpack_from("<HH", raw, 24)
    bumpmap_scale = struct.unpack_from("<f", raw, 48)[0]
    (hi_fmt,) = struct.unpack_from("<I", raw, 52)
    (mip_count,) = struct.unpack_from("<B", raw, 56)
    (lo_fmt,) = struct.unpack_from("<I", raw, 57)
    lo_w, lo_h = struct.unpack_from("<BB", raw, 61)
    depth = 1
    if header_size >= 65:
        depth = struct.unpack_from("<H", raw, 63)[0] or 1

    off = header_size
    # low-res thumbnail (usually a 1x1 DXT1 block) comes first
    if lo_fmt != NONE and lo_w and lo_h:
        lo_size = max(8, ((lo_w + 3) // 4) * ((lo_h + 3) // 4) * 8)
        # only DXT1/DXT5 thumbnails occur in practice
        off += lo_size

    mip_count = max(1, mip_count)
    sizes = []
    for level in range(mip_count):
        mw = max(1, width >> level)
        mh = max(1, height >> level)
        if hi_fmt in (DXT1, DXT1_ONEBITALPHA, DXT3, DXT5):
            size = ((mw + 3) // 4) * ((mh + 3) // 4) * (8 if hi_fmt in (DXT1, DXT1_ONEBITALPHA) else 16)
        elif hi_fmt in (RGBA8888, ABGR8888, ARGB8888, BGRA8888, BGRX8888):
            size = mw * mh * 4
        elif hi_fmt in (RGB888, BGR888):
            size = mw * mh * 3
        elif hi_fmt in (I8, A8):
            size = mw * mh
        elif hi_fmt == IA88:
            size = mw * mh * 2
        elif hi_fmt in (RGB565, BGR565, BGRX5551, BGRA5551, BGRA4444):
            size = mw * mh * 2
        elif hi_fmt in (RGBA16161616F,):
            size = mw * mh * 8
        elif hi_fmt in (RGBA16161616,):
            size = mw * mh * 8
        else:
            raise NotImplementedError(f"cannot size format {hi_fmt}")
        sizes.append((mw, mh, size))

    # mips are stored smallest -> largest
    mips = [None] * mip_count
    for level in reversed(range(mip_count)):
        mw, mh, size = sizes[level]
        chunk = raw[off:off + size]
        off += size
        mips[level] = decode(chunk, mw, mh, hi_fmt)

    return VTF(width=width, height=height, fmt=hi_fmt, frames=frames,
               mipmaps=mip_count, flags=flags, bumpmap_scale=bumpmap_scale,
               version=(major, minor), mips=mips)


def write(path: str, rgba: np.ndarray, fmt: int = BGRA8888) -> None:
    """Write an uncompressed (or DXT1) VTF. rgba: (h,w,3|4) float in [0,1] or uint8."""
    a = np.asarray(rgba)
    if a.dtype != np.uint8:
        a = (np.clip(a, 0, 1) * 255).astype(np.uint8)
    if a.ndim == 2:
        a = np.stack([a] * 3 + [np.full_like(a, 255)], -1)
    if a.shape[-1] == 3:
        a = np.concatenate([a, np.full(a.shape[:2] + (1,), 255, np.uint8)], -1)
    h, w = a.shape[:2]

    if fmt == BGRA8888:
        px = a[..., [2, 1, 0, 3]].tobytes()
    elif fmt == RGBA8888:
        px = a.tobytes()
    else:
        raise NotImplementedError("writer only does BGRA8888/RGBA8888")

    header_size = 80
    hdr = bytearray(header_size)
    hdr[0:4] = VTF_SIGNATURE
    struct.pack_into("<II", hdr, 4, 7, 2)          # version 7.2
    struct.pack_into("<I", hdr, 12, header_size)
    struct.pack_into("<HH", hdr, 16, w, h)
    struct.pack_into("<I", hdr, 20, 0)             # flags
    struct.pack_into("<HH", hdr, 24, 1, 0)         # frames, firstFrame
    struct.pack_into("<3f", hdr, 32, 1.0, 1.0, 1.0)  # reflectivity
    struct.pack_into("<f", hdr, 48, 1.0)           # bumpmap scale
    struct.pack_into("<I", hdr, 52, fmt)
    struct.pack_into("<B", hdr, 56, 1)             # mip count
    struct.pack_into("<I", hdr, 57, DXT1)          # low-res format
    hdr[61] = 1
    hdr[62] = 1

    lowres = bytes(8)  # a 1x1 black DXT1 block
    with open(path, "wb") as f:
        f.write(bytes(hdr))
        f.write(lowres)
        f.write(px)


if __name__ == "__main__":
    import sys
    v = read(sys.argv[1])
    print(f"{sys.argv[1]}: {v.width}x{v.height} fmt={FORMAT_NAMES.get(v.fmt, v.fmt)} "
          f"mips={v.mipmaps} v{v.version[0]}.{v.version[1]} "
          f"bumpmapScale={v.bumpmap_scale}")
    for i, m in enumerate(v.mips):
        print(f"  mip{i}: {m.shape[1]}x{m.shape[0]}")
