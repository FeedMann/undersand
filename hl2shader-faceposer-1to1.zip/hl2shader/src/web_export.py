"""
web_export.py -- bake everything the browser needs into one self-contained HTML.

The point is parity: the page runs the *same* GLSL (shader.py's FRAG_SRC, with
the same combo defines substituted at runtime) against the *same* texture arrays
(textures.py output, saved as PNG data URIs) with the *same* baked ambient cube
and envmap (lightcache.py).  Nothing is retyped or re-derived for the web, so if
the page and the offline render disagree, it is a real difference.

    python3 web_export.py                # write ../live/index.html
    python3 web_export.py --check        # compile every combo/term permutation
                                         # in a real GL context and report
"""
from __future__ import annotations

import argparse, base64, io, json, os, sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault("DISPLAY", ":99")

import render
import shader as shader_mod
import terms as terms_mod
from combos import Combos, HWConfig, resolve
from scene import make_scene
from textures import synth_face_textures, synth_lightwarp
from vmt import load_material

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, "web_template.html")


# ---------------------------------------------------------------------------
def _mesh(part):
    """(P, N, UV, idx) -> interleaved [px py pz nx ny nz u v] + indices."""
    P, N, UV, idx = part
    return dict(verts=np.concatenate([P, N, UV], 1).astype(np.float32).ravel().tolist(),
                idx=idx.astype(np.uint16 if idx.max() < 65536 else np.uint32).ravel().tolist())


def _mesh_full(mesh):
    """Interleaved [p n uv t b] from a model.Mesh -- the same layout the head
    uses, so the eye spheres can be drawn by the very same vertex bindings."""
    return dict(verts=np.concatenate([mesh.positions, mesh.normals, mesh.uvs,
                                      mesh.tangents, mesh.bitangents], 1)
                    .astype(np.float32).ravel().tolist(),
                idx=mesh.indices.astype(np.uint16).ravel().tolist())


def _lightmap_uri(scene, res=192):
    """The wall lightmap render.py bakes -- the same bake_lightmap() call, the
    same grid -- shipped as a PNG.  Its range is ~[0.09, 0.42], so 8 bits lose
    nothing an eye can see (the offline path uses float32 texels)."""
    import lightcache
    grid = lightcache.bake_grid(scene, res=(26, 18, 28), bounces=3, verbose=False)
    lm, _ = lightcache.bake_lightmap(scene, grid, res=res, which="wall")
    return png_data_uri(np.asarray(lm, np.float32))   # row 0 = v 0, no flip


def b64_bytes(a: np.ndarray) -> str:
    """Raw little-endian bytes of an array, base64'd for embedding in the page.

    Used for the two payloads that are *uploaded to GL verbatim* rather than
    parsed: the lightcache probe grid (RGB16F 3D texture) and the probe centres
    (HALF_FLOAT vertex attributes).  No JSON round-trip, no precision loss.
    """
    return base64.b64encode(np.ascontiguousarray(a).tobytes()).decode("ascii")


def png_data_uri(arr: np.ndarray, flip: bool = False) -> str:
    """arr is (h, w, 3|4) float 0..1, row 0 == v 0.  `flip` only for pictures a
    human will look at; the textures must stay in the orientation GL uploads."""
    from PIL import Image
    a = np.clip(arr, 0.0, 1.0)
    if a.shape[-1] == 3:
        a = np.concatenate([a, np.ones_like(a[..., :1])], -1)
    if flip:
        a = a[::-1]
    buf = io.BytesIO()
    Image.fromarray((a * 255.0 + 0.5).astype(np.uint8)).save(buf, format="PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")


def bake_env_faces(head_cube: np.ndarray, size: int = 64):
    """The same six faces render.py builds for $envmap 'env_cubemap': the baked
    probe evaluated along every direction of each cube face."""
    import lightcache as lc
    dirs = {
        0: lambda u, v: np.stack([np.ones_like(u), -v, -u], -1),   # +X
        1: lambda u, v: np.stack([-np.ones_like(u), -v, u], -1),   # -X
        2: lambda u, v: np.stack([u, np.ones_like(u), v], -1),     # +Y
        3: lambda u, v: np.stack([u, -np.ones_like(u), -v], -1),   # -Y
        4: lambda u, v: np.stack([u, -v, np.ones_like(u)], -1),    # +Z
        5: lambda u, v: np.stack([-u, -v, -np.ones_like(u)], -1),  # -Z
    }
    lin = np.linspace(-1, 1, size, dtype=np.float32)
    U, V = np.meshgrid(lin, lin)
    out = []
    for i in range(6):
        d = dirs[i](U, V)
        d /= np.linalg.norm(d, axis=-1, keepdims=True)
        out.append(lc.ambient_light(d, head_cube).astype(np.float32))
    return out



def lightgrid_u8(grid) -> tuple[str, float]:
    """The whole probe field, quantised to 8 bits per channel and base64'd.

    The *shader* reads the RGB16F 3D texture (see lightcache.grid_to_texture);
    this second copy exists so the page can do what the engine does on the CPU
    -- resolve one ambient cube per entity (`LightcacheGetStatic`) and move an
    entity around the map -- and so the probe cloud can be coloured.  Byte
    error is at most scale/255 = 0.0065, which is 0.4% of the brightest probe
    in this map; the page prints both values so the quantisation is visible
    rather than claimed.
    """
    cube = np.asarray(grid["cube"], np.float32)          # (nx,ny,nz,6,3)
    scale = float(np.abs(cube).max()) or 1.0
    q = np.clip(cube / scale * 255.0 + 0.5, 0, 255).astype(np.uint8)
    return b64_bytes(q.reshape(-1, 18)), scale


VBMOD_PATH = os.environ.get("VBMOD", "/home/user/vbmod_ref/samples/leanna.vbmod")
VBMOD_MATERIALS = os.environ.get("VBMOD_MATERIALS", "/home/user/vbmod_ref/materials")


def build_vbmod(vmt_text: str, verbose: bool = True):
    """The model in *its own* format, with the ported shaders' material block.

    Returns None when the file is not present, so the page degrades to the
    stand-in head instead of failing to build.
    """
    if not os.path.exists(VBMOD_PATH):
        return None
    import vbmod as vbmod_mod
    import vbmod_materials as vbm_mod
    import vbmod_skin
    model = vbmod_mod.read(VBMOD_PATH)
    baked = vbmod_skin.bake(model, W=1536, verbose=False)
    mats = {f.stem: vbm_mod.load(f) for f in sorted(Path(VBMOD_MATERIALS).glob("*.vbm"))}
    mapping = {k: vbm_mod.decide(v) for k, v in mats.items()}
    materials = dict(
        files={k: v for k, v in mats.items()},
        mapping=mapping,
        fields=vbm_mod.FIELD_MAP,
        order=vbm_mod.SEARCH_ORDER_NOTE,
        custom_stub=vbm_mod.CUSTOM_GLSL_STUB,
        note=("The .vbm files below are the package's own -- read, not retyped.  The mapping is "
              "the adapter: what the ported Source pixel shader reads for each field.  There is "
              "no xana texture in the package (its own description says the mesh then draws a "
              "plain lit fallback), so the maps shipped here are generated skin, and the custom "
              "GLSL path is a stub that falls back to lit."),
    )
    section = vbmod_skin.viewer_section(model, baked, materials, vmt_text, verbose=verbose)
    if verbose:
        print(f"[web] vbmod       : {section['name']}  {section['source']['verts']} verts, "
              f"{section['source']['tris']} tris, {len(section['targets'])} flex targets, "
              f"{len(section['eyes'])} eyes, maps {len(section['maps'])}"
              f" ({sum(len(v) for v in section['maps'].values())//1024} KB of data URIs)")
    return section


def vmt_text_of(vmt_paths: dict) -> str:
    """The ported skin material's own .vmt, read off disk -- never retyped.
    It is what the VBMOD's material block is mapped *onto*."""
    p = vmt_paths.get("ep1") or next(iter(vmt_paths.values()))
    with open(p) as f:
        return f.read()


def term_needs(line: str) -> list[str]:
    """Which combos a probe line depends on -- the browser forces them on so the
    term can compile when the current material would have compiled it away."""
    needs = []
    if any(k in line for k in ("fSpec", "fFresnel", "specularLighting", "vSpecularTint", "fRim")):
        needs.append("SKIN")
    if "envMapColor" in line:
        needs.append("CUBEMAP")
    if "u_lightwarpTex" in line:
        needs.append("LIGHTWARPTEXTURE")
    return needs


# ---------------------------------------------------------------------------
def build_data(res_tex: int = 256, res_env: int = 64) -> dict:
    import textures as tex

    vmt_dir = os.path.join(HERE, "..", "material_set")
    paths, vmt_paths = tex.write_material_set(vmt_dir, res=res_tex, verbose=False)

    albedo, normal_rgba, exponent_rgba = synth_face_textures(res=res_tex)
    lightwarp = synth_lightwarp()
    albedo = np.concatenate([albedo, np.ones_like(albedo[..., :1])], -1)

    # ---- the lightcache probe, exactly as render.py bakes it ---------------
    import lightcache as lc
    scene = make_scene()
    grid = lc.bake_grid(scene, res=(26, 18, 28), bounces=3, verbose=False)
    head_cube = lc.sample_cube(grid, scene.head_pos)
    env_faces = bake_env_faces(head_cube, res_env)

    # ---- the lightgrid, as if it had just been read out of the .bsp --------
    # In the engine this array lives in LUMP_LIGHTING: the compiled map carries
    # the probe grid, and DrawModelExecute hands one 6-vector of it to the
    # shader as cAmbientCube before the model is drawn.  There is no compiled
    # map here, so the array is *shipped*: a 3D texture with six direction
    # slices per probe, half-float RGB (see lightcache.grid_to_texture()).
    lg = lc.grid_to_texture(grid)
    cubes8, cube_scale = lightgrid_u8(grid)

    # the model in the user's own format, with the ported shaders and a material
    # block the port's own VMT writer produced
    vbmod_section = build_vbmod(vmt_text_of(vmt_paths))


    probes = grid["centers"].reshape(-1, 3).astype(np.float16)          # point cloud

    # one ambient cube per entity, sampled at its origin -- the per-object path
    prop_cubes = [lc.sample_cube(grid, (b.lo + b.hi) * 0.5) for b in scene.props]

    # the eyeballs: geometry + anchors, so the model is drawn as two materials
    import model as model_mod
    eye_mesh = model_mod.build_eye_sphere()
    eye_centers, eye_forwards = model_mod.eye_anchors()
    flex_names, flex_d = model_mod.flex_deltas(model_mod.build_head(nu=96, nv=72), verbose=False)
    # 8-bit signed deltas + a per-flex scale: a .vta's deltas are small and the
    # showcase only needs the mechanism, not 24-bit geometry
    flex_scale = float(max(1e-6, float(np.abs(flex_d).max())))
    flex_q = np.clip(flex_d / flex_scale * 127.0, -127, 127).astype(np.int8)

    # ---- registers straight out of the resolver, for the real VMT ----------
    ep1 = load_material(vmt_paths["ep1"])
    c_ep1, u_ep1 = resolve(ep1, HWConfig(ps_2_b=True, use_bumpmapping=True, use_phong=True))
    c_2004, u_2004 = resolve(load_material(vmt_paths["vanilla"]), HWConfig(True, True, True))

    regs = {k: (list(v) if isinstance(v, (list, tuple)) else float(v))
            for k, v in u_ep1.items() if isinstance(v, (list, tuple))}
    regs["EnvMapFresnel_SelfIllumMask"] = [0.0, 0.0, 0.0, 0.0]
    regs["EyePos_SpecExponent"] = [0.0, 0.0, 0.0, -1.0]
    regs["ShaderControls"] = [0.0, 0.0, 0.0, 0.0]
    regs["EnvmapTint_ShadowTweaks"] = [1.0, 1.0, 1.0, 0.0]

    print(f"[web] ep1 combos  : {', '.join(c_ep1.active())}")
    print(f"[web] 2004 combos : {', '.join(c_2004.active())}")
    print(f"[web] head cube   : {np.round(head_cube[:, 0], 3)}")
    print(f"[web] lightgrid   : {lg['dims'][0]}x{lg['dims'][1]}x{lg['dims'][2]} probes"
          f" -> 3D texture {lg['dims'][0]}x{lg['dims'][1]}x{lg['dims'][2]*6} RGB16F"
          f" = {lg['bytes']/1024:.0f} KB, cube max {lg['scale']:.3f}")
    print(f"[web] prop cubes  : crate {np.round(prop_cubes[0][:, 0], 3)}  "
          f"pillar {np.round(prop_cubes[1][:, 0], 3)}")
    print(f"[web] eyes        : {np.round(eye_centers, 3).tolist()} r={model_mod.EYE_RADIUS}"
          f"  flex: {', '.join(flex_names)} (scale {flex_scale:.3f})")

    # ---- terms -------------------------------------------------------------
    terms = []
    for name, line, scale, ref, which in terms_mod.TERMS:
        if name.startswith("final result"):
            continue                     # the select has its own "final result"
        terms.append(dict(name=name, line=line, ref=ref, which=which,
                          needs=term_needs(line)))

    def preset(pid, label, note, combos, vmt, primary=False):
        """`pid` is the offline variant name, so out/<pid>.png is this preset
        rendered by render.py -- which is what makes an automated pixel diff of
        the browser against the offline picture possible."""
        return dict(id=pid, label=label, note=note, combos=combos, vmt=vmt, primary=primary)

    base_vmt = dict(**{"$phongboost": 6.0, "fresMin": 0.05, "fresMid": 0.5, "fresMax": 1.0,
                       "tint": [1.0, 1.0, 1.0], "$phongexponent": 0.0,
                       "$rimlightpower": 4.0, "$rimlightboost": 1.0,
                       "envmaptint": [1.0, 1.0, 1.0], "$envmapfresnel": 0.0})

    presets = [
        preset("ep1_phong", "Alyx — Episode One", "$phong 1 · exponent map · boost 6 · halflambert",
               {"SKIN": 1, "HALFLAMBERT": 1}, dict(base_vmt), primary=True),
        preset("ep1_lightwarp", "+ $lightwarptexture", "2 * tex1D(ramp, ndotl*0.5+0.5)",
               {"SKIN": 1, "LIGHTWARPTEXTURE": 1, "HALFLAMBERT": 1}, dict(base_vmt)),
        preset("ep1_rim", "+ $rimlight / $rimmask", "2007 branch: max(specular, rim)",
               {"SKIN": 1, "RIMLIGHT": 1, "HALFLAMBERT": 1}, dict(base_vmt)),
        preset("vanilla_2004", "HL2 2004 — no $phong", "masked cubemap instead of a light-tracking highlight",
               {"CUBEMAP": 1, "NORMALMAPALPHAENVMAPMASK": 1, "HALFLAMBERT": 1},
               dict(base_vmt, **{"envmaptint": [0.1, 0.1, 0.1]})),
        preset("phong_off", "mat_phong 0", "$phong silently becomes 0 — routed out of the skin shader",
               {"HALFLAMBERT": 1}, dict(base_vmt, **{"$phongboost": 0.0})),
    ]

    # every combo name the shader knows about, in the order they are #defined
    combo_names = [k for k in Combos.__dataclass_fields__.keys()]

    return dict(
        frag=shader_mod.FRAG_SRC,
        vert=shader_mod.VERT_SRC,
        comboNames=combo_names,
        terms=terms,
        presets=presets,
        tex=dict(base=png_data_uri(albedo),
                 bump=png_data_uri(normal_rgba),
                 expo=png_data_uri(exponent_rgba),
                 warp=png_data_uri(lightwarp)),
        env=[png_data_uri(f) for f in env_faces],
        ambientCube=[[float(x) for x in head_cube[i]] for i in range(6)],
        propCubes=[[[float(x) for x in c[i]] for i in range(6)] for c in prop_cubes],
        propNames=[b.name for b in scene.props],
        # --- the probe field, straight off the baker ------------------------
        lightgrid=dict(lo=lg["lo"], hi=lg["hi"], cell=lg["cell"], dims=lg["dims"],
                       texels=lg["n_texels"], scale=lg["scale"], rgb16f=b64_bytes(lg["bits"]),
                       cubes8=cubes8, cubeScale=cube_scale),
        vbmod=vbmod_section,
        probeCloud=dict(n=int(probes.shape[0]), xyz16=b64_bytes(probes),
                        note="probe centres, HALF_FLOAT, same voxel order as the 3D texture"),
        eyes=dict(centers=[[float(x) for x in c] for c in eye_centers],
                  forwards=[[float(x) for x in c] for c in eye_forwards],
                  radius=float(model_mod.EYE_RADIUS), mesh=_mesh_full(eye_mesh),
                  note=("the eyeballs are a second material drawn after the skin, exactly as "
                        "models/alyx/alyx_eyes.mdl is a separate $eyerefract model")),
        flex=dict(names=list(flex_names), scale=flex_scale,
                  deltas8=b64_bytes(flex_q),  nverts=int(flex_d.shape[1])),
        defaultRegs=regs,
        defaultVmt=dict(base_vmt),
        lights=[dict(name=l.name,
                     pos=[float(x) for x in l.pos],
                     color=[float(x) for x in l.color]) for l in scene.lights],
        post=dict(vs=render.POST_VS, bright=render.BRIGHT_FS, blur=render.BLUR_FS),
        world=dict(vs=render.WORLD_VS, fs=render.WORLD_FS),
        room=dict(mesh=_mesh(render.build_world(scene)[0]),
                  props=_mesh(render.build_world(scene)[1]),
                  propDraws=[[i * 36, 36] for i in range(len(scene.props))],
                  lightmap=_lightmap_uri(scene),
                  albedo=dict(mesh=[0.38, 0.40, 0.46], props=[0.45, 0.40, 0.34])),
        headPos=[0.0, 0.10, 0.0],
        headScale=0.62,
        fov=42.0,
        camEye=[float(x) for x in scene.camera_eye],
        camTarget=[float(x) for x in scene.camera_target],
        sceneBounds=dict(lo=[float(x) for x in scene.bounds_lo],
                         hi=[float(x) for x in scene.bounds_hi]),
    )


# ---------------------------------------------------------------------------
def check(data: dict):
    """Compile the generated GLSL for every preset and every term, in a real GL
    context.  This is the same source the browser compiles, so a typo in a term
    line or a combo interaction shows up here instead of in the page."""
    import glfw, moderngl
    if not glfw.init():
        raise SystemExit("glfw init failed (is Xvfb running?)")
    glfw.window_hint(glfw.VISIBLE, glfw.FALSE)
    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 3)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 3)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)
    win = glfw.create_window(64, 64, "check", None, None)
    glfw.make_context_current(win)
    ctx = moderngl.create_context()

    anchor = "    fragColor = vec4(result, 1.0);"

    def body(combos: dict, name: str) -> str:
        """Mirror of buildFragment() in the template: substitute the defines, then
        undo the ES conversion so desktop GL can compile it."""
        s = data["frag"]
        for k in data["comboNames"]:
            s = s.replace(f"__{k}__", "1" if combos.get(k) else "0")
        s = s.replace("__NUM_LIGHTS__", "2")
        if name:
            s = s.replace(anchor, name)
        s = s.replace("#version 330 core", "#version 300 es\n"
                      "precision highp float;\nprecision highp int;\n"
                      "precision highp sampler2D;\nprecision highp samplerCube;")
        return s.replace("#version 300 es\nprecision highp float;\nprecision highp int;\n"
                         "precision highp sampler2D;\nprecision highp samplerCube;",
                         "#version 330 core")

    def probe_variants():
        """The PORT_PROBE_AMBIENT permutations: one #define away from the ones
        above, but a 3D sampler and three extra uniforms, so they get compiled
        here too rather than blowing up in the page."""
        base = dict(data["presets"][0]["combos"])
        src = body(base, None).replace("#version 330 core",
                                       "#version 330 core\n#define PORT_PROBE_AMBIENT 1")
        room = render.WORLD_FS.replace("#version 330 core",
                                       "#version 330 core\n#define PORT_PROBE_AMBIENT 1")
        return [("probe/head", src, "fragment"), ("probe/room", room, "fragment"),
                ("world/off", render.WORLD_FS, "fragment"),
                ("probe/hole", src.replace("probeLobe", "probeLobe").replace(
                    "u_lightgrid", "u_lightgrid"), "fragment")]

    ok = fail = 0
    for p in data["presets"]:
        for t in [None] + data["terms"]:
            if t and t["name"] in ("envmap  ($envmap)",) and not p["combos"].get("CUBEMAP"):
                pass                       # still compiled: the term forces CUBEMAP
            combos = dict(p["combos"])
            if t:
                for n in t["needs"]:
                    combos[n] = 1
            src = body(combos, t["line"] if t else None)
            tag = f"{p['label'][:26]:28s} / {(t['name'] if t else 'final result')[:26]}"
            try:
                ctx.program(vertex_shader=data["vert"].replace(
                    "#version 330 core", "#version 330 core"), fragment_shader=src)
                ok += 1
            except Exception as e:
                fail += 1
                print(f"  FAIL {tag}")
                print("   ", str(e).strip().splitlines()[-1][:160])
    for tag, src, which in probe_variants():
        try:
            ctx.program(vertex_shader=data["vert"], fragment_shader=src)
            ok += 1
        except Exception as e:
            fail += 1
            print(f"  FAIL {tag}")
            print("   ", str(e).strip().splitlines()[-1][:160])
    print(f"[web] GLSL check: {ok} programs compiled, {fail} failed")
    glfw.terminate()
    return fail


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(HERE, "..", "live", "index.html"))
    ap.add_argument("--tex-res", type=int, default=256)
    ap.add_argument("--check", action="store_true", help="compile every permutation")
    ap.add_argument("--no-write", action="store_true")
    a = ap.parse_args()

    data = build_data(res_tex=a.tex_res)
    if a.check:
        if check(data):
            raise SystemExit("GLSL check failed")
    if a.no_write:
        return

    tpl = open(TEMPLATE, encoding="utf-8").read()
    blob = json.dumps(data, separators=(",", ":")).replace("</", "<\\/")
    page = tpl.replace("/*__DATA__*/null", blob)
    assert "/*__DATA__*/null" not in page, "template marker not found"
    assert len(page) > len(tpl), "injection produced a shorter file -- suspicious"

    dest = os.path.abspath(a.out)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    with open(dest, "w", encoding="utf-8") as f:
        f.write(page)
    print(f"[web] wrote {dest}  ({os.path.getsize(dest)/1024:.0f} KB total, "
          f"{len(blob)/1024:.0f} KB of baked data)")


if __name__ == "__main__":
    main()
