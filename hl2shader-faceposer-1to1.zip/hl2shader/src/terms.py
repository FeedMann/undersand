"""terms.py -- render each term of the skin shader on its own.

This is the picture version of what trace.py does in text: take the exact GLSL
that render.py compiles, replace only the final line with a probe of one
intermediate, and draw it.  Nothing else in the shader changes, so the colours
you see are the real values the real shader produced for that term.

Run:  DISPLAY=:99 python3 terms.py [--size 512]
"""
from __future__ import annotations
import argparse, os, sys, numpy as np, moderngl

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault("DISPLAY", ":99")

import render as R, shader as S, combos as C
from vmt import load_material
from combos import HWConfig
from PIL import Image, ImageDraw, ImageFont

ANCHOR = "    fragColor = vec4(result, 1.0);"

# (title, probe line, display scale, source reference, which material to use)
TERMS = [
    ("world-space normal", "    fragColor = vec4(worldSpaceNormal * 0.5 + 0.5, 1.0);",
     1.0, "skin_ps20b.fxc:197  mul( i.tangentSpaceTranspose, tangentSpaceNormal )", "skin"),
    ("N . L, all lights", "    fragColor = vec4(diffuseLighting / 4.0, 1.0);",
     1.0, "common_vertexlitgeneric_dx9.h  DiffuseTerm()", "skin"),
    ("$basetexture", "    fragColor = vec4(baseColor.rgb, 1.0);",
     1.0, "skin_ps20b.fxc:169  tex2D( BaseTextureSampler, ... )", "skin"),
    ("ambient cube", "    fragColor = vec4(AmbientLight(worldSpaceNormal), 1.0);",
     1.0, "common_vertexlitgeneric_dx9.h  PixelShaderAmbientLight()", "skin"),
    ("half-lambert term", """    float _nd = dot(worldSpaceNormal, normalize(g_LightPos[0].xyz - v_worldPos));
    fragColor = vec4(vec3(clamp(_nd * 0.5 + 0.5, 0.0, 1.0)), 1.0);""",
     1.0, "DiffuseTerm():  saturate( NDotL * 0.5 + 0.5 )", "skin"),
    ("lightwarped diffuse", """    float _nd = dot(worldSpaceNormal, normalize(g_LightPos[0].xyz - v_worldPos));
    fragColor = vec4(2.0 * texture(u_lightwarpTex, vec2(clamp(_nd * 0.5 + 0.5, 0.0, 1.0), 0.5)).rgb, 1.0);""",
     1.0, "DiffuseTerm():  2.0 * tex1D( lightWarpSampler, fResult )", "skin"),
    ("specular exponent /150", "    fragColor = vec4(vec3(fSpecExp / 150.0), 1.0);",
     1.0, "skin_ps20b.fxc:266  1.0 + 149.0 * vSpecExpMap.r", "skin"),
    ("PHONG MASK  (bump alpha)", "    fragColor = vec4(vec3(fSpecMask), 1.0);",
     1.0, "$phong reads the $bumpmap's alpha unless $basemapalphaphongmask", "skin"),
    ("fresnel ranges", "    fragColor = vec4(vec3(fFresnelRanges), 1.0);",
     1.0, "Fresnel( N, V, ranges )  -- ranges re-encoded in skin_dx9_helper.cpp", "skin"),
    ("specular x5", "    fragColor = vec4(specularLighting * 5.0, 1.0);",
     1.0, "specularLighting *= fSpecMask * g_SpecularBoost   ($phongboost 6)", "skin"),
    ("envmap  ($envmap)", "    fragColor = vec4(envMapColor * 8.0, 1.0);",
     1.0, "skin_ps20b.fxc:229  envMapColor = ... texCUBE( EnvmapSampler, vReflect )", "2004"),
    ("final result", "    fragColor = vec4(result / 2.6, 1.0);",
     1.0, "result = specularLighting * vSpecularTint + envMapColor + diffuseComponent", "skin"),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", type=int, default=512)
    ap.add_argument("--tex-res", type=int, default=384)
    ap.add_argument("--vmt", default="alyx_faceandhair.vmt")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    r = R.Renderer(size=args.size, tex_res=args.tex_res)
    sc = r.scene
    r.view = R.look_at(sc.camera_eye, sc.camera_target)
    r.proj = R.perspective(sc.fov_deg, 1.0, 0.05, 60.0)
    outdir = args.out or r.outdir

    # the Ep1 material with every episode-era texture switched on, so every
    # term in the list below is non-degenerate
    mat = load_material(os.path.join(r.vmt_paths["ep1"]))
    mat.values["$lightwarptexture"] = "models/lightwarps/face_lightwarp"   # so LIGHTWARPTEXTURE is live
    mat.values["$rimlight"] = 1.0
    mat.values["$rimmask"] = 1.0
    c, u = C.resolve(mat, HWConfig(True, True, True))
    print(f"[terms] ep1 combos: {', '.join(c.active())}")

    mat4 = load_material(os.path.join(r.vmt_paths["ep1"]).replace(
        "alyx_faceandhair.vmt", "alyx_faceandhair_2004.vmt"))
    c4, u4 = C.resolve(mat4, HWConfig(True, True, True))
    print(f"[terms] 2004 combos: {', '.join(c4.active())}")

    model_mat = np.eye(4, dtype=np.float32)
    model_mat[:3, :3] *= 0.62
    model_mat[:3, 3] = sc.head_pos

    srcs = {
        "skin": S.build_fragment_source(c).replace("__NUM_LIGHTS__", str(len(sc.lights))),
        "2004": S.build_fragment_source(c4).replace("__NUM_LIGHTS__", str(len(sc.lights))),
    }
    for k, v in srcs.items():
        assert ANCHOR in v, f"the final fragColor line moved -- update terms.py ({k})"
    regs = {"skin": u, "2004": u4}

    def shot(frag_line: str, which: str = "skin"):
        prog = r.ctx.program(vertex_shader=S.VERT_SRC,
                             fragment_shader=srcs[which].replace(ANCHOR, frag_line))
        r.set_model_uniforms(prog, regs[which], sc.camera_eye, len(sc.lights), model_mat)
        fbo = r.ctx.framebuffer(
            [r.ctx.texture((r.size, r.size), 4, dtype="f2")],
            depth_attachment=r.ctx.depth_texture((r.size, r.size)))
        fbo.use()
        r.ctx.enable(moderngl.DEPTH_TEST | moderngl.CULL_FACE)
        r.ctx.clear(0, 0, 0, 0)
        # Only bind the attributes this program still declares: if a probe line
        # stopped using, say, the tangent frame, the GLSL compiler drops that
        # attribute and moderngl refuses to bind it.
        cols = [("a_pos", 3, r.head.positions), ("a_normal", 3, r.head.normals),
                ("a_uv", 2, r.head.uvs), ("a_tangent", 3, r.head.tangents),
                ("a_bitangent", 3, r.head.bitangents)]
        live = [c_ for c_ in cols if c_[0] in prog]
        if len(live) != len(cols):
            inter = np.concatenate([c_[2] for c_ in live], 1).astype(np.float32)
            vbo = r.ctx.buffer(np.ascontiguousarray(inter).tobytes())
        else:
            vbo = r.head_vbo
        va = r.ctx.vertex_array(
            prog, [(vbo, " ".join(f"{c_[1]}f" for c_ in live), *[c_[0] for c_ in live])],
            index_buffer=r.head_ibo)
        va.render(moderngl.TRIANGLES, r.head.indices.size)
        a = np.frombuffer(fbo.read(components=4, dtype="f2"), np.float16).astype(np.float32)
        return a.reshape(r.size, r.size, 4)[..., :3]

    imgs = []
    for name, line, scale, ref, which in TERMS:
        lin = shot(line, which) * scale
        px = np.clip(lin, 0, 1) ** (1.0 / 2.2)   # gamma so mid-tones are visible
        imgs.append((name, ref, which, px[::-1]))
        print(f"   {name:26s} [{which:4s}] linear max = {lin.max():.4f}   {ref[:52]}")

    # lay them out
    TILE = args.size
    SC = 300
    COLS = 4
    ROWS = (len(imgs) + COLS - 1) // COLS
    PAD, GAP = 24, 12
    W = PAD * 2 + SC * COLS + GAP * (COLS - 1)
    H = PAD + 54 + ROWS * (SC + 62) + PAD
    sheet = Image.new("RGB", (W, H), (18, 19, 22))
    d = ImageDraw.Draw(sheet)
    FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
    FS = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    d.text((PAD, PAD), "Every term of skin_ps20b.fxc, rendered on its own",
           font=ImageFont.truetype(FB, 24), fill=(232, 233, 236))
    d.text((PAD, PAD + 30), "each tile is the real GLSL with only the last line replaced; "
                            "linear values, gamma 2.2 for display",
           font=ImageFont.truetype(FS, 14), fill=(150, 154, 162))
    y = PAD + 54
    import textwrap
    for i, (name, ref, which, px) in enumerate(imgs):
        cx = PAD + (i % COLS) * (SC + GAP)
        cy = y + (i // COLS) * (SC + 62)
        im = Image.fromarray((px * 255).astype(np.uint8)).resize((SC, SC), Image.LANCZOS)
        sheet.paste(im, (cx, cy))
        d.rectangle([cx, cy, cx + SC - 1, cy + SC - 1], outline=(58, 60, 66))
        tag = "" if which == "skin" else "  [2004 material]"
        d.text((cx, cy + SC + 6), name + tag, font=ImageFont.truetype(FB, 15), fill=(232, 233, 236))
        d.text((cx, cy + SC + 26), "\n".join(textwrap.wrap(ref, 52)),
               font=ImageFont.truetype(FS, 12), fill=(146, 150, 158))
    p = os.path.join(outdir, "term_breakdown.png")
    sheet.save(p)
    print("[terms] wrote", p, sheet.size)


if __name__ == "__main__":
    main()
