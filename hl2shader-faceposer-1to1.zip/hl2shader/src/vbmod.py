#!/usr/bin/env python3
"""VBMOD4 (+ optional VBFLX1 trailer) reader -- the format in the user's own
FacePoser package, read here so the ported Source shaders can render *that*
format instead of a stand-in head.

Layout is taken from the package's own sources, not guessed:

    docs/VBMOD_FACEFLEX.md          byte tables for VBMOD4 and the VBFLX1 trailer
    src/vb/vb_model.cpp             ModelHeaderDisk / JointDisk / MeshDisk /
                                    VertexDisk + static_asserts on every size
    tools/faceflex_vbmod.py         the FaceFlex import/export bridge
    src/vb/vb_model.h               Joint / Mesh / Vertex / FaceFlexDelta

VBMOD4 is packed, little-endian, in this order (sizes are the asserted ones):

    ModelHeaderDisk   60   magic "VBMOD4\\0\\0", version 4, endian 0x01020304,
                           skeletonHash u64, presentationYawOffset f32,
                           jointCount, meshCount, vertexCount, indexCount,
                           hitGroupCount, hitboxCount, attachmentCount, ikChainCount
    JointDisk        164   name[64], parent i16, reserved u16, bindPose[12] f32,
                           inverseBind[12] f32                      (model-space 3x4)
    MeshDisk         144   name[64], material[64],
                           firstVertex, vertexCount, firstIndex, indexCount
    VertexDisk        44   position[3] f32, texcoord[2] f32,
                           joints[4] u16, weights[4] f32
    indices       4 each   u32
    HitGroupDisk      40, HitboxDisk, AttachmentDisk, IkChainDisk
    -- optional, straight after the IK chains --
    VBFLX1 header     36   magic "VBFLX1\\0\\0", version 1, headerSize 36,
                           payloadSize, normalCount, targetCount, deltaCount,
                           metadataBytes
    base normals   12 each position for every vertex, in vertex order
    target       164 each  name[64], pairName[64], descriptorIndex i32,
                           pairIndex i32, targetCurve[4] f32, firstDelta u32,
                           deltaCount u32, vertexAnimType u8, reserved[3]
    delta         44 each  meshIndex u16, reserved u16, vertex u32,
                           sourceVertexIndex u32, positionDelta[3] f32,
                           normalDelta[3] f32, speed u8, side u8,
                           vertexAnimType u8, flags u8, wrinkleRaw i16,
                           reserved u16
    metadata     N bytes   UTF-8 JSON (controllers, rules, visemes, presets)

The deltas are *sparse*: a target touches only the vertices it moves, which is
the same idea as Source's .vta, and is what makes it cheap to ship all 45 of
leanna.vbmod's targets into a browser.
"""
from __future__ import annotations

import json
import struct
from pathlib import Path

import numpy as np

VBMOD_MAGIC = b"VBMOD4\x00\x00"
VBFLX_MAGIC = b"VBFLX1\x00\x00"
ENDIAN = 0x01020304
VBMOD_VERSION = 4

HEADER = struct.Struct("<8sIIQf8I")          # 60 bytes  (src/vb/vb_model.cpp)
JOINT = struct.Struct("<64shH12f12f")        # 164
MESH = struct.Struct("<64s64s4I")            # 144
VERTEX = struct.Struct("<3f2f4H4f")          # 44
# sizes from src/vb/vb_model.cpp's *Disk structs:
#   HitGroupDisk    1+3+32+4                      = 40
#   HitboxDisk      32+2+1+1+12+16+12+4           = 80
#   AttachmentDisk  32+2+2+12+16                  = 64
#   IkChainDisk     32+2+2+2+2+12+12+4+4+4        = 76
# Only their sizes matter here -- this reader keeps the tables it renders and
# steps over the rest exactly as the C++ reader does.
HITGROUP = struct.Struct("<4B32sf")          # 40
HITBOX = struct.Struct("<32sBB3f4f3fI")      # 80
ATTACH = struct.Struct("<32sHH3f4f")         # 64
IKCHAIN = struct.Struct("<32s4H3f3fff")      # 76
VBFLX_HEADER = struct.Struct("<8s7I")        # 36
VBFLX_TARGET = struct.Struct("<64s64sii4fIIB3x")   # 164
VBFLX_DELTA = struct.Struct("<HHII6f4BhH")   # 44


def _s(raw: bytes) -> str:
    return raw.split(b"\x00", 1)[0].decode("utf-8", "replace")


def read(path) -> dict:
    """Parse a .vbmod file into numpy arrays + plain dicts."""
    raw = Path(path).read_bytes()
    if len(raw) < HEADER.size:
        raise ValueError("file is shorter than the VBMOD4 header")
    (magic, version, endian, skeleton_hash, yaw, n_joint, n_mesh, n_vert,
     n_index, n_hg, n_hb, n_att, n_ik) = HEADER.unpack_from(raw, 0)
    if magic != VBMOD_MAGIC:
        raise ValueError(f"not a VBMOD4 file (magic {magic!r})")
    if version != VBMOD_VERSION:
        raise ValueError(f"unsupported VBMOD version {version}")
    if endian != ENDIAN:
        raise ValueError("byte-order marker mismatch")

    off = HEADER.size
    joints = []
    for _ in range(n_joint):
        row = JOINT.unpack_from(raw, off); off += JOINT.size
        name, parent = row[0], row[1]
        bind, inv = row[3:15], row[15:27]
        joints.append(dict(name=_s(name), parent=parent,
                           bind=np.array(bind, np.float32).reshape(3, 4),
                           inverse=np.array(inv, np.float32).reshape(3, 4)))
    meshes = []
    for _ in range(n_mesh):
        name, material, fv, vc, fi, ic = MESH.unpack_from(raw, off); off += MESH.size
        meshes.append(dict(name=_s(name), material=_s(material),
                           first_vertex=fv, vertex_count=vc,
                           first_index=fi, index_count=ic))
    verts = np.empty((n_vert, 3), np.float32)
    uvs = np.empty((n_vert, 2), np.float32)
    joints4 = np.empty((n_vert, 4), np.uint16)
    weights4 = np.empty((n_vert, 4), np.float32)
    for i in range(n_vert):
        p0, p1, p2, u0, u1, j0, j1, j2, j3, w0, w1, w2, w3 = VERTEX.unpack_from(raw, off)
        off += VERTEX.size
        verts[i] = (p0, p1, p2)
        uvs[i] = (u0, u1)
        joints4[i] = (j0, j1, j2, j3)
        weights4[i] = (w0, w1, w2, w3)
    indices = np.frombuffer(raw, np.uint32, n_index, off).astype(np.uint32); off += 4 * n_index
    off += n_hg * HITGROUP.size + n_hb * HITBOX.size + n_att * ATTACH.size + n_ik * IKCHAIN.size

    out = dict(path=str(path), version=version, skeleton_hash=skeleton_hash,
               presentation_yaw=float(yaw), joints=joints, meshes=meshes,
               positions=verts, uvs=uvs, joints4=joints4, weights=weights4,
               indices=indices, bytes=len(raw),
               normals=None, targets=[], deltas=[], metadata=None,
               faceflex_bytes=0)

    # ---- optional VBFLX1 trailer ------------------------------------------
    if off + VBFLX_HEADER.size <= len(raw):
        magic2, ver, hsize, payload, n_norm, n_targ, n_delta, n_meta = VBFLX_HEADER.unpack_from(raw, off)
        if magic2 == VBFLX_MAGIC and ver == 1:
            start = off + hsize
            end = start + payload
            if end > len(raw):
                raise ValueError("VBFLX1 payload runs past the end of the file")
            p = start
            if n_norm:
                assert n_norm == n_vert
                out["normals"] = np.frombuffer(raw, np.float32, 3 * n_norm, p).reshape(-1, 3).copy()
                p += 12 * n_norm
            for _ in range(n_targ):
                (name, pair, desc, pair_i, c0, c1, c2, c3,
                 first, count, vat) = VBFLX_TARGET.unpack_from(raw, p)
                p += VBFLX_TARGET.size
                out["targets"].append(dict(name=_s(name), pair=_s(pair),
                                           descriptor=desc, pair_index=pair_i,
                                           curve=[c0, c1, c2, c3],
                                           first_delta=first, delta_count=count,
                                           vertex_anim_type=vat))
            for _ in range(n_delta):
                (mi, _r, v, sv, dx, dy, dz, nx, ny, nz, speed, side, vat, flags,
                 wrinkle, _r2) = VBFLX_DELTA.unpack_from(raw, p)
                p += VBFLX_DELTA.size
                out["deltas"].append((mi, v, (dx, dy, dz), (nx, ny, nz), wrinkle))
            if n_meta:
                out["metadata"] = json.loads(raw[p:p + n_meta].decode("utf-8"))
            out["faceflex_bytes"] = payload
    return out


def summary(m: dict) -> str:
    u = m["uvs"]
    lines = [
        f"VBMOD4      {m['bytes']/1024:.0f} KB   {m['version']}   skeleton hash {m['skeleton_hash']:016x}",
        f"joints      {len(m['joints'])}   root {m['joints'][0]['name'] if m['joints'] else '-'}",
        f"vertices    {len(m['positions'])}   indices {len(m['indices'])}   tris {len(m['indices'])//3}",
        f"uv          u [{u[:,0].min():.3f},{u[:,0].max():.3f}]  v [{u[:,1].min():.3f},{u[:,1].max():.3f}]",
        f"normals     {'yes, from VBFLX1' if m['normals'] is not None else 'no'}",
        f"face flex   {len(m['targets'])} targets, {len(m['deltas'])} sparse deltas, "
        f"{m['faceflex_bytes']/1024:.0f} KB trailer",
        "meshes      " + ", ".join(
            f"{x['name'].split('_')[-1]} ({x['vertex_count']}v/{x['index_count']//3}t -> {x['material']})"
            for x in m["meshes"]),
    ]
    if m["targets"]:
        biggest = max(m["targets"], key=lambda t: t["delta_count"])
        lines.append(f"            biggest target: {biggest['name']} ({biggest['delta_count']} deltas)")
        lines.append("            names: " + " ".join(t["name"] for t in m["targets"][:12]) + " ...")
    if m["metadata"]:
        keys = list(m["metadata"].keys())
        lines.append(f"metadata    {len(keys)} keys: {', '.join(keys[:8])}")
    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    for f in sys.argv[1:]:
        mdl = read(f)
        print(f"== {f}")
        print(summary(mdl))
