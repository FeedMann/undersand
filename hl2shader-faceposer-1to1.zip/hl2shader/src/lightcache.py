"""
lightcache.py -- baking probes, i.e. "porting the lightcaches".

Source lights models from three places (this is the whole point of the
"episodic shader tree" having three diffuses):
  1..N  local dynamic lights  -> per-pixel in the model shader
  the   ambient cube          -> a baked directional probe (Valve's replacement
                                 for a flat ambient term; SIGGRAPH 2006)
        (optionally) a lightmap -> static world lighting, sampled on models too

This module bakes all of it from one voxel grid so the numbers agree:

  direct pass   : per-voxel visibility + attenuation for each light
  projection    : incoming radiance is projected onto the six axis directions
                  -> the AMBIENT CUBE, exactly the data AmbientLight() consumes
  also computed : L1 spherical-harmonic coefficients for the same voxels, so you
                  can see the difference between "original light probes" (SH)
                  and Valve's ambient cubes, as in the 2006 course slides
  bounces       : a diffusion approximation (neighbour averaging), NOT Valve's
                  radiosity solver -- it is here so bounce light exists at all
  lightmaps     : 2D irradiance for the floor and back wall, what the world
                  geometry in the demo is actually lit by

Saved as lightcache.json (human readable: what the model shader consumes) plus
lightcache.npz (the full grid, for visualisation).
"""
from __future__ import annotations

import json
import os

import numpy as np

from scene import Scene, visible, make_scene

# cAmbientCube index order, read straight off PixelShaderAmbientLight() in
# common_vertexlitgeneric_dx9.h:
#     linearColor = isPositive.x * cAmbientCube[0] + isNegative.x * cAmbientCube[1]
#                 + isPositive.y * cAmbientCube[2] + isNegative.y * cAmbientCube[3]
#                 + isPositive.z * cAmbientCube[4] + isNegative.z * cAmbientCube[5];
# so  [0]=+x [1]=-x [2]=+y [3]=-y [4]=+z [5]=-z , and in general
#     index = 2*axis + (component < 0)
AXIS_ORDER = np.array([[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]], np.float32)
AXES = AXIS_ORDER
CUBE_AXIS = {i: AXIS_ORDER[i] for i in range(6)}


def _sh_l1_basis(d: np.ndarray) -> np.ndarray:
    """Return the 4 basis values (Y00..) for unit directions."""
    y00 = 0.282095
    y1 = 0.488603
    return np.stack([np.full(d.shape[:-1], y00), y1 * d[..., 1], y1 * d[..., 2], y1 * d[..., 0]], -1)


def bake_grid(scene: Scene, res=(28, 20, 30), bounces: int = 3, verbose: bool = True):
    nx, ny, nz = res
    lo, hi = scene.bounds_lo, scene.bounds_hi
    xs = np.linspace(lo[0], hi[0], nx)
    ys = np.linspace(lo[1], hi[1], ny)
    zs = np.linspace(lo[2], hi[2], nz)
    X, Y, Z = np.meshgrid(xs, ys, zs, indexing="ij")
    centers = np.stack([X, Y, Z], -1).astype(np.float32)          # (nx,ny,nz,3)

    n_lights = len(scene.lights)
    cube = np.zeros(centers.shape[:3] + (6, 3), np.float32)
    sh = np.zeros(centers.shape[:3] + (4, 3), np.float32)
    radiance_dirs = np.zeros(centers.shape[:3] + (n_lights, 3), np.float32)   # for the bounces

    # ---------------- direct pass -----------------------------------------
    for li, light in enumerate(scene.lights):
        d = light.pos[None, None, None, :] - centers
        dist2 = np.sum(d * d, -1)
        dist = np.sqrt(np.maximum(dist2, 1e-9))
        L = d / dist[..., None]
        atten = 1.0 / (1.0 + 0.06 * dist2)

        # occlusion: march each voxel toward the light against the props
        flat = centers.reshape(-1, 3)
        Lf = L.reshape(-1, 3)
        vis = np.ones(flat.shape[0], np.float32)
        for b in scene.props:
            inv = 1.0 / np.where(np.abs(Lf) < 1e-9, 1e-9, Lf)
            t1 = (b.lo - flat) * inv
            t2 = (b.hi - flat) * inv
            tmin = np.maximum.reduce(np.minimum(t1, t2), -1)
            tmax = np.minimum.reduce(np.maximum(t1, t2), -1)
            hit = (tmax >= np.maximum(tmin, 1e-3)) & (tmax > 1e-3) & (tmin < dist.reshape(-1))
            vis *= (~hit).astype(np.float32)
        vis = vis.reshape(centers.shape[:3])

        contribution = (light.color[None, None, None, :] * (atten * vis)[..., None]).astype(np.float32)
        radiance_dirs[..., li, :] = contribution

        # project onto the six axis bins: weight by how well each axis faces the light
        for ci in range(6):
            w = np.clip(np.sum(L * CUBE_AXIS[ci][None, None, None, :], -1), 0.0, 1.0)
            cube[..., ci, :] += contribution * (w ** 2)[..., None]

        b = _sh_l1_basis(L)
        sh += b[..., None] * contribution[..., None, :]

    # energy scale: the ambient cube is consumed as sum(n_i^2 * cube_i) and then
    # multiplied by albedo, so fold in a 1/pi-ish factor to keep levels sane
    cube *= 0.55
    sh[..., 0, :] *= 0.55
    sh[..., 1:, :] *= 0.55

    # ---------------- bounces (diffusion approximation) -------------------
    scalar = cube.sum(-1).mean(-1)                     # (nx,ny,nz) rough radiance
    for it in range(bounces):
        padded = np.pad(scalar, 1, mode="edge")
        avg = (padded[2:, 1:-1, 1:-1] + padded[:-2, 1:-1, 1:-1] +
               padded[1:-1, 2:, 1:-1] + padded[1:-1, :-2, 1:-1] +
               padded[1:-1, 1:-1, 2:] + padded[1:-1, 1:-1, :-2]) / 6.0
        scalar = scalar * 0.55 + avg * 0.45
        # re-distribute: the average neighbour level, tinted by the wall albedo,
        # gets added back into every bin (cheap isotropic bounce)
        tint = np.array([scene.wall_albedo, scene.wall_albedo, scene.wall_albedo * 0.95], np.float32)
        cube += (scalar * 0.16 / 6.0)[..., None, None] * tint[None, None, None, None, :]

    if verbose:
        print(f"[lightcache] baked {nx}x{ny}x{nz} = {nx*ny*nz} probes, "
              f"{len(scene.lights)} lights, {bounces} bounce passes")

    return dict(cube=cube, sh=sh, scalar=scalar, centers=centers,
                bounds=(lo, hi), res=(nx, ny, nz))


def sample_cube(grid, pos, radius_voxels=1):
    lo, hi = grid["bounds"]
    nx, ny, nz = grid["res"]
    idx = ((np.asarray(pos) - lo) / (hi - lo) * (np.array([nx, ny, nz]) - 1)).round().astype(int)
    idx = np.clip(idx, radius_voxels, np.array([nx, ny, nz]) - 1 - radius_voxels)
    x, y, z = idx
    r = radius_voxels
    block = grid["cube"][x - r:x + r + 1, y - r:y + r + 1, z - r:z + r + 1]
    return block.reshape(-1, 6, 3).mean(0)


def sample_cube_batch(grid, positions, radius_voxels=1):
    """sample_cube() for many points at once -- the per-object path of the
    forward renderer (one probe per model, not per vertex)."""
    pos = np.asarray(positions, np.float32).reshape(-1, 3)
    return np.stack([sample_cube(grid, p, radius_voxels) for p in pos])


def grid_to_texture(grid, pad_dirs: bool = False):
    """The probe grid packed as it would ship to the GPU.

    A real map gets its probe field from the .bsp's LUMP_LIGHTING cells and the
    engine un-packs one 6x3 ambient cube per entity when it draws it.  There is
    no .bsp here, so the identical array the baker produced is shipped instead:
    a 3D texture, one probe per (x,y,z) texel, six direction slices per z.

        texture size  (nx, ny, nz*6)      slice z = probe_z*6 + cube_index
        probe (i,j,k) centre is texel   ((i+0.5)/nx, (j+0.5)/ny, (k*6+d+0.5)/(nz*6))

    Because the six directions of one probe are *adjacent* slices, GL_LINEAR
    filtering interpolates along x, y and z but *not* between directions -- the
    3-tap AmbientLight() in the shader does the direction select instead.  The
    result is trilinear interpolation between the probes for each of the six
    lobes, which is what "a model inherits the map's baked lighting" means.

    Storage is RGB16F (half float): 11 bits of mantissa is far more than the
    cube needs, and a u8 payload would band the ambient term visibly.
    """
    cube = np.asarray(grid["cube"], np.float32)          # (nx,ny,nz,6,3)
    lo, hi = grid["bounds"]
    nx, ny, nz = grid["res"]
    cell = (np.asarray(hi, np.float32) - np.asarray(lo, np.float32)) / (np.array([nx, ny, nz]) - 1)

    # (nz, 6, ny, nx, 3) -> memory order x fastest, then y, then direction, then z
    tex = np.transpose(cube, (2, 3, 1, 0, 4))            # (nz,6,ny,nx,3)
    tex = np.ascontiguousarray(tex, np.float32).ravel()
    if pad_dirs:
        tex = tex.reshape(nz * 6, ny, nx, 3)
    half = tex.astype(np.float16)
    return dict(lo=[float(v) for v in lo], hi=[float(v) for v in hi],
                cell=[float(v) for v in cell], dims=[int(nx), int(ny), int(nz)],
                n_texels=int(nx * ny * nz * 6), bytes=int(half.nbytes),
                bits=half.view(np.uint16).tobytes(),
                scale=float(np.abs(cube).max()))


def sample_sh(grid, pos, radius_voxels=1):
    lo, hi = grid["bounds"]
    nx, ny, nz = grid["res"]
    idx = ((np.asarray(pos) - lo) / (hi - lo) * (np.array([nx, ny, nz]) - 1)).round().astype(int)
    idx = np.clip(idx, radius_voxels, np.array([nx, ny, nz]) - 1 - radius_voxels)
    x, y, z = idx
    r = radius_voxels
    block = grid["sh"][x - r:x + r + 1, y - r:y + r + 1, z - r:z + r + 1]
    return block.reshape(-1, 4, 3).mean(0)


def eval_sh(sh_coeffs, direction):
    """L1 SH reconstruction, i.e. what the older probe scheme would return."""
    d = np.asarray(direction, np.float32)
    d = d / max(np.linalg.norm(d), 1e-9)
    b = _sh_l1_basis(d.reshape(1, 3))[0]
    return (b[:, None] * np.asarray(sh_coeffs)).sum(0)


def ambient_light(normal, cube):
    """Verbatim port of AmbientLight() -- kept here so the baker can be checked
    against the shader without running a GPU.

    Handles the scalar case (one normal, one 6x3 cube) and the vector case
    (a whole grid of normals, broadcasting a single cube), because the envmap
    bake evaluates one probe along every direction of six cube faces.
    """
    n = np.asarray(normal, np.float32)
    cube = np.asarray(cube, np.float32)
    n2 = n * n
    if n.ndim == 1:                       # the scalar case, as the shader sees it
        out = np.zeros(3, np.float32)
        out += n2[0] * cube[0 if n[0] >= 0 else 1]
        out += n2[1] * cube[2 if n[1] >= 0 else 3]
        out += n2[2] * cube[4 if n[2] >= 0 else 5]
        return out
    # vector case: selector = 2*axis + (component < 0), pushed to the last axis
    sel = np.stack([np.where(n[..., 0] >= 0, 0, 1),
                    np.where(n[..., 1] >= 0, 2, 3),
                    np.where(n[..., 2] >= 0, 4, 5)], -1)          # (..., 3)
    return np.sum(n2[..., None] * cube[sel], -2)                   # (..., 3)


# ---------------------------------------------------------------------------
# lightmaps for the world geometry
# ---------------------------------------------------------------------------
def bake_lightmap(scene: Scene, grid, res: int = 192, which: str = "floor",
                  bounces: int = 1):
    """Direct + one bounce term, per texel, for a flat quad."""
    us = np.linspace(0.0, 1.0, res)
    a, b = np.meshgrid(us, us, indexing="xy")
    if which == "floor":
        x = scene.bounds_lo[0] + (scene.bounds_hi[0] - scene.bounds_lo[0]) * a
        z = scene.bounds_lo[2] + (scene.bounds_hi[2] - scene.bounds_lo[2]) * b
        y = np.full_like(x, scene.floor_y)
        normal = np.array([0, 1, 0], np.float32)
        albedo = scene.floor_albedo
    else:  # back wall (+z), normal points -z into the room
        x = scene.bounds_lo[0] + (scene.bounds_hi[0] - scene.bounds_lo[0]) * a
        y = scene.bounds_lo[1] + (scene.bounds_hi[1] - scene.bounds_lo[1]) * b
        z = np.full_like(x, scene.wall_z - 0.001)
        normal = np.array([0, 0, -1], np.float32)
        albedo = scene.wall_albedo

    pts = np.stack([x, y, z], -1).reshape(-1, 3)
    out = np.zeros((pts.shape[0], 3), np.float32)
    for light in scene.lights:
        d = light.pos[None, :] - pts
        dist2 = np.sum(d * d, -1)
        dist = np.sqrt(np.maximum(dist2, 1e-9))
        L = d / dist[:, None]
        atten = 1.0 / (1.0 + 0.06 * dist2)
        ndotl = np.clip(L @ normal, 0.0, 1.0)
        # shadow test per texel (vectorised)
        visov = np.ones(pts.shape[0], np.float32)
        for box in scene.props:
            inv = 1.0 / np.where(np.abs(L) < 1e-9, 1e-9, L)
            t1 = (box.lo - pts) * inv
            t2 = (box.hi - pts) * inv
            tmin = np.maximum.reduce(np.minimum(t1, t2), -1)
            tmax = np.minimum.reduce(np.maximum(t1, t2), -1)
            hit = (tmax >= np.maximum(tmin, 1e-3)) & (tmax > 1e-3) & (tmin < dist - 1e-3)
            visov *= (~hit).astype(np.float32)
        out += visov[:, None] * (atten * ndotl)[:, None] * light.color[None, :]

    # bounce term pulled from the baked grid (the probes already contain it)
    lo, hi = grid["bounds"]
    nx, ny, nz = grid["res"]
    idx = np.clip(((pts - lo) / (hi - lo) * (np.array([nx, ny, nz]) - 1)).round().astype(int), 0,
                  np.array([nx, ny, nz]) - 1)
    cube_here = grid["cube"][idx[:, 0], idx[:, 1], idx[:, 2]]        # (N,6,3)
    bounce = np.stack([ambient_light(normal, c) for c in cube_here[::97]])   # subsample for speed
    # evaluate for all points cheaply: n is constant per lightmap
    n = normal
    n2 = n * n
    sel = [0 if n[0] < 0 else 1, 2 if n[1] < 0 else 3, 4 if n[2] < 0 else 5]
    weights = np.array([n2[0], n2[1], n2[2]], np.float32)
    bounce_all = sum(weights[i] * cube_here[:, sel[i], :] for i in range(3))

    out = out * albedo + bounce_all * albedo * 0.55
    return out.reshape(res, res, 3), pts.reshape(res, res, 3)


# ---------------------------------------------------------------------------
def save(scene: Scene, grid, outdir: str, head_cube=None, head_sh=None, verbose=True):
    os.makedirs(outdir, exist_ok=True)
    lo, hi = grid["bounds"]
    data = {
        "format": "hl2-probe-cache/1",
        "note": ("ambient cube index order follows PixelShaderAmbientLight() in "
                 "common_vertexlitgeneric_dx9.h -- isPositive.x * cAmbientCube[0] + "
                 "isNegative.x * cAmbientCube[1] + ... -- i.e. "
                 "[0]=+x [1]=-x [2]=+y [3]=-y [4]=+z [5]=-z"),
        "grid": {"bounds_lo": lo.tolist(), "bounds_hi": hi.tolist(),
                 "res": list(grid["res"])},
        "lights": [{"name": l.name, "pos": l.pos.tolist(), "color": l.color.tolist()}
                   for l in scene.lights],
        "head_probe": {"pos": scene.head_pos.tolist(),
                       "ambient_cube": (head_cube if head_cube is not None
                                        else sample_cube(grid, scene.head_pos)).tolist(),
                       "sh_l1": (head_sh if head_sh is not None
                                 else sample_sh(grid, scene.head_pos)).tolist()},
    }
    with open(os.path.join(outdir, "lightcache.json"), "w") as f:
        json.dump(data, f, indent=2)

    np.savez_compressed(os.path.join(outdir, "lightcache.npz"),
                        cube=grid["cube"].astype(np.float32),
                        sh=grid["sh"].astype(np.float32),
                        scalar=grid["scalar"].astype(np.float32),
                        centers=grid["centers"].astype(np.float32),
                        bounds=np.stack([lo, hi]))
    if verbose:
        cube = np.array(data["head_probe"]["ambient_cube"])
        print("[lightcache] head probe ambient cube (index: colour):")
        names = ["-x", "+x", "-y", "+y", "-z", "+z"]
        for i in range(6):
            print(f"    [{i}] {names[i]:>3s}  {cube[i]}")
        sh = np.array(data["head_probe"]["sh_l1"])
        print("[lightcache] head probe SH L1 (first band colour):", sh[0].round(3))
    return data


def visualize(scene, grid, outdir: str, verbose=True):
    """Save PNGs of what was baked, so the cache is inspectable rather than magic.

    Two sheets, both labelled:

      probe_slice_ambientcube.png  the six cAmbientCube lobes on a horizontal
                                   slice through the room at eye height, in the
                                   engine's own index order (+x -x +y -y +z -z),
                                   two rows of three
      probe_slice_scalar.png       total baked radiance on the same slice, with
                                   the light positions and the head marked
    """
    from PIL import Image, ImageDraw, ImageFont
    os.makedirs(outdir, exist_ok=True)
    paths = {}
    FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
    FS = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    names = ["+x", "-x", "+y", "-y", "+z", "-z"]
    ny = grid["cube"].shape[1]
    y_mid = int(ny * 0.45)
    T = 200
    PAD, GAP, LBL = 20, 10, 26

    def gamma(a):
        a = a / max(float(a.max()), 1e-6)
        return np.clip(a ** 0.45, 0, 1)

    # ---- the six lobes, 2 rows of 3, in the shader's index order ----------
    W = PAD * 2 + T * 3 + GAP * 2
    H = PAD + 46 + 2 * (T + LBL) + GAP + PAD
    sheet = Image.new("RGB", (W, H), (18, 19, 22))
    d = ImageDraw.Draw(sheet)
    d.text((PAD, PAD), "cAmbientCube: the six baked lobes (horizontal slice, eye height)",
           font=ImageFont.truetype(FB, 17), fill=(232, 233, 236))
    d.text((PAD, PAD + 22),
           "index order is the shader's:  isPositive.x*cube[0] + isNegative.x*cube[1] + ...",
           font=ImageFont.truetype(FS, 13), fill=(146, 150, 158))
    for i in range(6):
        t = gamma(grid["cube"][:, y_mid, :, i, :])          # (nx, nz, 3)
        im = Image.fromarray((np.transpose(t, (1, 0, 2)) * 255).astype(np.uint8))
        im = im.resize((T, T), Image.LANCZOS)
        cx = PAD + (i % 3) * (T + GAP)
        cy = PAD + 46 + (i // 3) * (T + LBL)
        sheet.paste(im, (cx, cy))
        d.rectangle([cx, cy, cx + T - 1, cy + T - 1], outline=(58, 60, 66))
        d.text((cx, cy + T + 5), f"[{i}]  {names[i]}", font=ImageFont.truetype(FB, 14),
               fill=(232, 233, 236))
    p = os.path.join(outdir, "probe_slice_ambientcube.png")
    sheet.save(p)
    paths["probe_slice_ambientcube"] = p

    # ---- total baked radiance, with the lights marked ---------------------
    slab = gamma(grid["scalar"][:, y_mid, :])
    S = 420
    W2 = PAD * 2 + S
    H2 = PAD + 46 + S + PAD
    sheet2 = Image.new("RGB", (W2, H2), (18, 19, 22))
    d2 = ImageDraw.Draw(sheet2)
    d2.text((PAD, PAD), "baked radiance on the same slice", font=ImageFont.truetype(FB, 17),
            fill=(232, 233, 236))
    d2.text((PAD, PAD + 22), "warm key + cool fill, with one bounce-brightened wall",
            font=ImageFont.truetype(FS, 13), fill=(146, 150, 158))
    rgb = np.stack([slab, slab * 0.94, slab * 0.88], -1)
    im2 = Image.fromarray((np.transpose(rgb, (1, 0, 2)) * 255).astype(np.uint8)).resize((S, S), Image.LANCZOS)
    # project the light positions and the head onto the slab
    lo, hi = scene.bounds_lo, scene.bounds_hi
    def to_px(p):
        u = (p[0] - lo[0]) / (hi[0] - lo[0])
        v = (p[2] - lo[2]) / (hi[2] - lo[2])
        return PAD + u * S, PAD + 46 + (1.0 - v) * S
    for l in scene.lights:
        x, y = to_px(l.pos)
        d2.ellipse([x - 5, y - 5, x + 5, y + 5], outline=(255, 230, 120), width=2)
        d2.text((x + 8, y - 7), l.name, font=ImageFont.truetype(FS, 12), fill=(255, 230, 120))
    x, y = to_px(scene.head_pos)
    d2.ellipse([x - 3, y - 3, x + 3, y + 3], fill=(120, 220, 255))
    d2.text((x + 8, y + 2), "head probe", font=ImageFont.truetype(FS, 12), fill=(120, 220, 255))
    sheet2.paste(im2, (PAD, PAD + 46))
    d2.rectangle([PAD, PAD + 46, PAD + S - 1, PAD + 46 + S - 1], outline=(58, 60, 66))
    p2 = os.path.join(outdir, "probe_slice_scalar.png")
    sheet2.save(p2)
    paths["probe_slice_scalar"] = p2

    if verbose:
        print(f"[lightcache] viz: {', '.join(paths.values())}")
    return paths


if __name__ == "__main__":
    # Standalone use: bake the scene's probe grid and draw the slices, so the
    # lighting solution can be inspected without opening a GL context at all.
    import argparse
    import time
    ap = argparse.ArgumentParser(description="bake + visualise the lightcache")
    ap.add_argument("--out", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out"))
    ap.add_argument("--res", type=int, default=26, help="grid resolution along x")
    ap.add_argument("--no-save", action="store_true")
    a = ap.parse_args()
    outdir = os.path.abspath(a.out)
    os.makedirs(outdir, exist_ok=True)

    from scene import make_scene
    sc = make_scene()
    t0 = time.time()
    g = bake_grid(sc, res=(a.res, int(a.res * 0.7), int(a.res * 1.1)), bounces=3)
    print(f"[lightcache] baked in {time.time()-t0:.2f}s "
          f"({g['cube'].shape[0]}x{g['cube'].shape[1]}x{g['cube'].shape[2]} probes)")
    cube = sample_cube(g, sc.head_pos)
    names = ["+x", "-x", "+y", "-y", "+z", "-z"]
    print(f"[lightcache] probe at the head {np.round(sc.head_pos,2)}:")
    for i in range(6):
        print(f"    [{i}] {names[i]}  {np.round(cube[i],4)}")
    if not a.no_save:
        save(sc, g, outdir, head_cube=cube, head_sh=sample_sh(g, sc.head_pos))
        visualize(sc, g, outdir)
