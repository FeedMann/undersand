"""
render.py -- run the ported shader under Xvfb and prove it works three ways:

  1. GPU forward pass        (the pretty picture, HDR + bloom + tonemap)
  2. CPU shader on a G-buffer (same math in numpy, diffed against the GPU)
  3. per-pixel verbose trace  (every intermediate term printed for one pixel)

and a set of material variants so you can see what each VMT line buys you:

  vanilla_2004   $envmap masked cubemap, no $phong      <- Half-Life 2, 2004
  ep1_phong      $phong 1 + exponent map + boost 6      <- Episode One
  ep1_lightwarp  the same + $lightwarptexture           <- Episode-era addition
  ep1_rim        the same + $rimlight/$rimmask          <- 2007 shader branch
  phong_off      the Ep1 material with mat_phong 0      <- the silent degrade

Usage:
    DISPLAY=:99 python3 render.py --out ../out --size 900
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import glfw
import moderngl

import combos as combos_mod
import lightcache
import model
import shader as shader_mod
import vtf as vtf_mod
from combos import HWConfig
from scene import make_scene
from textures import write_material_set


# ---------------------------------------------------------------------------
# math helpers (no external deps)
# ---------------------------------------------------------------------------
def perspective(fovy_deg, aspect, near, far):
    f = 1.0 / np.tan(np.radians(fovy_deg) / 2.0)
    m = np.zeros((4, 4), np.float32)
    m[0, 0] = f / aspect
    m[1, 1] = f
    m[2, 2] = (far + near) / (near - far)
    m[2, 3] = (2 * far * near) / (near - far)
    m[3, 2] = -1.0
    return m


def look_at(eye, target, up=(0, 1, 0)):
    eye = np.asarray(eye, np.float32); target = np.asarray(target, np.float32)
    up = np.asarray(up, np.float32)
    f = target - eye; f /= np.linalg.norm(f)
    s = np.cross(f, up); s /= np.linalg.norm(s)
    u = np.cross(s, f)
    m = np.eye(4, dtype=np.float32)
    m[0, :3] = s; m[1, :3] = u; m[2, :3] = -f
    m[0, 3] = -np.dot(s, eye); m[1, 3] = -np.dot(u, eye); m[2, 3] = np.dot(f, eye)
    return m


def as_mat4(m):
    return np.ascontiguousarray(m.T.astype(np.float32))


# ---------------------------------------------------------------------------
# world shaders (LightmappedGeneric-style quad, plus a simple prop shader)
# ---------------------------------------------------------------------------
WORLD_VS = r"""
#version 330 core
layout(location=0) in vec3 a_pos;
layout(location=1) in vec3 a_normal;
layout(location=2) in vec2 a_uv;
uniform mat4 u_model, u_view, u_proj;
uniform mat3 u_normalMat;
out vec3 v_worldPos; out vec3 v_normal; out vec2 v_uv;
void main(){
    vec4 wp = u_model * vec4(a_pos,1.0);
    v_worldPos = wp.xyz;
    v_normal = normalize(u_normalMat * a_normal);
    v_uv = a_uv;
    gl_Position = u_proj * u_view * wp;
}
"""

WORLD_FS = r"""
#version 330 core
in vec3 v_worldPos; in vec3 v_normal; in vec2 v_uv;
out vec4 fragColor;
uniform sampler2D u_lightmap;
uniform vec3 u_albedo;
uniform float u_useLightmap;      // 1 for the mapped quads, 0 for props
uniform vec3 u_ambientCube[6];
#if defined(PORT_PROBE_AMBIENT)
uniform sampler3D u_lightgrid;    // the baked probe field
uniform vec3 u_gridLo, u_gridCell, u_gridDims;
#endif

#if defined(PORT_PROBE_AMBIENT)
// One lobe of the probe field at a world position, with the z axis interpolated
// by hand.
//
// The grid ships as a 3D texture of (nx, ny, nz*6) whose z axis walks
// probe -> lobe -> probe -> lobe:  slice z = probe_z*6 + cube_index.  Hardware
// trilinear filtering would therefore blend *lobes* together wherever the probe
// coordinate is fractional on z -- sampling at (g.z*6 + lobe) mixes this lobe
// with the next one.  So the sampler is pinned to two exact texel rows and the
// two probes are mixed here instead; x and y still filter in hardware, where
// the neighbours really are neighbours.
vec3 probeLobe(vec3 p, float lobe){
    vec3 g = (p - u_gridLo) / u_gridCell;
    float zc = clamp(g.z, 0.0, u_gridDims.z - 1.0);
    float z0 = floor(zc);
    float z1 = min(z0 + 1.0, u_gridDims.z - 1.0);
    float fz = zc - z0;
    vec2 uv = (g.xy + 0.5) / u_gridDims.xy;
    float sz = u_gridDims.z * 6.0;
    vec3 a = texture(u_lightgrid, vec3(uv, (z0*6.0 + lobe + 0.5) / sz)).rgb;
    vec3 b = texture(u_lightgrid, vec3(uv, (z1*6.0 + lobe + 0.5) / sz)).rgb;
    return mix(a, b, fz);
}

#endif

vec3 AmbientLight(vec3 n){
    vec3 n2 = n*n;
    // cAmbientCube is stored [+x -x +y -y +z -z]  (PixelShaderAmbientLight)
#if defined(PORT_PROBE_AMBIENT)
    // PORT EXTENSION: the same six-lobe lookup, taken per *fragment* out of the
    // map's probe texture instead of out of one per-entity cAmbientCube.  The
    // floor/wall case is interesting because the lightmap already stores the
    // same bake -- this makes the two comparable in the same frame.
    // slice order is [+x -x +y -y +z -z]: a negative component picks the odd one
    vec3 c0 = probeLobe(v_worldPos, n.x<0.0?1.0:0.0);
    vec3 c1 = probeLobe(v_worldPos, n.y<0.0?3.0:2.0);
    vec3 c2 = probeLobe(v_worldPos, n.z<0.0?5.0:4.0);
    return n2.x*c0 + n2.y*c1 + n2.z*c2;
#else
    return n2.x*u_ambientCube[n.x<0.0?1:0] + n2.y*u_ambientCube[n.y<0.0?3:2] + n2.z*u_ambientCube[n.z<0.0?5:4];
#endif
}

void main(){
    vec3 albedo = u_albedo;
    // a little procedural panel detail so the lightmap is readable
    float grid = smoothstep(0.0, 0.02, min(fract(v_uv.x*8.0), fract(v_uv.y*8.0)));
    albedo *= 0.86 + 0.14*grid;
    vec3 lmap = texture(u_lightmap, v_uv).rgb;
    vec3 lit = mix(AmbientLight(v_normal), lmap, u_useLightmap);
    fragColor = vec4(albedo * lit, 1.0);
}
"""

POST_VS = r"""
#version 330 core
layout(location=0) in vec2 a_pos;
out vec2 v_uv;
void main(){ v_uv = a_pos*0.5+0.5; gl_Position = vec4(a_pos,0.0,1.0); }
"""

BRIGHT_FS = r"""
#version 330 core
in vec2 v_uv; out vec4 fragColor;
uniform sampler2D u_src; uniform float u_threshold;
void main(){
    vec3 c = texture(u_src, v_uv).rgb;
    float l = dot(c, vec3(0.2126,0.7152,0.0722));
    fragColor = vec4(c * max(0.0, l - u_threshold) / max(l, 1e-4), 1.0);
}
"""

BLUR_FS = r"""
#version 330 core
in vec2 v_uv; out vec4 fragColor;
uniform sampler2D u_src; uniform vec2 u_dir;   // texel-sized direction
void main(){
    float w[5] = float[](0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216);
    vec3 sum = texture(u_src, v_uv).rgb * w[0];
    for (int i=1;i<5;i++){
        sum += texture(u_src, v_uv + u_dir*float(i)).rgb * w[i];
        sum += texture(u_src, v_uv - u_dir*float(i)).rgb * w[i];
    }
    fragColor = vec4(sum, 1.0);
}
"""

COMBINE_FS = r"""
#version 330 core
in vec2 v_uv; out vec4 fragColor;
uniform sampler2D u_scene, u_bloom;
uniform float u_exposure, u_bloomAmount;
// Valve's HDR path tone-maps; we use a simple filmic-ish curve so $phongboost 6
// visibly blooms the way it does in Episode One
vec3 tonemap(vec3 x){ return x / (1.0 + x); }
void main(){
    vec3 c = texture(u_scene, v_uv).rgb * u_exposure;
    c += texture(u_bloom, v_uv).rgb * u_bloomAmount;
    c = tonemap(c);
    c = pow(max(c, 0.0), vec3(1.0/2.2));
    fragColor = vec4(c, 1.0);
}
"""

GBUF_FS = r"""
#version 330 core
in vec3 v_worldPos; in vec3 v_worldNormal; in vec2 v_uv;
in mat3 v_tangentSpaceTranspose;
layout(location=0) out vec4 o_pos;
layout(location=1) out vec4 o_normal;
layout(location=2) out vec4 o_tangent;
layout(location=3) out vec4 o_bitangent;
layout(location=4) out vec4 o_uv;
void main(){
    o_pos = vec4(v_worldPos, 1.0);
    o_normal = vec4(normalize(v_worldNormal), 1.0);
    o_tangent = vec4(v_tangentSpaceTranspose[0], 1.0);
    o_bitangent = vec4(v_tangentSpaceTranspose[1], 1.0);
    o_uv = vec4(v_uv, 0.0, 1.0);
}
"""


# ---------------------------------------------------------------------------
# environment cubemap for the 2004 cubemap-specular variant
# ---------------------------------------------------------------------------
def make_env_cube(size=64):
    """A stand-in for env_cubemap: a cool room with a warm window blob."""
    faces = []
    dirs = {
        0: lambda u, v: np.stack([np.ones_like(u), -v, -u], -1),   # +X
        1: lambda u, v: np.stack([-np.ones_like(u), -v, u], -1),   # -X
        2: lambda u, v: np.stack([u, np.ones_like(u), v], -1),     # +Y
        3: lambda u, v: np.stack([u, -np.ones_like(u), -v], -1),   # -Y
        4: lambda u, v: np.stack([u, -v, np.ones_like(u)], -1),    # +Z
        5: lambda u, v: np.stack([-u, -v, -np.ones_like(u)], -1),  # -Z
    }
    lin = np.linspace(-1, 1, size, dtype=np.float32)
    U, V = np.meshgrid(lin, lin)
    for i in range(6):
        d = dirs[i](U, V)
        d /= np.linalg.norm(d, axis=-1, keepdims=True)
        up = np.clip(d[..., 1] * 0.5 + 0.5, 0, 1)[..., None]
        col = np.array([0.10, 0.12, 0.16])[None, None, :] * (0.4 + 0.8 * up)
        col += np.array([0.05, 0.06, 0.09])[None, None, :]
        # a window: bright warm rectangle toward -x/+z
        wmask = ((d[..., 0] < -0.35) & (d[..., 2] > 0.25) & (d[..., 1] > -0.25) & (d[..., 1] < 0.45))
        col = np.where(wmask[..., None], col + np.array([1.6, 1.25, 0.85])[None, None, :], col)
        # floor glow
        fmask = d[..., 1] < -0.6
        col = np.where(fmask[..., None], col + np.array([0.12, 0.09, 0.06])[None, None, :], col)
        faces.append(np.clip(col, 0, None))
    return faces


# ---------------------------------------------------------------------------
# variant definitions -- each is just a VMT plus a config tweak
# ---------------------------------------------------------------------------
VARIANTS = [
    ("vanilla_2004", "alyx_faceandhair_2004.vmt", dict(use_phong=False), "HL2 2004: masked cubemap, no $phong"),
    ("ep1_phong", "alyx_faceandhair.vmt", dict(use_phong=True), "Episode One: $phong + exponent map + boost 6"),
    ("ep1_lightwarp", "alyx_faceandhair_lightwarp.vmt", dict(use_phong=True), "Episode-era: + $lightwarptexture"),
    ("ep1_rim", "alyx_faceandhair_rim.vmt", dict(use_phong=True), "2007 branch: + $rimlight/$rimmask"),
    ("phong_off", "alyx_faceandhair.vmt", dict(use_phong=False, force_off=True), "Ep1 material with mat_phong 0"),
]


def build_world(scene):
    """The room: floor + three walls (one lightmapped draw) and the two props.

    Returns (world(P,N,UV,idx), props(P,N,UV,idx)).  Kept at module level so
    web_export.py can bake the identical geometry for the browser.
    """
    lo, hi = scene.bounds_lo, scene.bounds_hi

    def quad(p0, p1, p2, p3, normal):
        P = np.array([p0, p1, p2, p3], np.float32)
        N = np.tile(normal, (4, 1)).astype(np.float32)
        UV = np.array([[0, 0], [1, 0], [1, 1], [0, 1]], np.float32)
        T = np.tile(np.array([1, 0, 0], np.float32), (4, 1))
        B = np.tile(np.array([0, 0, 1], np.float32), (4, 1))
        idx = np.array([[0, 1, 2], [0, 2, 3]], np.uint32)
        return P, N, UV, T, B, idx

    parts = []
    # NOTE: winding must be CCW when seen from the side the normal points to,
    # or GL_CULL_FACE eats the face.
    parts.append(quad([lo[0], scene.floor_y, lo[2]], [lo[0], scene.floor_y, hi[2]],
                      [hi[0], scene.floor_y, hi[2]], [hi[0], scene.floor_y, lo[2]],
                      [0, 1, 0]))                                   # floor
    parts.append(quad([hi[0], lo[1], scene.wall_z], [lo[0], lo[1], scene.wall_z],
                      [lo[0], hi[1], scene.wall_z], [hi[0], hi[1], scene.wall_z],
                      [0, 0, -1]))                                  # back wall
    parts.append(quad([lo[0], lo[1], scene.wall_z], [lo[0], lo[1], lo[2]],
                      [lo[0], hi[1], lo[2]], [lo[0], hi[1], scene.wall_z],
                      [1, 0, 0]))                                   # left wall
    parts.append(quad([hi[0], lo[1], lo[2]], [hi[0], lo[1], scene.wall_z],
                      [hi[0], hi[1], scene.wall_z], [hi[0], hi[1], lo[2]],
                      [-1, 0, 0]))                                  # right wall
    P = np.concatenate([p[0] for p in parts])
    N = np.concatenate([p[1] for p in parts])
    UV = np.concatenate([p[2] for p in parts])
    idx, base = [], 0
    for p in parts:
        idx.append(p[5] + base); base += 4
    world = (P, N, UV, np.concatenate(idx))

    bp, bn, bu, bi, off = [], [], [], [], 0
    for box in scene.props:
        v, f = Renderer._box(box.lo, box.hi)
        bp.append(v[:8]); bn.append(np.tile([0, 1, 0.0], (8, 1)))
        bu.append(np.tile([[0, 0], [1, 0], [1, 1], [0, 1]], (2, 1)))
        bi.append(f + off); off += 8
    props = (np.concatenate(bp), np.concatenate(bn), np.concatenate(bu),
             np.concatenate(bi).astype(np.uint32))
    return world, props


class Renderer:
    def __init__(self, size=900, tex_res=512, scene=None):
        self.size = size
        self.tex_res = tex_res
        self.scene = scene or make_scene()
        self.log = []
        self._init_gl()
        here = os.path.dirname(os.path.abspath(__file__))
        self.outdir = os.path.abspath(os.path.join(here, "..", "out"))
        os.makedirs(self.outdir, exist_ok=True)
        # the lightcache goes first: the CUBEMAP path needs the baked probe
        # before the envmap cubemap can be built from it (env_cubemap in a real
        # map is baked by the same radiosity pass as the ambient cube)
        self._init_lightcache()
        self._init_assets()
        self._init_geometry()

    def say(self, msg):
        print(msg)
        self.log.append(msg)

    # ---- gl ---------------------------------------------------------------
    def _init_gl(self):
        if not glfw.init():
            raise RuntimeError("glfw init failed (is DISPLAY set / Xvfb running?)")
        glfw.window_hint(glfw.VISIBLE, glfw.FALSE)
        glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 3)
        glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 3)
        glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)
        self.window = glfw.create_window(self.size, self.size, "hl2 shader port", None, None)
        if not self.window:
            raise RuntimeError("could not create GL context under DISPLAY=%s" % os.environ.get("DISPLAY"))
        glfw.make_context_current(self.window)
        self.ctx = moderngl.create_context()
        self.say(f"[gl] {self.ctx.info['GL_VERSION']} | {self.ctx.info['GL_RENDERER']} "
                 f"| display {os.environ.get('DISPLAY')}")

    # ---- assets -----------------------------------------------------------
    def _init_assets(self):
        here = os.path.dirname(os.path.abspath(__file__))
        self.outdir = os.path.abspath(os.path.join(here, "..", "out"))
        self.moddir = os.path.abspath(os.path.join(here, "..", "material_set"))
        os.makedirs(self.outdir, exist_ok=True)
        paths, vmt_paths = write_material_set(self.moddir, res=self.tex_res, verbose=False)
        self.asset_paths, self.vmt_paths = paths, vmt_paths

        # --- prove the VTF container round-trips (to 8-bit quantisation) ----
        from textures import synth_face_textures, synth_lightwarp
        albedo, normal_rgba, exponent_rgba = synth_face_textures(res=self.tex_res)
        # $basetexture has an implicit opaque alpha channel; the envmap and
        # $basemapalphaphongmask paths read it, so give it one on both sides
        albedo = np.concatenate([albedo, np.ones_like(albedo[..., :1])], -1)
        for name, arr, path in (("albedo", albedo, paths["albedo"]),
                                ("normal+mask", normal_rgba, paths["normal"]),
                                ("exponent", exponent_rgba, paths["exponent"])):
            back = vtf_mod.read(path).rgba
            d = float(np.abs(back[..., :arr.shape[2]] - arr).max())
            self.say(f"[vtf ] round-trip {name:12s} -> {os.path.basename(path)}  max abs diff = {d:.4f}"
                     + ("  (exact)" if d == 0 else ""))
            assert d < 0.01, "VTF writer/reader mismatch"

        self.tex = {
            "base": albedo,
            "normal": normal_rgba,
            "exponent": exponent_rgba,
            "lightwarp": synth_lightwarp(),
        }
        # GPU copies
        self.gpu_tex = {}
        for k, arr in self.tex.items():
            a = np.ascontiguousarray(arr.astype(np.float32))
            if a.shape[2] != 4:      # only the 1D lightwarp strip is RGB
                a = np.concatenate([a, np.ones_like(a[..., :1])], -1)
                self.tex[k] = a
            t = self.ctx.texture((a.shape[1], a.shape[0]), 4, a.tobytes(), dtype="f4")
            t.repeat_x = t.repeat_y = True
            t.filter = (moderngl.LINEAR, moderngl.LINEAR)
            self.gpu_tex[k] = t

        self.env_faces = self.make_probe_env_cube(64)
        cube = self.ctx.texture_cube((64, 64), 3,
                                     b"".join(np.ascontiguousarray(f.astype(np.float32)).tobytes()
                                              for f in self.env_faces),
                                     dtype="f4")
        cube.filter = (moderngl.LINEAR, moderngl.LINEAR)
        self.env_cube = cube

    def make_probe_env_cube(self, size=64):
        """The $envmap cubemap, baked from the lightcache probe at the head.

        In a real map `env_cubemap` means "whatever the env_cubemap entity
        nearest this model baked" -- and light.exe bakes those from the same
        radiosity solution that fills the ambient cube.  So the honest stand-in
        here is not a hand-drawn skybox: it is the same ambient-cube probe the
        shader reads, evaluated along every direction, which gives the six lobes
        their real relative brightness.  `$envmaptint "[.1 .1 .1]"` then scales
        the result, exactly as the 2004 VMT asks.
        """
        import lightcache as lc
        dirs = {
            0: lambda u, v: np.stack([np.ones_like(u), -v, -u], -1),   # +X
            1: lambda u, v: np.stack([-np.ones_like(u), -v, u], -1),   # -X
            2: lambda u, v: np.stack([u, np.ones_like(u), v], -1),     # +Y
            3: lambda u, v: np.stack([u, -np.ones_like(u), -v], -1),   # -Y
            4: lambda u, v: np.stack([u, -v, np.ones_like(u)], -1),    # +Z
            5: lambda u, v: np.stack([-u, -v, -np.ones_like(u)], -1),  # -Z
        }
        lin = np.linspace(-1, 1, size, dtype=np.float32)
        U, V = np.meshgrid(lin, lin)
        faces = []
        for i in range(6):
            d = dirs[i](U, V)
            d /= np.linalg.norm(d, axis=-1, keepdims=True)
            # a probe is very low frequency, so six lobes is all the detail a
            # 2004-era env_cubemap would have carried anyway
            faces.append(lc.ambient_light(d, self.head_cube).astype(np.float32))
        return np.stack(faces, 0)

    # ---- geometry ---------------------------------------------------------
    def _init_geometry(self):
        head = model.build_head(nu=96, nv=72)
        self.head = head
        n = head.positions.shape[0]
        inter = np.concatenate([head.positions, head.normals, head.uvs, head.tangents, head.bitangents], 1)
        self.head_vbo = self.ctx.buffer(np.ascontiguousarray(inter.astype(np.float32)).tobytes())
        self.head_ibo = self.ctx.buffer(np.ascontiguousarray(head.indices.astype(np.uint32)).tobytes())
        self.say(f"[mesh] head stand-in: {n} verts, {head.indices.shape[0]//3} tris, "
                 f"UV face centred at u=0.5")

        # world: floor, back wall, two side walls, plus the two props -- built
        # by the module-level helper so web_export.py bakes the same room
        sc = self.scene
        wP, wN, wUV, wIDX = build_world(sc)[0]
        inter = np.concatenate([wP, wN, wUV], 1).astype(np.float32)   # world shader has no tangents
        self.world_vbo = self.ctx.buffer(np.ascontiguousarray(inter).tobytes())
        self.world_ibo = self.ctx.buffer(np.ascontiguousarray(wIDX.astype(np.uint32)).tobytes())
        # .size, not .shape[0]: the index array is (ntris, 3), so shape[0] is
        # the *triangle* count -- which silently dropped the three walls.
        self.world_vert_count = wIDX.size

        pP, pN, pUV, IDX = build_world(sc)[1]
        inter = np.concatenate([pP, pN, pUV], 1).astype(np.float32)
        self.prop_vbo = self.ctx.buffer(np.ascontiguousarray(inter).tobytes())
        self.prop_ibo = self.ctx.buffer(np.ascontiguousarray(IDX.astype(np.uint32)).tobytes())
        self.prop_idx_count = IDX.size   # same trap as the world draw above
        # per-prop index ranges (8 verts / 36 indices per box) so each entity can
        # be drawn with its own ambient cube
        per = 36
        self.prop_draws = [(i * per, per) for i in range(max(1, IDX.size // per))]

        # fullscreen triangle strip for post
        fsq = np.array([-1, -1, 3, -1, -1, 3], np.float32)
        self.fsq_vbo = self.ctx.buffer(fsq.tobytes())

    @staticmethod
    def _box(lo, hi):
        v = np.array([[lo[0], lo[1], lo[2]], [hi[0], lo[1], lo[2]], [hi[0], hi[1], lo[2]], [lo[0], hi[1], lo[2]],
                      [lo[0], lo[1], hi[2]], [hi[0], lo[1], hi[2]], [hi[0], hi[1], hi[2]], [lo[0], hi[1], hi[2]]],
                     np.float32)
        # outward-facing winding (verified by cross-product test vs. box centre)
        f = np.array([[0, 2, 1], [0, 3, 2], [5, 7, 4], [5, 6, 7], [1, 6, 5], [1, 2, 6],
                      [4, 3, 0], [4, 7, 3], [3, 6, 2], [3, 7, 6], [4, 1, 5], [4, 0, 1]], np.uint32)
        return v, f

    # ---- lightcache -------------------------------------------------------
    def _init_lightcache(self):
        t0 = time.time()
        self.grid = lightcache.bake_grid(self.scene, res=(26, 18, 28), bounces=3, verbose=False)
        self.head_cube = lightcache.sample_cube(self.grid, self.scene.head_pos)
        # per-entity probes: this is LightcacheGetStatic()/LightcacheGetDynamic()
        # returning *one* ambient cube for the whole model, which is then handed
        # to the forward renderer as cAmbientCube when the entity is drawn.
        self.prop_cubes = [lightcache.sample_cube(self.grid, (b.lo + b.hi) * 0.5)
                           for b in self.scene.props]
        self.prop_cube_idx = 0
        self.head_sh = lightcache.sample_sh(self.grid, self.scene.head_pos)
        lightcache.save(self.scene, self.grid, self.outdir,
                        head_cube=self.head_cube, head_sh=self.head_sh, verbose=False)
        self.floor_lm_np, _ = lightcache.bake_lightmap(self.scene, self.grid, res=192, which="floor")
        self.wall_lm_np, _ = lightcache.bake_lightmap(self.scene, self.grid, res=192, which="wall")
        self.say(f"[cache] probes baked in {time.time()-t0:.2f}s  |  head ambient cube "
                 f"(-x..+z) = {np.round(self.head_cube[:,0], 3)}")
        lm_f = self.ctx.texture((192, 192), 3, np.ascontiguousarray(self.floor_lm_np.astype(np.float32)).tobytes(), dtype="f4")
        lm_w = self.ctx.texture((192, 192), 3, np.ascontiguousarray(self.wall_lm_np.astype(np.float32)).tobytes(), dtype="f4")
        for t in (lm_f, lm_w):
            t.filter = (moderngl.LINEAR, moderngl.LINEAR)
        self.lm_floor, self.lm_wall = lm_f, lm_w

    # ---- programs ---------------------------------------------------------
    def make_model_program(self, combos, num_lights):
        frag = shader_mod.build_fragment_source(combos)
        frag = frag.replace("__NUM_LIGHTS__", str(num_lights))
        prog = self.ctx.program(
            vertex_shader=shader_mod.VERT_SRC,
            fragment_shader=frag,
        )
        return prog

    @staticmethod
    def setu(prog, name, value):
        """GLSL compilers drop uniforms that the active combo never reads, so
        setting them has to be conditional -- and *which* ones survive is a
        useful readout of what a given VMT actually uses."""
        if name in prog:
            prog[name].value = value
            return True
        return False

    @staticmethod
    def setu_array(prog, name, arr):
        """Array uniforms: the driver reports how many elements the active combo
        actually keeps, so only that many can be written (a 4-light array whose
        loop bound is 2 gets trimmed to 2 by the compiler)."""
        if name not in prog:
            return False
        u = prog[name]
        n = getattr(u, "array_length", 1) or 1
        a = np.asarray(arr, np.float32)
        if a.ndim >= 2 and a.shape[0] >= n:
            a = a[:n]
        u.write(np.ascontiguousarray(a).tobytes())
        return True

    def set_model_uniforms(self, prog, u, camera_eye, num_lights, model_mat=None):
        model_mat = np.eye(4, dtype=np.float32) if model_mat is None else model_mat
        self.mat_model, self.mat_normal = model_mat, np.eye(3, dtype=np.float32)
        # these four are always live: the vertex shader reads them all
        prog["u_model"].write(as_mat4(model_mat).tobytes())
        prog["u_view"].write(as_mat4(self.view).tobytes())
        prog["u_proj"].write(as_mat4(self.proj).tobytes())
        if "u_normalMat" in prog:
            prog["u_normalMat"].write(
                np.ascontiguousarray(np.eye(3, dtype=np.float32)).tobytes())

        # PSREG_EYEPOS_SPEC_EXPONENT: xyz are only known at draw time (Source
        # calls GetWorldSpaceCameraPosition() here).  Keeping the Python dict in
        # sync matters -- otherwise the CPU reference shades with the eye at the
        # origin and every reflection vector is wrong.
        eye = np.array(u["EyePos_SpecExponent"], np.float32)
        eye[:3] = camera_eye
        u["EyePos_SpecExponent"] = [float(v) for v in eye]
        self.setu(prog, "g_EyePos_SpecExponent", tuple(eye))
        self.setu(prog, "g_FresnelRanges_SpecBoost", tuple(u["FresnelRanges_SpecBoost"]))
        self.setu(prog, "g_SpecularRimParams", tuple(u["SpecularRimParams"]))
        self.setu(prog, "g_FlashlightPos_RimBoost", tuple(u["FlashlightPos_RimBoost"]))
        self.setu(prog, "g_FlashlightAttenuation_RimMask", tuple(u["FlashlightAttenuation_RimMask"]))
        self.setu(prog, "g_ShaderControls", tuple(u["ShaderControls"]))
        self.setu(prog, "g_DiffuseModulation", tuple(u["DiffuseModulation"]))
        self.setu(prog, "g_EnvmapTint_ShadowTweaks", tuple(u["EnvmapTint_ShadowTweaks"]))
        self.setu(prog, "g_EnvMapFresnel_SelfIllumMask",
                  tuple(u["EnvMapFresnel_SelfIllumMask"]))

        self.setu_array(prog, "u_ambientCube", self.head_cube)

        lp = np.zeros((4, 4), np.float32); lc = np.zeros((4, 4), np.float32)
        for i, l in enumerate(self.scene.lights[:num_lights]):
            lp[i, :3] = l.pos; lc[i, :3] = l.color
        self.setu_array(prog, "g_LightPos", lp)
        self.setu_array(prog, "g_LightColor", lc)

        self.gpu_tex["base"].use(0); self.setu(prog, "u_baseTex", 0)
        self.gpu_tex["normal"].use(1); self.setu(prog, "u_normalTex", 1)
        self.gpu_tex["exponent"].use(2); self.setu(prog, "u_exponentTex", 2)
        self.gpu_tex["lightwarp"].use(3); self.setu(prog, "u_lightwarpTex", 3)
        # $envmap "env_cubemap": the built cubemap.  Without this the CUBEMAP
        # path samples an unbound sampler -- which on llvmpipe comes back as a
        # fully black texture, i.e. a black head rather than a warning.
        self.env_cube.use(5); self.setu(prog, "u_envCube", 5)
        self.active_registers = sorted(prog._members.keys())

    # ---- rendering --------------------------------------------------------
    def render_variant(self, name, vmt_file, opts, desc):
        from vmt import load_material
        mat = load_material(os.path.join(os.path.dirname(self.vmt_paths["ep1"]), vmt_file))
        hw = HWConfig(ps_2_b=opts.get("ps_2_b", True),
                      use_bumpmapping=True,
                      use_phong=opts.get("use_phong", True))
        c, u = combos_mod.resolve(mat, hw)
        u["FresnelRanges_SpecBoost"] = list(u["FresnelRanges_SpecBoost"])
        n_lights = len(self.scene.lights)

        model_mat = np.eye(4, dtype=np.float32)
        model_mat[:3, :3] *= 0.62                            # head is authored ~1 unit tall
        model_mat[:3, 3] = self.scene.head_pos
        prog = self.make_model_program(c, n_lights)
        self.set_model_uniforms(prog, u, self.scene.camera_eye, n_lights, model_mat)

        hdr = self.ctx.framebuffer(
            color_attachments=[self.ctx.texture((self.size, self.size), 4, dtype="f2")],
            depth_attachment=self.ctx.depth_texture((self.size, self.size)))
        hdr.use()
        self.ctx.enable(moderngl.DEPTH_TEST | moderngl.CULL_FACE)
        self.ctx.clear(0.0, 0.0, 0.0, 1.0)

        # world first
        wprog = self.ctx.program(vertex_shader=WORLD_VS, fragment_shader=WORLD_FS)
        wprog["u_view"].write(as_mat4(self.view).tobytes())
        wprog["u_proj"].write(as_mat4(self.proj).tobytes())
        ident = as_mat4(np.eye(4, dtype=np.float32))
        wprog["u_model"].write(ident.tobytes())
        wprog["u_normalMat"].write(np.ascontiguousarray(np.eye(3, dtype=np.float32)).tobytes())
        wprog["u_ambientCube"].write(np.ascontiguousarray(self.head_cube.astype(np.float32)).tobytes())
        wva = self.ctx.vertex_array(
            wprog, [(self.world_vbo, "3f 3f 2f", "a_pos", "a_normal", "a_uv")],
            index_buffer=self.world_ibo)
        wprog["u_albedo"].value = (0.38, 0.40, 0.46)
        wprog["u_useLightmap"].value = 1.0
        self.lm_wall.use(4); wprog["u_lightmap"].value = 4
        wva.render(moderngl.TRIANGLES, self.world_vert_count)

        pva = self.ctx.vertex_array(
            wprog, [(self.prop_vbo, "3f 3f 2f", "a_pos", "a_normal", "a_uv")],
            index_buffer=self.prop_ibo)
        # One draw per prop, each uploading *its own* ambient cube: that is the
        # per-object path of the forward renderer, and it is why the engine
        # cannot batch two entities that resolve to different probe cubes --
        # cAmbientCube is a constant register, not a vertex attribute.
        wprog["u_useLightmap"].value = 0.0
        wprog["u_albedo"].value = (0.45, 0.40, 0.34)
        for pi in range(len(self.prop_cubes)):
            cube = self.prop_cubes[pi].astype(np.float32)
            wprog["u_ambientCube"].write(np.ascontiguousarray(cube).tobytes())
            pva.render(moderngl.TRIANGLES, self.prop_draws[pi][1], first=self.prop_draws[pi][0])

        # then the model
        va = self.ctx.vertex_array(
            prog, [(self.head_vbo, "3f 3f 2f 3f 3f", "a_pos", "a_normal", "a_uv", "a_tangent", "a_bitangent")],
            index_buffer=self.head_ibo)
        va.render(moderngl.TRIANGLES, self.head.indices.size)

        img = self.post(hdr)
        out = os.path.join(self.outdir, f"{name}.png")
        self.save_png(img, out)
        self.say(f"[render] {name:14s} combos={','.join(c.active()) or 'none'}  "
                 f"registers_live={len(self.active_registers)}  -> {out}\n           {desc}")
        return img, c, u, prog, hdr

    def post(self, hdr):
        """bright pass -> 4 separable blur passes (ping-pong) -> combine/tonemap.
        Source's HDR pipeline does this same shape of work at a fixed point size;
        the point of having it here is that $phongboost 6 only *looks* like
        Episode One once the highlight is allowed to bloom."""
        w = h = self.size
        scene_tex = hdr.color_attachments[0]
        lw, lh = w // 4, h // 4
        bright = self.ctx.framebuffer([self.ctx.texture((lw, lh), 4, dtype="f2")])
        ping = [self.ctx.framebuffer([self.ctx.texture((lw, lh), 4, dtype="f2")]) for _ in range(2)]
        out = self.ctx.framebuffer([self.ctx.texture((w, h), 4)])

        prog_b = self.ctx.program(vertex_shader=POST_VS, fragment_shader=BRIGHT_FS)
        prog_l = self.ctx.program(vertex_shader=POST_VS, fragment_shader=BLUR_FS)
        prog_c = self.ctx.program(vertex_shader=POST_VS, fragment_shader=COMBINE_FS)
        va_b = self.ctx.vertex_array(prog_b, [(self.fsq_vbo, "2f", "a_pos")])
        va_l = self.ctx.vertex_array(prog_l, [(self.fsq_vbo, "2f", "a_pos")])
        va_c = self.ctx.vertex_array(prog_c, [(self.fsq_vbo, "2f", "a_pos")])

        self.ctx.disable(moderngl.DEPTH_TEST)
        bright.use(); scene_tex.use(0)
        prog_b["u_src"].value = 0
        prog_b["u_threshold"].value = 1.0
        va_b.render(moderngl.TRIANGLES, 3)

        src = bright.color_attachments[0]
        for i, d in enumerate([(1.0, 0.0), (0.0, 1.0), (1.0, 0.0), (0.0, 1.0)]):
            dst = ping[i % 2]
            dst.use(); src.use(0)
            prog_l["u_src"].value = 0
            prog_l["u_dir"].value = (d[0] / lw, d[1] / lh)
            va_l.render(moderngl.TRIANGLES, 3)
            src = dst.color_attachments[0]

        out.use()
        scene_tex.use(0); src.use(1)
        prog_c["u_scene"].value = 0
        prog_c["u_bloom"].value = 1
        prog_c["u_exposure"].value = 1.15
        prog_c["u_bloomAmount"].value = 0.85
        va_c.render(moderngl.TRIANGLES, 3)

        data = out.read(components=4, dtype="f1")
        return np.frombuffer(data, np.uint8).reshape(h, w, 4)

    @staticmethod
    def save_png(img, path):
        from PIL import Image
        # glReadPixels hands back rows bottom-up; PNG rows run top-down.
        Image.fromarray(img[::-1, :, :3]).save(path)

    # ---- validation -------------------------------------------------------
    def gbuffer(self, combos):
        """Render the model's interpolants into float attachments so the CPU
        shader and the tracer see byte-identical inputs to the GPU."""
        w = h = self.size
        fbo = self.ctx.framebuffer(
            color_attachments=[self.ctx.texture((w, h), 4, dtype="f4") for _ in range(5)],
            depth_attachment=self.ctx.depth_texture((w, h)))
        gprog = self.ctx.program(vertex_shader=shader_mod.VERT_SRC, fragment_shader=GBUF_FS)
        gprog["u_model"].write(as_mat4(self.mat_model).tobytes())
        gprog["u_view"].write(as_mat4(self.view).tobytes())
        gprog["u_proj"].write(as_mat4(self.proj).tobytes())
        gprog["u_normalMat"].write(np.ascontiguousarray(self.mat_normal.astype(np.float32)).tobytes())
        va = self.ctx.vertex_array(
            gprog, [(self.head_vbo, "3f 3f 2f 3f 3f",
                     "a_pos", "a_normal", "a_uv", "a_tangent", "a_bitangent")],
            index_buffer=self.head_ibo)
        fbo.use()
        self.ctx.enable(moderngl.DEPTH_TEST | moderngl.CULL_FACE)
        self.ctx.clear(0, 0, 0, 0)
        va.render(moderngl.TRIANGLES, self.head.indices.size)
        out = {}
        for i, k in enumerate(["worldPos", "normal", "T", "B", "uv"]):
            arr = np.frombuffer(fbo.read(components=4, dtype="f4", attachment=i), np.float32)
            out[k] = np.ascontiguousarray(arr.reshape(h, w, 4)[..., :2 if k == "uv" else 3])
        return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--size", type=int, default=900)
    ap.add_argument("--tex-res", type=int, default=512)
    ap.add_argument("--out", default=None)
    ap.add_argument("--variants", default="all")
    ap.add_argument("--trace", type=int, default=1)
    args = ap.parse_args()

    t_start = time.time()
    r = Renderer(size=args.size, tex_res=args.tex_res)
    r.outdir = os.path.abspath(args.out) if args.out else r.outdir
    os.makedirs(r.outdir, exist_ok=True)

    sc = r.scene
    r.view = look_at(sc.camera_eye, sc.camera_target)
    r.proj = perspective(sc.fov_deg, 1.0, 0.05, 60.0)

    results = {}
    keep = None
    for name, vmt, opts, desc in VARIANTS:
        if args.variants != "all" and name not in args.variants.split(","):
            continue
        img, c, u, prog, hdr = r.render_variant(name, vmt, opts, desc)
        results[name] = dict(desc=desc, combos=c.active(),
                             registers={k: list(v) for k, v in u.items() if isinstance(v, (list, tuple))})
        if name == "ep1_phong":
            keep = (prog, hdr, c, u)

    # ---- CPU validation against the GPU --------------------------------
    report = dict(variants=results, gl=r.log)
    if keep is not None:
        _, hdr, c, u = keep
        gb = r.gbuffer(c)
        lights = [(l.pos, l.color) for l in sc.lights]
        cpu = shader_mod.CPUShader(c, u, r.tex, len(lights), ambient_cube=r.head_cube,
                                   env_faces=r.env_faces)
        linear = cpu.shade(gb, lights)

        gpu_lin = np.frombuffer(hdr.read(components=4, dtype="f2"), np.float16).astype(np.float32)
        gpu_lin = gpu_lin.reshape(args.size, args.size, 4)[..., :3]

        # only compare where geometry exists (G-buffer wrote a position)
        mask = np.abs(gb["worldPos"]).sum(-1) > 1e-6
        m = mask[..., None]
        cpu_masked = np.where(m, linear, 0.0)
        diff = np.abs(cpu_masked - gpu_lin)
        m3 = np.repeat(mask[..., None], 3, axis=2)
        maxd = float(diff[m3].max()) if mask.any() else 0.0
        meand = float(diff[m3].mean()) if mask.any() else 0.0
        d1 = diff.max(-1)[mask]
        p50, p99 = float(np.percentile(d1, 50)), float(np.percentile(d1, 99))
        # where is the tail?  a hand full of pixels is expected: the two paths
        # bilinearly filter the same texture with different rounding, so the
        # disagreement lives on the highest-contrast texel edges.
        big = (diff.max(-1) > 0.01) & mask
        frac_big = float(big.sum()) / max(int(mask.sum()), 1)
        r.say(f"[check] CPU vs GPU on {int(mask.sum())} model pixels: "
              f"p50 = {p50:.5f}, p99 = {p99:.5f}, max = {maxd:.4f} "
              f"({frac_big*100:.2f}% of pixels above 0.01)")

        # diff heatmap + a red-green overlay of the two paths
        from PIL import Image
        hm = np.clip(diff.max(-1) * 8.0, 0, 1)
        rgb = np.stack([hm, np.zeros_like(hm), np.zeros_like(hm)], -1)
        hp = os.path.join(r.outdir, "cpu_vs_gpu_diff.png")
        Image.fromarray((np.clip(rgb, 0, 1)[::-1] * 255).astype(np.uint8)).save(hp)
        report["validation"] = dict(pixels=int(mask.sum()), max_abs_diff=maxd,
                                    mean_abs_diff=meand, p50=p50, p99=p99,
                                    frac_above_0p01=frac_big,
                                    image=os.path.basename(hp))

        # ---- verbose per-pixel traces ---------------------------------
        if args.trace:
            import trace as trace_mod
            traces = trace_mod.pick_and_trace(gb, cpu, u, r.tex, lights,
                                              r.head_cube, os.path.join(r.outdir, "trace.txt"))
            r.say(f"[trace] wrote {len(traces)} per-pixel traces -> {os.path.join(r.outdir, 'trace.txt')}")
            report["traces"] = traces

    with open(os.path.join(r.outdir, "report.json"), "w") as f:
        json.dump(report, f, indent=2)
    r.say(f"[done ] {time.time()-t_start:.1f}s total")
    glfw.terminate()


if __name__ == "__main__":
    main()
