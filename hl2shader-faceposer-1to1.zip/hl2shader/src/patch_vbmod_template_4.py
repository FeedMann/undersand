"""Patch 4: the model in the scene (VBMOD4) -- CPU probe lookup for the entity
cube, the second material for its eyeballs, the move-the-model demo, and the
material panel that shows the package's own .vbm files."""
import io

P = "web_template.html"
s = io.open(P, encoding="utf-8").read()


def sub1(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:70])
    s = s.replace(old, new)


# ---------------------------------------------------- 1. state: model motion
sub1("""  model:{src:PARITY?"head":"head", vbSel:0, vbWeight:0.0, vbMirror:true},""",
     """  model:{src:"head", vbSel:0, vbWeight:0.0, vbMirror:true, move:[0.0,0.0]},""")

# ------------------------------------------- 2. helpers: cube lookup + matrix
sub1("""/* Which probe cube a *model* gets: cAmbientCube is resolved once per entity, at
   the entity's origin -- for a character that origin is at the feet, not the
   head, which is exactly why a tall model can look flat.  The read-out prints
   both so the difference is visible. */
function vbCube(){""",
     """/* The probe field, looked up on the CPU the way the engine resolves one
   ambient cube per entity (LightcacheGetStatic): round the position to a voxel,
   clamp it, then average a (2r+1)^3 block of probes -- radius 1 for a model.
   This is the JS twin of lightcache.sample_cube(), reading the u8 copy of the
   array the GPU gets as an RGB16F 3D texture. */
function probeIndex(pos, r){
  const d=DATA.lightgrid, out=[];
  for(let a=0;a<3;a++){
    let i=Math.round((pos[a]-d.lo[a])/d.cell[a]);
    out.push(Math.max(r,Math.min(d.dims[a]-1-r,i)));
  }
  return out;
}
function probeCubeAt(i,j,k){
  const d=DATA.lightgrid, bytes=gpu.cubesU8;
  const base=(((i*d.dims[1])+j)*d.dims[2]+k)*18;
  const out=[];
  for(let l=0;l<6;l++){
    const ch=[0,0,0];
    for(let c=0;c<3;c++) ch[c]=bytes[base+l*3+c]/255*DATA.lightgrid.cubeScale;
    out.push(ch);
  }
  return out;
}
function entityCube(pos,r){
  const [i,j,k]=probeIndex(pos,r||1);
  const cube=[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]];
  let n=0;
  for(let a=i-1;a<=i+1;a++) for(let b=j-1;b<=j+1;b++) for(let c=k-1;c<=k+1;c++){
    const pc=probeCubeAt(a,b,c);
    for(let l=0;l<6;l++) for(let ch=0;ch<3;ch++) cube[l][ch]+=pc[l][ch];
    n++;
  }
  for(let l=0;l<6;l++) for(let ch=0;ch<3;ch++) cube[l][ch]/=n;
  return cube;
}
function translateM4(dx,dy,dz){
  return new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, dx,dy,dz,1]);
}

/* Which probe cube a *model* gets: cAmbientCube is resolved once per entity, at
   the entity's origin -- for a character that origin is at the feet, not the
   head, which is exactly why a tall model can look flat.  The read-out prints
   both so the difference is visible. */
function vbCube(){""")

sub1("""  if(!gpu.vb||!gpu.vb.cube){
    const o=(DATA.vbmod&&DATA.vbmod.origin)||[0,0,0];
    gpu.vb.cube=LG.sampleCube(o,1);
    gpu.vb.headCube=LG.sampleCube(DATA.vbmod.eyeCentre,1);
  }""",
     """  if(!gpu.vb||!gpu.vb.cube){
    const o=(DATA.vbmod&&DATA.vbmod.origin)||[0,0,0];
    const mv=state.model.move, off=[mv[0],0,mv[1]];
    gpu.vb.cube=entityCube([o[0]+off[0],o[1]+off[1],o[2]+off[2]],1);
    gpu.vb.headCube=entityCube([DATA.vbmod.eyeCentre[0]+off[0],
                                DATA.vbmod.eyeCentre[1]+off[1],
                                DATA.vbmod.eyeCentre[2]+off[2]],1);
  }""")

# the read-out gains the entity-cube comparison and the file's own counts
sub1("""function refreshVbReadout(){
  const el=document.getElementById("vbread"); if(!el||!gpu.vb) return;
  const V=gpu.vb, L=[];
  L.push("file     "+V.name+" \\u00b7 "+V.nverts+" verts \\u00b7 "+V.meshes.length+" meshes");
  L.push("meshes   "+V.meshes.map(m=>m.material+"("+m.vertexCount+"v/"+m.indexCount/3+"t)").join("  "));
  L.push("targets  "+V.targets.length+" flexes, active "+(V.targets[state.model.vbSel].name)+
         " @ "+state.model.vbWeight.toFixed(2)+(state.model.vbMirror?" (+mirror)":""));
  L.push("cube@origin "+(V.cube?LG.fmt(LG.ambientLight([0,1,0],V.cube)):"\\u2014")+
         "   cube@eye "+(V.headCube?LG.fmt(LG.ambientLight([0,1,0],V.headCube)):"\\u2014"));
  el.textContent=L.join("\\n");
}""",
     """function refreshVbReadout(){
  const el=document.getElementById("vbread"); if(!el) return;
  const L=[];
  const on=(state.model.src==="vbmod");
  const dq=DATA.vbmod;
  if(dq){
    const V=gpu.vb, mv=state.model.move;
    L.push("file      "+dq.name+" \\u00b7 "+dq.source.bytes.toLocaleString()+" bytes \\u00b7 "+
           dq.source.verts+" verts \\u00b7 "+dq.source.tris+" tris");
    L.push("meshes    "+dq.meshes.map(m=>m.material+"("+m.vertexCount+"v/"+m.indexCount/3+"t)").join("  ")+
           "   + "+dq.eyes.length+" eyeball sphere(s), a second material program");
    L.push("targets   "+dq.targets.length+" VBFLX1 flexes \\u00b7 "+dq.targetNames.length+" names in the trailer");
    const t=V.targets[state.model.vbSel];
    L.push("flex      "+(t.name||"")+"  "+t.count+" sparse deltas, peak "+t.peak.toFixed(4)+
           "  @ "+state.model.vbWeight.toFixed(2)+" wt"+(state.model.vbMirror&&t.pair?(" + mirror "+t.pair):""));
    L.push("placed at ["+mv[0].toFixed(2)+" 0 "+mv[1].toFixed(2)+"], eye level y="+dq.eyeCentre[1].toFixed(3));
    const c0=entityCube([dq.origin[0]+mv[0],dq.origin[1],dq.origin[2]+mv[1]],1);
    const c1=entityCube([dq.eyeCentre[0]+mv[0],dq.eyeCentre[1],dq.eyeCentre[2]+mv[1]],1);
    L.push("cAmbientCube @ entity origin  "+LG.fmt(LG.ambientLight([0,1,0],c0))+
           "  (this is what the engine hands a model)");
    L.push("cAmbientCube @ the eyes       "+LG.fmt(LG.ambientLight([0,1,0],c1))+
           "  (a meter higher -- what a per-pixel lookup would see)");
    L.push("mode      "+state.light.mode+"  ("+
           (state.light.mode==="probe"?"per-fragment fetch of the 3D texture; move the model and it changes continuously"
            :state.light.mode==="flat"?"one cube for the whole map": "one cube per entity, stepped when the model crosses a voxel")+")");
  } else {
    L.push("no VBMOD blob in this build");
  }
  el.textContent=L.join("\\n");
}""")

# ---------------------------------------------- 3. model matrices use `move`
sub1("""  if(useVb){
    const V=gpu.vb, p=gpu.vbSkin;
    gl.useProgram(p);
    const L=(n)=>gl.getUniformLocation(p,n);
    gl.uniformMatrix4fv(L("u_model"),false,IDENT4);""",
     """  if(useVb){
    const V=gpu.vb, p=gpu.vbSkin, MV=state.model.move;
    gl.useProgram(p);
    const L=(n)=>gl.getUniformLocation(p,n);
    gl.uniformMatrix4fv(L("u_model"),false,translateM4(MV[0],0,MV[1]));""")
sub1("""      const ep=gpu.vbEye; if(ep){
      gl.useProgram(ep);
      const EL=(n)=>gl.getUniformLocation(ep,n);
      gl.uniformMatrix4fv(EL("u_model"),false,IDENT4);""".replace("      const ep", "    const ep"),
     """    const ep=gpu.vbEye; if(ep){
      gl.useProgram(ep);
      const EL=(n)=>gl.getUniformLocation(ep,n);
      gl.uniformMatrix4fv(EL("u_model"),false,IDENT4);""")

# ------------------------------------------------- 4. the VBMOD eyeball draw
sub1("""    const ep=gpu.vbEye; if(ep){
      gl.useProgram(ep);
      const EL=(n)=>gl.getUniformLocation(ep,n);
      gl.uniformMatrix4fv(EL("u_model"),false,IDENT4);
      gl.uniformMatrix4fv(EL("u_view"),false,viewM);
      gl.uniformMatrix4fv(EL("u_proj"),false,projM);
      gl.uniformMatrix3fv(EL("u_normalMat"),false,IDENT3);
      gl.uniform4f(EL("g_EyePos"),eye[0],eye[1],eye[2],0);
      gl.activeTexture(gl.TEXTURE5); gl.bindTexture(gl.TEXTURE_CUBE_MAP,gpu.env);
      gl.uniform1i(EL("u_envCube"),5);
      const lp3=new Float32Array(12), lc3=new Float32Array(12);
      state.lights.slice(0,3).forEach((l,i)=>{ lp3.set(l.pos,i*4); lc3.set(l.color,i*4); });
      gl.uniform4fv(EL("g_sLightInfoPos"),lp3);
      gl.uniform4fv(EL("g_sLightInfoColor"),lc3);
      gl.uniform3fv(EL("g_cAmbientOcclColor"),new Float32Array([0.35,0.30,0.28]));
      gl.uniform1f(EL("g_flAOStandIn"),state.eye.ao);
      gl.uniform1f(EL("u_eyeShow"),state.eye.show);
      V.eyes.forEach((e,i)=>{
        const amb=LG.sampleAmbient(e.centre,e.forward,1);
        const avg=luma(amb);
        gl.uniform4f(EL("g_flDilation_Glossiness_AvgAmbient_CorneaBump"),
                     state.eye.dilation,state.eye.gloss,avg,0.0);
        gl.uniform4f(EL("g_EyeCentre_Radius"),e.centre[0],e.centre[1],e.centre[2],e.radius);
        gl.uniform3fv(EL("g_EyeForward"),new Float32Array(e.forward));
        gl.uniform4fv(EL("g_IrisColor"),new Float32Array(state.eye.iris));
        gl.uniform4fv(EL("g_IrisParams"),new Float32Array([state.eye.irisR,state.eye.pupilR,
                                                           0.03,state.eye.bright]));
        for(const m of V.meshes){
          if(m.slot!=="eye"||m.material!==e.material) continue;
          gl.drawElements(gl.TRIANGLES,m.indexCount,gpu.vbIndexType,m.firstIndex*4);
        }
      });
    }""",
     """    drawVbEyes();""")

sub1("""/* The read-out that answers "what is my file actually supplying": the payload""",
     """/* The second material of the VBMOD model: the eyeballs.  Same vertex program
   the stand-in head's eyes use (DATA.vert), same pixel program (eye_refract),
   different geometry and a different socket frame -- which is the entire point:
   the material decides the program, the model format only feeds it. */
function drawVbEyes(){
  const ep=gpu.vbEye, dq=DATA.vbmod, V=gpu.vb;
  if(!ep||!dq||!V) return;
  const MV=state.model.move;
  gl.useProgram(ep);
  const EL=(n)=>gl.getUniformLocation(ep,n);
  gl.uniformMatrix4fv(EL("u_view"),false,viewM);
  gl.uniformMatrix4fv(EL("u_proj"),false,projM);
  gl.uniformMatrix3fv(EL("u_normalMat"),false,IDENT3);
  setUniform(ep,"u_cFlexScale",0.0);
  setUniform(ep,"u_flexWeight",0.0);
  const ep2=DATA.camEye;
  gl.uniform4f(EL("g_EyePos"),ep2[0],ep2[1],ep2[2],0);
  gl.uniform3fv(EL("g_cAmbientOcclColor"),new Float32Array([0.35,0.30,0.28]));
  gl.uniform1f(EL("g_flAOStandIn"),state.eye.ao);
  gl.uniform1f(EL("u_eyeShow"),state.eye.show);
  const lp=new Float32Array(12), lc=new Float32Array(12);
  state.lights.slice(0,3).forEach((l,i)=>{ lp.set(l.pos,i*4); lc.set(l.color,i*4); lc[i*4+3]=1; });
  gl.uniform4fv(EL("g_sLightInfoPos"),lp);
  gl.uniform4fv(EL("g_sLightInfoColor"),lc);
  gl.activeTexture(gl.TEXTURE5); gl.bindTexture(gl.TEXTURE_CUBE_MAP,gpu.env);
  gl.uniform1i(EL("u_envCube"),5);
  gl.bindVertexArray(null);
  bindAttribs(ep,gpu.vbEyeVBO,gpu.vbEyeIBO,HEAD_LAYOUT);
  dq.eyes.forEach((e)=>{
    const c=[e.centre[0]+MV[0], e.centre[1], e.centre[2]+MV[1]];
    const m=e.matrix.slice();
    m[12]+=MV[0]; m[14]+=MV[1];
    gl.uniformMatrix4fv(EL("u_model"),false,new Float32Array(m));
    gl.uniform4f(EL("g_EyeCentre_Radius"),c[0],c[1],c[2],e.radius);
    gl.uniform3fv(EL("g_EyeForward"),new Float32Array(e.forward));
    // $iris from the material's own .vbm: eyeball_l/r.vbm carry
    // irisColor [0.3 0.42 0.55], irisSize 0.46, pupilSize 0.17,
    // irisSpecular 0.85, scleraSpecular 0.15 -- read, not retyped.
    const mat=DATA.vbmod.materials.files[e.material]||{};
    const eye=mat.eye||{};
    const col=eye.irisColor||state.eye.iris;
    gl.uniform4f(EL("g_IrisColor"),col[0],col[1],col[2],1.0);
    gl.uniform4f(EL("g_IrisParams"),eye.irisSize||state.eye.irisR,
                 eye.pupilSize||state.eye.pupilR,0.03,eye.irisSpecular||state.eye.bright);
    // g_flAverageAmbient: resolved once per material from the probe field at
    // that eyeball's own position -- the entity-cube lookup, per eye
    const cube=entityCube([c[0],c[1],c[2],],1);
    gl.uniform4f(EL("g_flDilation_Glossiness_AvgAmbient_CorneaBump"),
                 state.eye.dilation, eye.irisSpecular||0.85,
                 luma(LG.ambientLight([0,1,0],cube)), 0.0);
    gl.drawElements(gl.TRIANGLES,gpu.vbEyeCount,gl.UNSIGNED_SHORT,0);
  });
}

/* The read-out that answers "what is my file actually supplying": the payload""")

# ------------------------------------------------- 5. boot: cubes8 + eye mesh
sub1("""  /* ---- the VBMOD4 model: parse the file's own bytes, no conversion ------ */
  if(DATA.vbmod){""",
     """  /* ---- the VBMOD4 model: parse the file's own bytes, no conversion ------ */
  gpu.cubesU8=b64ToBytes(DATA.lightgrid.cubes8);
  if(DATA.vbmod){""")

sub1("""    gpu.vb.maps.albedo=mkTex(vbm.maps.albedo,true);
    gpu.vb.maps.bump=mkTex(vbm.maps.normal,true);
    gpu.vb.maps.expo=mkTex(vbm.maps.exponent,true);""",
     """    gpu.vb.maps.albedo=mkTex(vbm.maps.albedo,true);
    gpu.vb.maps.bump=mkTex(vbm.maps.normal,true);
    gpu.vb.maps.expo=mkTex(vbm.maps.exponent,true);
    // the eyeball sphere: a unit sphere + one matrix per eye, so the second
    // material needs no format-specific vertex program at all
    gpu.vbEyeVBO=gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER,gpu.vbEyeVBO);
    gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vbm.eyeMesh.verts),gl.STATIC_DRAW);
    gpu.vbEyeIBO=gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,gpu.vbEyeIBO);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(vbm.eyeMesh.idx),gl.STATIC_DRAW);
    gpu.vbEyeCount=vbm.eyeMesh.idx.length;""")

# ------------------------------------------- 6. the material panel + controls
sub1("""    <div class="sec">
      <h2>Face flexes <span class="tag">the other vertex stream</span></h2>""",
     """    <div class="sec">
      <h2>Materials <span class="tag">the package's own .vbm</span></h2>
      <div class="note" style="margin-top:0" id="vbmNote"></div>
      <div class="row"><select id="vbmSel" style="width:100%"></select></div>
      <pre id="vbmText"></pre>
      <div class="note" id="vbmMap"></div>
      <div class="row"><label for="vbmCustom">custom GLSL material (stubbed)</label>
        <input type="checkbox" id="vbmCustom"></div>
      <pre id="vbmStub" style="max-height:170px"></pre>
    </div>

    <div class="sec">
      <h2>Face flexes <span class="tag">the other vertex stream</span></h2>""")

sub1("""      <div id="vbFlexParams"></div>
      <div class="ro" id="vbread"></div>
    </div>""",
     """      <div id="vbFlexParams"></div>
      <div class="row"><label for="vbMove">walk the model across the light (x)</label></div>
      <div class="row"><input type="range" id="vbMove" min="-0.5" max="0.5" step="0.02" value="0">
        <input type="range" id="vbMoveZ" min="-0.5" max="0.5" step="0.02" value="0"></div>
      <div class="ro" id="vbread"></div>
    </div>""")

# ----------------------------------------------------- 7. UI wiring, panel
sub1("""    window.vb={
      data:true, apply:applyVbFlex, modelSrc:setModelSrc,""",
     """    const mvx=$("vbMove"), mvz=$("vbMoveZ");
    const onMove=()=>{ state.model.move=[parseFloat(mvx.value),parseFloat(mvz.value)];
      gpu.vb.cube=null; refreshVbReadout(); };
    mvx.addEventListener("input",onMove); mvz.addEventListener("input",onMove);
    /* the material panel: the package's own files, then the mapping onto the
       ported shader's knobs, then the stubbed custom path */
    {
      const ms=$("vbmSel"), files=DATA.vbmod.materials.files;
      Object.keys(files).forEach(k=>{ const o=document.createElement("option");
        o.value=k; o.textContent=k+".vbm  \\u2014 shader: "+(files[k].shader||"lit");
        ms.appendChild(o); });
      $("vbmNote").textContent=DATA.vbmod.materials.note;
      const show=()=>{
        const k=ms.value, f=files[k], m=DATA.vbmod.materials.mapping[k]||{};
        $("vbmText").textContent=JSON.stringify(f,null,1)
          +"\\n// -> ported program: "+m.program+"  combos "+JSON.stringify(m.combos||{})
          +"\\n// registers: "+JSON.stringify(m.regs||{},null,0)
          +(m.stands_in&&m.stands_in.length?("\\n// stand-ins: "+m.stands_in.join("; ")):"");
      };
      ms.addEventListener("change",show);
      ms.value=Object.keys(files).includes("xana")?"xana":ms.value;
      show();
      const boxes=Object.entries(DATA.vbmod.materials.fields)
        .map(([k,v])=>k.padEnd(20)+" -> "+(Array.isArray(v)?v.join(" "):v)).join("\\n");
      $("vbmMap").textContent="search order: "+DATA.vbmod.materials.order.join("  ")
        +"   |   field map:\\n"+boxes;
      $("vbmStub").textContent=DATA.vbmod.materials.custom_stub;
      $("vbmCustom").addEventListener("change",()=>{
        state.vbmCustom=$("vbmCustom").checked;
        $("vbmStub").style.opacity=state.vbmCustom?"1":"0.45";
      });
      state.vbmCustom=false;
      $("vbmStub").style.opacity="0.45";
    }
    window.vb={
      data:true, apply:applyVbFlex, modelSrc:setModelSrc,
      entityCube:(p)=>entityCube(p,1),"""
)

io.open(P, "w", encoding="utf-8").write(s)
print("patch 4 applied")
