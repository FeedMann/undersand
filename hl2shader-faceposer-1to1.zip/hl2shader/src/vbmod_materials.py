#!/usr/bin/env python3
"""The FacePoser material layer, read as it is and stubbed where it is empty.

`leanna.vbmod` names a material per mesh.  The package resolves those names to
`.vbm` files (FacePoser's portable subset of Chisel `.cmt` JSON) with this
search order, quoted from its own MATERIALS.md:

    "1. Model folder.  2. Folder supplied with --materials DIR.
     3. Folder supplied with --assets DIR."

and:

    "Built-in shader types include lit, half_lambert, and the procedural
     chisel_eye preview. Custom GLSL fragment shaders are supported for
     advanced users; a compile failure falls back to lit shading so the model
     remains visible."

What the three shipped `.vbm` files actually contain (verbatim, see
../vbmod_ref/materials/):

    xana.vbm       shader "half_lambert"   albedo "xana"   tint [1,1,1,1]
                   specularStrength 0.1    shininess 24.0
    eyeball_l.vbm  shader "chisel_eye"     seed 7.0   irisColor [0.3,0.42,0.55]
    eyeball_r.vbm  shader "chisel_eye"     seed 3.0   (same parameters)

and the albedo reference is a *stem* -- "xana" is looked up as xana.png /
.tga / .jpg / .jpeg / .bmp / .vtf beside the .vbm, under textures/, and under
each root.  None of those files exist in the package, which its own description
says out loud:

    "Put xana.png/.tga/.jpg/.vtf next to this file (or under textures/). Until
     then FacePoser shows the plain lit fallback colour."

So this module does two things and nothing else:

  1. maps the *current* (placeholder) material definitions onto the ported
     Source shader's combos and constant registers, so the same model can be
     drawn by either system -- the table is the deliverable, not new material
     semantics;
  2. stubs the custom-GLSL path exactly as MATERIALS.md describes it: a shader
     that fails to compile falls back to lit, and here that means falling back
     to the ported VertexLitGeneric combos that this package already exercises.

Nothing here invents a material format.  The user's tool is the authority on
`.vbm`; this is the adapter that lets the *Source* shaders consume it.
"""
from __future__ import annotations

import json
from pathlib import Path

# ---------------------------------------------------------------------------
# the mapping: FacePoser material field -> the ported shader's knob
#
# Left column is a key that literally appears in the .vbm JSON, right column is
# where the ported Source shader reads the same quantity.  Registers are named
# as skin_dx9_helper.cpp names them, combos as the .fxc #defines name them.
# ---------------------------------------------------------------------------
FIELD_MAP = {
    "shader": {
        "lit":          "no combos (ambient + one N.L per light)",
        "half_lambert": "HALFLAMBERT=1  -- ndotl * 0.5 + 0.5 before the ramp",
        "chisel_eye":   "eye_refract_ps2x.fxc -- a *separate* material program",
        "custom GLSL":  "SUPPORTED_WITH_LIT_FALLBACK (stubbed below)",
    },
    "albedo":            "$basetexture    (a stem: .png/.tga/.jpg/.jpeg/.bmp/.vtf)",
    "tint":              "$color2         -> g_DiffuseModulation",
    "specularStrength":  "$phongboost     -> g_FresnelRanges_SpecBoost.w",
    "shininess":         "$phongexponent  -> g_EyePos_SpecExponent.w "
                         "(w >= 0 wins over the exponent map)",
    "eye.irisColor":     "$iris           -> g_IrisColor",
    "eye.irisSize":      "$iris           -> g_IrisParams.x (radius, radians)",
    "eye.pupilSize":     "$iris           -> g_IrisParams.y (radius, radians)",
    "eye.irisSpecular":  "$phongboost     -> g_IrisParams.w",
    "eye.scleraSpecular": "$phongexponent -> g_IrisParams.z (feather stand-in)",
    "eye.scleraColor":   "(no Source equivalent without $iris2 -- stand-in)",
    "eye.vesselColor":   "(no Source equivalent in eye_refract -- stand-in)",
    "eye.seed":          "(procedural detail; the Source eyemap would supply it)",
}


SEARCH_ORDER_NOTE = [
    "1. Model folder.",
    "2. Folder supplied with --materials DIR.",
    "3. Folder supplied with --assets DIR.",
]

# MATERIALS.md, verbatim: "A missing texture does not stop FacePoser from loading
# the mesh; the affected surface uses the built-in neutral lit fallback."
MISSING_TEXTURE_NOTE = ("A missing texture does not stop FacePoser from loading the mesh; "
                        "the affected surface uses the built-in neutral lit fallback.")


def load(vbm_path: str | Path) -> dict:
    return json.loads(Path(vbm_path).read_text())


def resolve_roots(model_dir: str | Path, materials: str | Path | None = None,
                  assets: str | Path | None = None) -> list[Path]:
    """MATERIALS.md's search order, in the same order."""
    roots = [Path(model_dir)]
    if materials:
        roots.append(Path(materials))
    if assets:
        roots.append(Path(assets))
    return roots


def find_texture(stem: str, roots) -> str | None:
    """The lookup MATERIALS.md describes: exact path, then under materials/ and
    textures/, with the six extensions tried when the reference has none."""
    exts = ["", ".png", ".tga", ".jpg", ".jpeg", ".bmp", ".vtf"]
    for root in roots:
        for sub in ("", "materials", "textures"):
            for e in exts if not Path(stem).suffix else [""]:
                p = Path(root) / sub / (stem + e)
                if p.is_file():
                    return str(p)
    return None


def decide(material: dict) -> dict:
    """What the ported Source shader does with this material, and what is a
    stand-in.  Returned so both the offline renderer and the viewer can state
    it instead of silently guessing."""
    shader = (material.get("shader") or "lit").strip()
    if shader == "chisel_eye":
        eye = material.get("eye", {})
        return dict(
            program="eye_refract_ps2x.fxc",
            combos={"HALFLAMBERT": 0},
            regs=dict(
                g_IrisColor=[*eye.get("irisColor", [0.3, 0.42, 0.55]), 1.0],
                g_IrisParams=[float(eye.get("irisSize", 0.46)),
                              float(eye.get("pupilSize", 0.17)),
                              float(eye.get("scleraSpecular", 0.15)),
                              float(eye.get("irisSpecular", 0.85))],
                g_flDilation_Glossiness_AvgAmbient_CorneaBump=[
                    float(eye.get("pupilFeather", 0.02)) * 10.0,   # stand-in
                    float(eye.get("irisSpecular", 0.85)),
                    0.0,                                           # filled from the probe field
                    0.0],
            ),
            stands_in=["iris colour comes from $iris (no eyemap texture exists here)",
                       "seed/fiberDensity/veinDensity/veinDistortion/fleckAmount are the "
                       "procedural preview's own detail -- $eyemap would carry that",
                       "vesselColor and irisFleckColor have no eye_refract equivalent"],
        )
    combos = {"HALFLAMBERT": 1 if shader == "half_lambert" else 0}
    regs = dict(
        g_DiffuseModulation=[float(x) for x in material.get("tint", [1, 1, 1, 1])],
        g_FresnelRanges_SpecBoost=[0.9, 0.5, 1.0, float(material.get("specularStrength", 0.1))],
        g_EyePos_SpecExponent=[0.0, 0.0, 0.0, float(material.get("shininess", 24.0))],
    )
    stands_in = []
    if shader == "custom":
        stands_in.append("custom GLSL: stubbed -- falls back to lit, per MATERIALS.md")
    return dict(program="skin_ps20b.fxc (VertexLitGeneric, $phong path)",
                combos=combos, regs=regs, stands_in=stands_in)


def table(materials: dict[str, dict], verbose: bool = True) -> str:
    lines = ["material            shader         -> ported program / combos",
             "-" * 78]
    for name, mat in materials.items():
        d = decide(mat)
        lines.append(f"{name:<19} {mat.get('shader','lit'):<14} -> {d['program']}"
                     f"  {d['combos']}")
        for k, v in d["regs"].items():
            lines.append(f"{'':<19} {k:<30} {v}")
        for s in d["stands_in"]:
            lines.append(f"{'':<19} stand-in: {s}")
    out = "\n".join(lines)
    if verbose:
        print(out)
    return out


CUSTOM_GLSL_STUB = '''// The custom-shader path, stubbed exactly as MATERIALS.md describes it:
//
//   "Custom GLSL fragment shaders are supported for advanced users; a compile
//    failure falls back to lit shading so the model remains visible."
//
// So this is a *fragment* hook, not a new material model.  It is handed the
// values the ported VertexLitGeneric path already computed, and if it does not
// compile the caller keeps the lit program instead of failing the mesh.
vec4 materialCustom(vec3 vWorldPos, vec3 vWorldNormal, vec2 v_uv, vec3 vAlbedo,
                    vec3 vAmbient, vec4 vLightAccum, vec4 vPhong)
{
    // whatever the .vbm's `glsl` field contains goes here; the stub is the
    // identity so a material with no custom code draws the lit fallback.
    return vec4(vAlbedo * (vAmbient + vLightAccum.rgb) + vPhong.rgb, 1.0);
}
'''


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description="show how the .vbm materials map onto the ported shaders")
    ap.add_argument("--materials", default="/home/user/vbmod_ref/materials")
    args = ap.parse_args(argv)
    mats = {p.stem: load(p) for p in sorted(Path(args.materials).glob("*.vbm"))}
    print(table(mats))
    print()
    print("field map (verbatim .vbm key -> ported shader knob):")
    for k, v in FIELD_MAP.items():
        print(f"  {k:<22} {v}")
    print()
    print(CUSTOM_GLSL_STUB)


if __name__ == "__main__":
    main()
