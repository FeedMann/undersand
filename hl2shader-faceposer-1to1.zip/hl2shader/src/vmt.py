"""
vmt.py -- a real reader for Valve Material Type files (VMT) and the QC-era
KeyValues dialect they use.  Also the parameter table used by the skin shader,
keeping Valve's VMT names ($phongfresnelranges) exactly as they are in the file.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# KeyValues tokenizer -- this is the actual VMT grammar, not a JSON hack
# ---------------------------------------------------------------------------
class KVError(Exception):
    pass


@dataclass
class Block:
    shader: str
    entries: dict = field(default_factory=dict)   # key -> str | Block
    order: list = field(default_factory=list)

    def get(self, key: str, default=None):
        return self.entries.get(key.lower(), default)

    def __contains__(self, key: str) -> bool:
        return key.lower() in self.entries


def _strip_comments(text: str) -> str:
    """Remove // line comments and /* */ blocks, but not inside quoted strings."""
    out, i, n = [], 0, len(text)
    in_str = False
    while i < n:
        c = text[i]
        if in_str:
            out.append(c)
            if c == '"':
                in_str = False
            i += 1
            continue
        if c == '"':
            in_str = True
            out.append(c)
            i += 1
            continue
        if text.startswith("//", i):
            j = text.find("\n", i)
            i = n if j < 0 else j
            continue
        if text.startswith("/*", i):
            j = text.find("*/", i + 2)
            i = n if j < 0 else j + 2
            continue
        out.append(c)
        i += 1
    return "".join(out)


_TOKEN = re.compile(r'"(?:\\.|[^"\\])*"|[{}]|[^\s{}"]+')


def parse(text: str) -> Block:
    tokens = _TOKEN.findall(_strip_comments(text))
    pos = 0

    def next_tok():
        nonlocal pos
        if pos >= len(tokens):
            raise KVError("unexpected EOF")
        t = tokens[pos]
        pos += 1
        if t.startswith('"'):
            t = t[1:-1].replace('\\"', '"').replace("\\\\", "\\")
        return t

    def parse_block(name=None, depth=0):
        if depth > 16:
            raise KVError("block nesting too deep")
        if name is None:
            name = next_tok()
        if next_tok() != "{":
            raise KVError(f"expected '{{' after '{name}'")
        blk = Block(shader=name)
        while True:
            t = next_tok()
            if t == "}":
                return blk
            key = t
            peek = tokens[pos] if pos < len(tokens) else None
            if peek == "{":
                next_tok()
                sub = parse_block(key, depth + 1)
                blk.entries[key.lower()] = sub
                blk.order.append(key)
            else:
                val = next_tok()
                blk.entries[key.lower()] = val
                blk.order.append(key)

    return parse_block()


def load(path: str, _seen=None) -> Block:
    """Load a VMT, following #base / #include like the engine does."""
    _seen = _seen or set()
    path = os.path.abspath(path)
    if path in _seen:
        raise KVError(f"include cycle at {path}")
    _seen.add(path)
    text = open(path, encoding="utf-8", errors="replace").read()

    # engine directives (#base "x.vmt" / #include "x.vmt"), patched into the block
    merged = Block(shader="__root__")
    for m in re.finditer(r'^\s*#(base|include)\s+"([^"]+)"', text, re.M):
        inc = os.path.join(os.path.dirname(path), m.group(2))
        for cand in (inc, inc + ".vmt"):
            if os.path.exists(cand):
                sub = load(cand, _seen)
                merged.entries.update(sub.entries)
                merged.shader = sub.shader
                break

    blk = parse(text)
    merged.entries.update(blk.entries)
    if blk.shader != "__root__":
        merged.shader = blk.shader
    merged.order = blk.order
    return merged


# ---------------------------------------------------------------------------
# VMT -> typed parameter values, following the skin shader's expectations
# ---------------------------------------------------------------------------
def _vec(s: str) -> tuple[float, ...]:
    s = s.strip().strip("{}[]()")
    return tuple(float(x) for x in s.replace(",", " ").split())


def _num(s: str) -> float:
    return float(str(s).strip().strip('"'))


DEFAULTS = {
    # name in VMT            default (as the shader treats an absent param)
    "$phong":                 0.0,      # bool
    "$phongexponent":         -1.0,     # -1 == "not defined" -> use the map
    "$phongboost":            1.0,
    "$phongfresnelranges":    (0.0, 0.5, 1.0),
    "$phongtint":             (1.0, 1.0, 1.0),
    "$phongalbedotint":       0.0,
    "$phongexponentfactor":   0.0,
    "$phongwarptexture":      None,
    "$lightwarptexture":      None,
    "$halflambert":           0.0,
    "$basemapalphaphongmask": 0.0,
    "$invertphongmask":       0.0,
    "$rimlight":              0.0,
    "$rimmask":               0.0,
    "$rimlightpower":         4.0,
    "$rimlightboost":         1.0,
    "$envmap":                None,
    "$envmapfresnel":         0.0,
    "$basetexture":           None,
    "$bumpmap":               None,
    "$detail":                None,
    "$nodecal":               0.0,
    "$model":                 0.0,
    "$nofog":                 0.0,
    "$selfillum":             0.0,
    "$selfillumfresnel":      0.0,
    "$color":                 (1.0, 1.0, 1.0),
}

VECTOR_PARAMS = {"$phongfresnelranges", "$phongtint", "$color", "$envmaptint"}
TEXTURE_PARAMS = {"$basetexture", "$bumpmap", "$phongexponenttexture", "$lightwarptexture",
                  "$phongwarptexture", "$detail", "$envmap", "$selfillummask", "$iris",
                  "$corneatexture", "$ambientoccltexture"}


@dataclass
class Material:
    name: str
    shader: str
    values: dict
    raw: Block
    source_path: str = ""

    def __getitem__(self, k):
        return self.values[k]

    def get(self, k, d=None):
        return self.values.get(k.lower(), d)

    def has_texture(self, k: str) -> bool:
        v = self.values.get(k.lower())
        return bool(v)

    def summary(self) -> str:
        keys = ["$phong", "$phongexponenttexture", "$phongexponent", "$phongboost",
                "$phongfresnelranges", "$bumpmap", "$lightwarptexture", "$halflambert",
                "$basemapalphaphongmask", "$rimlight"]
        lines = [f"{self.name}  [{self.shader}]"]
        for k in keys:
            if k in self.values:
                lines.append(f"    {k:24s} = {self.values[k]!r}")
        return "\n".join(lines)


def load_material(path: str) -> Material:
    blk = load(path)
    vals = dict(DEFAULTS)
    for k, v in blk.entries.items():
        if isinstance(v, Block):
            continue
        if k in TEXTURE_PARAMS or k.endswith("texture") or k in ("$envmap",):
            vals[k] = str(v).strip().strip('"')
        elif k in VECTOR_PARAMS:
            vals[k] = _vec(str(v))
        else:
            try:
                vals[k] = _num(v)
            except ValueError:
                vals[k] = str(v).strip('"')
    # known derived rules from the engine
    if vals.get("$phongalbedotint"):
        vals["$phongtint"] = (1.0, 1.0, 1.0)
    return Material(name=os.path.basename(path), shader=blk.shader, values=vals,
                    raw=blk, source_path=path)
