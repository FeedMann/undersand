"""
trace.py -- the "verbose" part: one pixel, every intermediate term, in order.

This is a deliberately separate scalar implementation of the same shader so that
each intermediate value can be printed and checked against the HLSL line that
produced it.  If the numbers here disagree with shader.py's vectorised CPU path
or the GPU, something is wrong -- and that is the point.
"""
from __future__ import annotations

import os

import numpy as np

from shader import sample2d


def _f(x):
    return f"{float(x): .6f}"


def trace_pixel(px, gbuf, uniforms, textures, lights, cube, label="", out=None):
    """px: (y, x).  Returns a dict summary; appends the full text to `out`."""
    y, x = px
    lines = []

    def L(s=""):
        lines.append(s)

    pos = gbuf["worldPos"][y, x].astype(float)
    Ngeo = gbuf["normal"][y, x].astype(float)
    T = gbuf["T"][y, x].astype(float)
    B = gbuf["B"][y, x].astype(float)
    uv = gbuf["uv"][y, x].astype(float)

    u = uniforms
    base = sample2d(textures["base"], uv.reshape(1, 1, 2))[0, 0].astype(float)
    nrm = sample2d(textures["normal"], uv.reshape(1, 1, 2))[0, 0].astype(float)
    exp_tex = sample2d(textures["exponent"], uv.reshape(1, 1, 2))[0, 0].astype(float)

    eye = np.asarray(u["EyePos_SpecExponent"], float)[:3]
    ranges_encoded = np.asarray(u["FresnelRanges_SpecBoost"], float)
    boost = ranges_encoded[3]
    tint_reg = np.asarray(u["SpecularRimParams"], float)
    cube = np.asarray(cube, float)

    L(f"{'='*92}")
    L(f"PIXEL TRACE  {label}   pixel (x={x}, y={y})")
    L(f"{'='*92}")
    L(f"g-buffer")
    L(f"  worldPos        = {np.round(pos,4)}")
    L(f"  uv              = {np.round(uv,4)}   -> texel ({uv[0]*768:.1f}, {uv[1]*768:.1f})")
    L(f"  N (geometric)   = {np.round(Ngeo,4)}")
    L(f"  T               = {np.round(T,4)}")
    L(f"  B               = {np.round(B,4)}")

    L(f"\n1. texture fetches  (skin_ps20b.fxc:190-200)")
    L(f"   $basetexture          rgb = {np.round(base[:3],4)}   a = {_f(base[3])}")
    L(f"   $bumpmap              rgb = {np.round(nrm[:3],4)}   a = {_f(nrm[3])}")
    L(f"   $phongexponenttexture r   = {_f(exp_tex[0])}   g(tint) = {_f(exp_tex[1])}   a(rim) = {_f(exp_tex[2])}")

    tsn = 2.0 * nrm[:3] - 1.0
    L(f"\n2. tangent-space normal = 2*rgb - 1  ->  {np.round(tsn,4)}")
    bmap = u["ShaderControls"][0]
    if bmap:
        tsn = tsn * (1 - bmap) + np.array([0, 0, 1.0]) * bmap
        L(f"   $basemapalphaphongmask = {bmap}: normal flattened to {np.round(tsn,4)}")
    fSpecMask = nrm[3]
    L(f"   PHONG MASK = alpha of the bumpmap = {_f(fSpecMask)}   <- 'Phong Mask' box in the shader tree")

    WN = T * tsn[0] + B * tsn[1] + Ngeo * tsn[2]
    WN /= max(np.linalg.norm(WN), 1e-9)
    L(f"\n3. world normal = T*x + B*y + N*z, normalised = {np.round(WN,4)}")

    V = eye - pos
    dist_eye = np.linalg.norm(V)
    V /= max(dist_eye, 1e-9)
    NdotV = float(np.dot(WN, V))
    L(f"\n4. view vector V = normalize(eye - pos),  |eye-pos| = {_f(dist_eye)}")
    L(f"   N.V = {_f(NdotV)}")

    lo, mid, hi = (ranges_encoded[0], ranges_encoded[1], ranges_encoded[2])
    # undo the packing the CPU-side helper applies, to show both forms
    min_ = mid - lo / 2.0
    max_ = hi / 2.0 + mid
    L(f"\n5. fresnel   (skin_dx9_helper.cpp re-encodes the VMT values)")
    L(f"   VMT            $phongfresnelranges = [{min_:.3f} {mid:.3f} {max_:.3f}]")
    L(f"   register       g_FresnelRanges     = [{lo:.3f} {mid:.3f} {hi:.3f}]   ((mid-min)*2, mid, (max-mid)*2)")
    f = max(0.0, min(1.0, 1.0 - NdotV))
    f2 = f * f
    fenc = f2 - 0.5
    fres = mid + (hi if fenc >= 0.0 else lo) * fenc
    L(f"   f  = saturate(1 - N.V) = {_f(f)}")
    L(f"   f*f - 0.5              = {_f(fenc)}      -> branch {'high' if fenc>=0 else 'low'}")
    L(f"   fresnel                = {_f(fres)}")

    L(f"\n6. diffuse: 'Light Source Parameters' (common_vertexlitgeneric_dx9.h DiffuseTerm)")
    half_lambert = u.get("HALFLAMBERT", True)
    diffuse_sum = np.zeros(3)
    for i, (lp, lc) in enumerate(lights):
        d = np.asarray(lp, float) - pos
        dd = float(np.dot(d, d))
        dist = float(np.sqrt(dd))
        Ld = d / max(dist, 1e-9)
        atten = 1.0 / (1.0 + 0.06 * dd)
        ndotl_raw = float(np.dot(WN, Ld))
        fr = max(0.0, min(1.0, ndotl_raw * 0.5 + 0.5))
        fr = fr * fr
        term = np.asarray(lc, float) * atten * fr
        diffuse_sum += term
        L(f"   light[{i}]  dist = {_f(dist)}  atten = 1/(1+0.06d^2) = {_f(atten)}")
        L(f"             L = {np.round(Ld,4)}   raw N.L = {_f(ndotl_raw)}")
        L(f"             half-lambert saturate(N.L*0.5+0.5) = {_f(fr)} (squared: no lightwarp on this material)")
        L(f"             contribution = {np.round(term,5)}")
    # ambient cube
    n2 = WN * WN
    L(f"   ambient cube  (cAmbientCube: [0]=+x [1]=-x [2]=+y [3]=-y [4]=+z [5]=-z):")
    # index = 2*axis + (component < 0) -- the pixel-shader form of AmbientLight()
    sel = [0 if WN[0] >= 0 else 1, 2 if WN[1] >= 0 else 3, 4 if WN[2] >= 0 else 5]
    for ci in range(6):
        L(f"     [{ci}] {'+-'[0 if ci % 2 == 0 else 1]}{'xyz'[ci // 2]}  {np.round(cube[ci],5)}"
          + ("   <- used (N component sign matches)" if ci in sel else ""))
    amb = n2[0] * cube[sel[0]] + n2[1] * cube[sel[1]] + n2[2] * cube[sel[2]]
    L(f"   ambient = n.x^2*cube[{sel[0]}] + n.y^2*cube[{sel[1]}] + n.z^2*cube[{sel[2]}] = {np.round(amb,5)}")
    diffuse = diffuse_sum + amb
    L(f"   total diffuse lighting = {np.round(diffuse,5)}")

    L(f"\n7. specular exponent  (skin_ps20b.fxc:266-268)")
    w = float(np.asarray(u["EyePos_SpecExponent"], float)[3])
    L(f"   g_EyePos_SpecExponent.w = {_f(w)}  ({'constant from $phongexponent' if w >= 0 else '-1 => use the map'})")
    spec_exp = 1.0 + 149.0 * exp_tex[0]
    L(f"   fSpecExp = 1 + 149 * exponentTexel.r = 1 + 149*{_f(exp_tex[0])} = {_f(spec_exp)}")
    L(f"   (a high exponent = a tight hotspot; the wiki's '0-255 maps to 1-150')")

    L(f"\n8. specular  (SpecularAndRimTerms)")
    R = 2.0 * WN * np.dot(WN, V) - V
    spec_total = np.zeros(3)
    for i, (lp, lc) in enumerate(lights):
        d = np.asarray(lp, float) - pos
        dd = float(np.dot(d, d))
        Ld = d / max(np.sqrt(dd), 1e-9)
        atten = 1.0 / (1.0 + 0.06 * dd)
        LdotR = max(0.0, min(1.0, float(np.dot(R, Ld))))
        ndotl = max(0.0, min(1.0, float(np.dot(WN, Ld))))
        p = LdotR ** spec_exp
        contrib = np.asarray(lc, float) * atten * (p * ndotl)
        spec_total += contrib
        L(f"   light[{i}]  R = 2N(N.V) - V       = {np.round(R,4)}")
        L(f"             L.R = {_f(LdotR)}   saturate(N.L) = {_f(ndotl)}")
        L(f"             pow(L.R, fSpecExp) = {_f(p)}   {'<- tight hotspot' if p < 0.05 else ''}")
        L(f"             contribution = {np.round(contrib,6)}")

    L(f"\n9. masking, boost, tint  (skin_ps20b.fxc:310-316)")
    masked = fSpecMask * fres
    L(f"   fSpecMask *= fFresnelRanges       = {_f(fSpecMask)} * {_f(fres)} = {_f(masked)}")
    boosted = spec_total * masked * boost
    L(f"   specular *= fSpecMask * $phongboost({_f(boost)}) = {np.round(boosted,6)}")
    tint_const = tint_reg[:3]
    if tint_const[0] >= 0.0:
        tint = tint_const
        L(f"   vSpecularTint = $phongtint = {np.round(tint,3)}")
    else:
        tint = base[:3]
        L(f"   vSpecularTint = albedo (via exponent green channel) = {np.round(tint,3)}")

    L(f"\n10. FINAL LIGHTING")
    diff_comp = diffuse * base[:3]
    L(f"   Final Diffuse  = diffuse * albedo = {np.round(diff_comp,6)}")
    L(f"   Specular Term  = specular * tint  = {np.round(boosted * tint,6)}")
    result = boosted * tint + diff_comp
    L(f"   result                             = {np.round(result,6)}")
    tonemapped = result * 1.15
    tonemapped = tonemapped / (1.0 + tonemapped)
    tonemapped = np.power(np.clip(tonemapped, 0, None), 1 / 2.2)
    L(f"   after exposure+tonemap+gamma       = {np.round(tonemapped,4)}  (sRGB {np.round(tonemapped*255).astype(int)})")

    text = "\n".join(lines)
    if out:
        with open(out, "a") as fh:
            fh.write(text + "\n\n")
    else:
        print(text)

    return {
        "label": label, "pixel": [int(x), int(y)],
        "phong_mask": float(fSpecMask), "fresnel": float(fres),
        "spec_exp": float(spec_exp), "boost": float(boost),
        "specular": [float(v) for v in boosted],
        "diffuse_component": [float(v) for v in diff_comp],
        "result": [float(v) for v in result],
    }


def _find_pixels(gbuf, uniforms, textures, lights, cube):
    """Pick pixels that show off different parts of the shader.

    The first entry is deliberately the pixel with the *brightest specular*, not
    the strongest mask: the mask is a multiplier, so a trace taken where L.R
    happens to be zero teaches the masking maths and nothing about the highlight.
    """
    h, w = gbuf["uv"].shape[:2]
    nrm_tex = sample2d(textures["normal"], gbuf["uv"])
    nrm = nrm_tex[..., 3]
    mask = np.abs(gbuf["worldPos"]).sum(-1) > 1e-6
    picks = []

    # 0. the actual highlight: reconstruct the specular term and take its peak
    tsn = 2.0 * nrm_tex[..., :3] - 1.0
    wn = gbuf["T"] * tsn[..., 0:1] + gbuf["B"] * tsn[..., 1:2] + gbuf["normal"] * tsn[..., 2:3]
    wn /= np.maximum(np.linalg.norm(wn, axis=-1, keepdims=True), 1e-9)
    eye = np.asarray(uniforms["EyePos_SpecExponent"][:3], np.float32)
    V = eye[None, None, :] - gbuf["worldPos"]
    V /= np.maximum(np.linalg.norm(V, axis=-1, keepdims=True), 1e-9)
    exp_tex = sample2d(textures["exponent"], gbuf["uv"])
    wgt = float(uniforms["EyePos_SpecExponent"][3])
    exp_field = (1.0 + wgt * exp_tex[..., 0]) if wgt > 0.0 else (1.0 + 149.0 * exp_tex[..., 0])
    spec = np.zeros(wn.shape[:-1], np.float32)
    for pos, col in lights:
        L = pos[None, None, :] - gbuf["worldPos"]
        L /= np.maximum(np.linalg.norm(L, axis=-1, keepdims=True), 1e-9)
        R = 2.0 * wn * np.sum(wn * V, -1)[..., None] - V
        LdotR = np.clip(np.sum(R * L, -1), 0.0, 1.0)
        spec += float(np.max(col)) * (LdotR ** exp_field) * np.clip(np.sum(wn * L, -1), 0, 1)
    loc = np.where(mask, spec, -1.0)
    y0, x0 = np.unravel_index(np.argmax(loc), loc.shape)
    picks.append(((y0, x0), f"THE HIGHLIGHT (specular peak; mask here = {nrm[y0, x0]:.3f})"))

    m = np.where(mask, nrm, -1)
    # 1. strongest phong mask on the model
    y, x = np.unravel_index(np.argmax(m), m.shape)
    picks.append(((y, x), "hairband/lips: strongest phong mask"))
    # 2. a mid-mask skin pixel (broad sheen)
    mm = np.where(mask, np.where((nrm > 0.15) & (nrm < 0.4), nrm, -1), -1)
    if (mm > 0).any():
        y2, x2 = np.unravel_index(np.argmax(mm), mm.shape)
        picks.append(((y2, x2), "skin: mid mask, broad sheen"))
    # 3. zero mask (eyelid / cloth)
    zz = np.where(mask, np.where(nrm < 0.02, 1.0, -1), -1)
    if (zz > 0).any():
        ys, xs = np.argwhere(zz > 0)[0]
        picks.append(((int(ys), int(xs)), "matte zone: phong mask ~ 0"))
    return picks


def pick_and_trace(gbuf, cpu, uniforms, textures, lights, cube, path):
    summaries = []
    with open(path, "w") as fh:
        fh.write("Per-pixel traces of the ported skin shader (Ep1 material, $phong path).\n")
        fh.write("Every line corresponds to a line of skin_ps20b.fxc / "
                 "common_vertexlitgeneric_dx9.h.\n\n")
    for px, label in _find_pixels(gbuf, uniforms, textures, lights, cube):
        summaries.append(trace_pixel(px, gbuf, uniforms, textures, lights, cube,
                                     label=label, out=path))
    return summaries
