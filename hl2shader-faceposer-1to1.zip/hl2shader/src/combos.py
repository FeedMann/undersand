"""
combos.py -- the part modders never see laid out in one place.

A Source shader is not one program: it is a *family* of programs selected by
#defines ("combos").  vertexlitgeneric_dx9_helper.cpp and skin_dx9_helper.cpp
decide which combos are on, then shadercompile.exe compiles one .vcs binary per
combination actually used.  This module reproduces that decision logic in
Python, and the constant-register packing that goes with it.

References (line numbers from the public SDK tree):
  vertexlitgeneric_dx9_helper.cpp : WantsSkinShader(), DrawVertexLitGeneric_DX9()
  skin_dx9_helper.cpp             : InitParamsSkin_DX9(), constant packing at ~805-935
"""
from __future__ import annotations

from dataclasses import dataclass, asdict

from vmt import Material


# ---------------------------------------------------------------------------
# Hardware / config gate -- mirrors g_pHardwareConfig + g_pConfig
# ---------------------------------------------------------------------------
@dataclass
class HWConfig:
    ps_2_b: bool = True          # SupportsPixelShaders_2_b()
    use_bumpmapping: bool = True  # g_pConfig->UseBumpmapping()  (mat_bumpmap)
    use_phong: bool = True        # g_pConfig->UsePhong()        (mat_phong)


@dataclass
class Combos:
    # these names are the literal STATIC/DYNAMIC combo names out of the .fxc headers
    SKIN: bool = False                    # <- "am I in skin_ps20b.fxc at all"
    WRINKLEMAP: bool = False
    LIGHTWARPTEXTURE: bool = False
    PHONGWARPTEXTURE: bool = False
    PHONG_USE_EXPONENT_FACTOR: bool = False
    RIMLIGHT: bool = False
    DETAILTEXTURE: bool = False
    DETAIL_BLEND_MODE: int = 0
    SELFILLUM: bool = False
    SELFILLUMFRESNEL: bool = False
    CUBEMAP: bool = False
    NORMALMAPALPHAENVMAPMASK: bool = False
    HALFLAMBERT: bool = False
    FLASHLIGHT: bool = False
    FASTPATH_NOBUMP: bool = False
    INVERTPHONGMASK: bool = False
    BASEMAPALPHAPHONGMASK: bool = False
    BLENDTINTBYBASEALPHA: bool = False

    def defines(self) -> dict[str, str]:
        out = {}
        for k, v in asdict(self).items():
            out[k] = ("1" if v else "0") if isinstance(v, bool) else str(v)
        return out

    def active(self) -> list[str]:
        return [k for k, v in asdict(self).items() if v not in (False, 0)]


def wants_skin_shader(m: Material, hw: HWConfig = HWConfig()) -> bool:
    """Transliteration of WantsSkinShader() from vertexlitgeneric_dx9_helper.cpp."""
    if m.get("$phong") is None:
        return False
    if m["$phong"] == 0:
        return False
    # phong + diffuse warp  => skin
    if m.has_texture("$lightwarptexture"):
        return True
    # note the real test: BaseMapAlphaPhongMask != 1 means "use the bumpmap's alpha",
    # so a bump map must actually be present
    if m.get("$basemapalphaphongmask", 0) != 1:
        if not m.has_texture("$bumpmap"):
            return False
    return True


def resolve(m: Material, hw: HWConfig = HWConfig()) -> tuple[Combos, dict]:
    """Returns (combos, packed_uniforms).  packed_uniforms mirrors the
    SetPixelShaderConstant() calls in skin_dx9_helper.cpp."""
    c = Combos()

    phong_on = bool(m["$phong"]) and hw.use_phong and hw.ps_2_b
    if m["$phong"] and not (hw.use_phong and hw.ps_2_b):
        # this is the engine's silent degrade: params[m_nPhong]->SetIntValue(0)
        m.values["$phong"] = 0.0

    c.SKIN = wants_skin_shader(m, hw) and hw.use_bumpmapping and hw.use_phong and hw.ps_2_b
    c.HALFLAMBERT = bool(m["$halflambert"])
    c.NORMALMAPALPHAENVMAPMASK = m.has_texture("$envmap") and bool(m.get("$normalmapalphaenvmapmask", 0))
    c.CUBEMAP = m.has_texture("$envmap")
    c.RIMLIGHT = bool(m["$rimlight"])
    c.INVERTPHONGMASK = bool(m["$invertphongmask"])
    c.BASEMAPALPHAPHONGMASK = bool(m.get("$basemapalphaphongmask", 0))
    c.DETAILTEXTURE = m.has_texture("$detail")
    c.SELFILLUM = bool(m["$selfillum"])
    c.SELFILLUMFRESNEL = c.SELFILLUM and bool(m["$selfillumfresnel"])

    # skin_ps20b.fxc: SET_STATIC_PIXEL_SHADER_COMBO( LIGHTWARPTEXTURE, bHasDiffuseWarp && bHasPhong )
    c.LIGHTWARPTEXTURE = bool(c.SKIN and m.has_texture("$lightwarptexture"))
    c.PHONGWARPTEXTURE = bool(c.SKIN and m.has_texture("$phongwarptexture"))
    c.WRINKLEMAP = bool(c.SKIN and m.get("$wrinklemap", 0))

    # $phongexponentfactor -> the dynamic combo PHONG_USE_EXPONENT_FACTOR
    foc = float(m.get("$phongexponentfactor", 0) or 0)
    c.PHONG_USE_EXPONENT_FACTOR = foc != 0.0

    # a material with no $bumpmap still needs a ps_2_b program (FASTPATH_NOBUMP)
    c.FASTPATH_NOBUMP = c.SKIN and not m.has_texture("$bumpmap")

    # ---------------- constant register packing ----------------
    u: dict = {}

    # PSREG_EYEPOS_SPEC_EXPONENT : xyz = eye pos, w = $phongexponent
    #   default -1.f means "no constant exponent, use the texture"
    spec_exp = -1.0
    if "phongexponent" in m.raw.entries:
        try:
            v = float(str(m.raw.entries["phongexponent"]).strip('"'))
            if v > 0.0:
                spec_exp = v
        except ValueError:
            pass
    if c.PHONG_USE_EXPONENT_FACTOR:
        spec_exp = foc
    u["EyePos_SpecExponent"] = [0.0, 0.0, 0.0, spec_exp]   # xyz filled at draw time

    # PSREG_FRESNEL_SPEC_PARAMS : xyz = re-encoded fresnel ranges, w = $phongboost
    lo, mid, hi = m["$phongfresnelranges"]
    u["FresnelRanges_SpecBoost"] = [
        (mid - lo) * 2.0,     # <- the encoding change: (min,mid,max) -> ((mid-min)*2, mid, (max-mid)*2)
        mid,
        (hi - mid) * 2.0,
        float(m["$phongboost"]),
    ]

    # PSREG_SPEC_RIM_PARAMS : xyz = $phongtint, w = $rimlightpower (>=1)
    tint = list(m["$phongtint"])
    if m.get("$phongalbedotint", 0):
        tint = [-1.0, -1.0, -1.0]        # negative => "tint with albedo via exponent green channel"
    rim_power = max(float(m.get("$rimlightpower", 4.0)), 1.0)
    u["SpecularRimParams"] = tint + [rim_power]

    # PSREG_FLASHLIGHT_POSITION_RIM_BOOST : xyz = flashlight pos, w = $rimlightboost
    u["FlashlightPos_RimBoost"] = [0.0, 0.0, 0.0, float(m.get("$rimlightboost", 1.0))]

    # PSREG_FLASHLIGHT_ATTENUATION : on a non-flashlight pass, x = $rimmask
    rim_mask = float(m["$rimmask"]) if m.has_texture("$phongexponenttexture") else 0.0
    u["FlashlightAttenuation_RimMask"] = [rim_mask, 0.0, 0.0, 0.0]

    # PSREG_CONSTANT_27 : x = basemapAlphaPhongMask, y = 1-blendtint, z = tintoverlay, w = invertphongmask
    u["ShaderControls"] = [
        1.0 if c.BASEMAPALPHAPHONGMASK else 0.0,
        0.0, 0.0,
        1.0 if c.INVERTPHONGMASK else 0.0,
    ]

    # PSREG_ENVMAP_TINT__SHADOW_TWEAKS : rgb = $envmaptint, w = envmap mask control
    #   In skin_ps20b.fxc:
    #       float fEnvMapMask = lerp( baseColor.a, fSpecMask, g_EnvmapTint_ShadowTweaks.w );
    #   so w = 1 selects the *bumpmap alpha* as the mask -- which is exactly what
    #   $normalmapalphaenvmapmask asks for, and is how the 2004 face material
    #   gets its masked "shine" on the hairband without any $phong at all.
    #   (The non-skin path spells the same idea out:
    #       if ( bNormalMapAlphaEnvmapMask ) specularFactor = normalTexel.a;
    #    in vertexlit_and_unlit_generic_bump_ps2x.fxc:165-170.)
    env_tint = list(m["$envmaptint"]) if m.has_texture("$envmap") else [1.0, 1.0, 1.0]
    mask_control = 1.0 if m.get("$normalmapalphaenvmapmask", 0) else 0.0
    u["EnvmapTint_ShadowTweaks"] = env_tint + [mask_control]

    # PSREG_ENVMAP_FRESNEL__SELFILLUMMASK : x = $envmapfresnel
    #   envMapColor = (ENV_MAP_SCALE * lerp(1, fFresnelRanges, g_EnvMapFresnel.x) * ...)
    u["EnvMapFresnel_SelfIllumMask"] = [float(m.get("$envmapfresnel", 0.0)), 0.0, 0.0, 0.0]

    u["DiffuseModulation"] = list(m["$color"]) + [1.0]
    return c, u


def describe(m: Material, hw: HWConfig = HWConfig()) -> str:
    c, u = resolve(m, hw)
    lines = [f"combos for {m.name} ({m.source_path})",
             f"  path        : {'skin_ps20b.fxc' if c.SKIN else 'vertexlit_and_unlit_generic_ps2x.fxc'}",
             f"  active      : {', '.join(c.active()) or '(none)'}"]
    for k, v in u.items():
        lines.append(f"  {k:32s} = {v}")
    return "\n".join(lines)
