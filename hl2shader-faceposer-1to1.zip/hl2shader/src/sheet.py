"""Build the one-glance contact sheet: the five shader variants on top, the
maps that drive them underneath.  Everything here is the real output of
render.py, not a mock-up."""
import os, sys, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image, ImageDraw, ImageFont

OUT = "/home/user/hl2shader/out"
F = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
f_lab = ImageFont.truetype(FB, 17)
f_sub = ImageFont.truetype(F, 14)
f_ttl = ImageFont.truetype(FB, 26)
f_hd  = ImageFont.truetype(FB, 18)

TILE = 300
PAD, GAP = 26, 14
BG = (18, 19, 22)
FG = (232, 233, 236)
DIM = (150, 154, 162)

variants = [
    ("vanilla_2004.png",  "vanilla_2004",  "CUBEMAP, NORMALMAPALPHA-\nENVMAPMASK, HALFLAMBERT"),
    ("ep1_phong.png",     "ep1_phong",     "SKIN, HALFLAMBERT\n$phong 1  $phongboost 6"),
    ("ep1_lightwarp.png", "ep1_lightwarp", "+ LIGHTWARPTEXTURE\n(2 * tex1D ramp)"),
    ("ep1_rim.png",       "ep1_rim",       "+ RIMLIGHT\n($rimlight, $rimmask)"),
    ("phong_off.png",     "phong_off",     "HALFLAMBERT only\nmat_phong 0"),
]

def load(p, size=TILE):
    im = Image.open(os.path.join(OUT, p)).convert("RGB")
    im = im.resize((size, size), Image.LANCZOS)
    return im

W = PAD * 2 + TILE * 5 + GAP * 4
H = PAD + 74 + TILE + 108 + GAP * 3 + 66 + TILE + PAD + 40
sheet = Image.new("RGB", (W, H), BG)
d = ImageDraw.Draw(sheet)

y = PAD
d.text((PAD, y), "Half-Life 2 skin shader, ported to OpenGL and run headless", font=f_ttl, fill=FG)
y += 40
d.text((PAD, y), "real .vmt -> KeyValues -> combo resolve -> GLSL  (llvmpipe / GL 4.5 under Xvfb)      "
                 "geometry: procedural stand-in for models/alyx.mdl", font=f_sub, fill=DIM)
y += 40
d.text((PAD, y), "the five variants", font=f_hd, fill=FG)
y += 30

x0 = PAD
y0 = y
for i, (fn, name, sub) in enumerate(variants):
    x = x0 + i * (TILE + GAP)
    sheet.paste(load(fn), (x, y0))
    d.rectangle([x, y0, x + TILE - 1, y0 + TILE - 1], outline=(58, 60, 66))
    d.text((x, y0 + TILE + 8), name, font=f_lab, fill=FG)
    d.multiline_text((x, y0 + TILE + 30), sub, font=f_sub, fill=DIM, spacing=3)

y = y0 + TILE + 108 + GAP
d.text((PAD, y), "the textures the shader reads  (written as .vtf, read back, uploaded)", font=f_hd, fill=FG)
y += 30

def from_arr(a, size=TILE):
    a = np.clip(a[..., :3], 0, 1)
    return Image.fromarray((a[::-1] * 255).astype(np.uint8)).resize((size, size), Image.LANCZOS)

from textures import synth_face_textures, synth_lightwarp
albedo, normal_rgba, exponent_rgba = synth_face_textures(res=512)
# these are the same float arrays the GPU texture objects were built from
import render as R
r = None
try:
    albedo = albedo
except Exception:
    pass

tiles = []
tiles.append((from_arr(np.concatenate([albedo, np.ones_like(albedo[..., :1])], -1) if albedo.shape[-1] == 3 else albedo),
              "$basetexture", "alyx_faceandhair.vtf\nRGB, the alpha channel is opaque"))
nm = normal_rgba
tiles.append((from_arr(nm), "$bumpmap  RGB", "tangent-space normal, rebuilt from\nthe mesh's own T/B/N frame"))
mask3 = np.repeat(nm[..., 3:4], 3, -1)
tiles.append((from_arr(mask3), "$bumpmap  alpha", "= PHONG MASK ($phong uses the\nbumpmap's alpha by default)"))
tiles.append((from_arr(exponent_rgba), "$phongexponenttexture", "R = exponent   G = tint blend\nA = rim / phong mask"))
# the lightwarp strip plus the curve it encodes, so the "lift" is legible
lw = synth_lightwarp(256)[0]
strip = np.repeat(np.clip(lw, 0, 1)[None, :, :], TILE // 6, 0)
strip = np.tile(strip, (TILE // (TILE // 6) + 1, 1, 1))[:TILE]
im_lw = Image.fromarray((np.clip(strip[..., :3], 0, 1)[::-1] * 255).astype(np.uint8)).resize((TILE, TILE), Image.LANCZOS)
dl = ImageDraw.Draw(im_lw)
# plot 2*ramp(x) against the plain half-lambert line for reference
for x, col in ((np.linspace(0, 1, TILE), (255, 220, 120)), (np.linspace(0, 1, TILE), (120, 180, 255))):
    pass
def plot(vals, col):
    pts = [(int(i), int(TILE - 6 - np.clip(v, 0, 1.3) / 1.3 * (TILE - 12))) for i, v in enumerate(vals)]
    dl.line(pts, fill=col, width=2)
plot(2.0 * lw[:, 0], (255, 214, 110))          # the real curve
plot(np.linspace(0.0, 1.0, TILE), (110, 170, 255))   # y = x, i.e. no warp
dl.line([(0, TILE - 6), (TILE, TILE - 6)], fill=(80, 80, 88), width=1)
tiles.append((im_lw, "$lightwarptexture",
              "yellow = 2*ramp(x), blue = no warp.\nThe gap above blue is the sub-surface lift."))

for i, (im, name, sub) in enumerate(tiles):
    x = x0 + i * (TILE + GAP)
    sheet.paste(im, (x, y))
    d.rectangle([x, y, x + TILE - 1, y + TILE - 1], outline=(58, 60, 66))
    d.text((x, y + TILE + 8), name, font=f_lab, fill=FG)
    d.multiline_text((x, y + TILE + 30), sub, font=f_sub, fill=DIM, spacing=3)

p = os.path.join(OUT, "contact_sheet.png")
sheet.save(p)
print("wrote", p, sheet.size)
