"""
model.py -- the stand-in for Alyx's head.

Alyx's real model is `models/alyx.mdl` inside the game VPKs; it is not
redistributable and is not downloaded here.  What this file provides instead is
a procedural head that is *built the way her model is built*, so the shader port
has something to shade that exercises the same code paths:

  * a parametric UV sphere-ish skull with the face centred on u = 0.5 so the
    face lives in the region a Source face texture would occupy,
  * explicit per-vertex tangent / bitangent vectors, so
    tangent-space normals resolve into world space exactly the way
    `mul( i.tangentSpaceTranspose, tangentSpaceNormal )` does in HLSL,
  * broad geometric features (brow ridge, nose, chin, cheekbones, ears) and a
    raised hairband band, matching the shiny region in Alyx's phong mask,
  * everything finer than a few mesh columns is left to the $bumpmap, which is
    how a real Source model achieves its detail: a smooth cage plus a normal map.

The mesh is deliberately low-poly-by-today's-standards (96 x 72 quads, ~7k
verts) because that is the ballpark of the 2004-2007 character models.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np


@dataclass
class Mesh:
    positions: np.ndarray
    normals: np.ndarray
    uvs: np.ndarray
    tangents: np.ndarray
    bitangents: np.ndarray
    indices: np.ndarray

    @property
    def bounds(self):
        return self.positions.min(0), self.positions.max(0)

    @property
    def num_tris(self):
        return self.indices.shape[0] // 3


def _smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def _gauss(u, v, cu, cv, su, sv, wrap=True):
    """Separable gaussian bump in UV space.  wrap=True folds u around, so a
    bump authored at u = 0.5 does not leak across the seam at u = 0/1."""
    du = u - cu
    if wrap:
        du = (du + 0.5) % 1.0 - 0.5
    return np.exp(-(du / su) ** 2 - ((v - cv) / sv) ** 2)


def head_position(u: np.ndarray, v: np.ndarray, detail: float = 1.0) -> np.ndarray:
    """Parametric head surface.  u: [0,1) longitude (0.5 = front of face),
    v: [0,1] from bottom of neck to crown."""
    theta = (u - 0.5) * 2.0 * math.pi          # 0 at the front
    phi = (v - 0.5) * math.pi                  # -pi/2 (bottom) .. +pi/2 (top)

    # base ellipsoid, skull-ish
    x = np.sin(theta) * np.cos(phi)
    y = np.sin(phi)
    z = -np.cos(theta) * np.cos(phi)

    x *= 0.82                                   # narrow left-right
    y *= 1.06                                   # longer top-bottom
    z *= 0.94

    # flatten the back of the skull
    back = np.clip(-z, 0, None)
    z += 0.10 * back * _smoothstep(0.45, 0.95, v)

    # taper the jaw / narrow the chin (lower v)
    taper = 0.62 + 0.38 * _smoothstep(0.05, 0.40, v)
    x *= taper

    # neck: shrink the very bottom
    x *= 0.55 + 0.45 * _smoothstep(0.0, 0.14, v)
    z *= 0.55 + 0.45 * _smoothstep(0.0, 0.14, v)
    y += 0.20 * _smoothstep(0.14, 0.0, v)

    if detail:
        d = np.zeros_like(x)
        # brow ridge
        d += 0.030 * _gauss(u, v, 0.5, 0.610, 0.135, 0.030)
        d -= 0.026 * _gauss(u, v, 0.5, 0.560, 0.150, 0.045)   # eye sockets
        # cheekbones
        d += 0.020 * _gauss(u, v, 0.5 - 0.075, 0.480, 0.075, 0.070)
        d += 0.020 * _gauss(u, v, 0.5 + 0.075, 0.480, 0.075, 0.070)
        # nose bridge + tip (kept >= 5 mesh columns wide so the sampled surface
        # stays smooth -- the fine structure lives in the $bumpmap instead)
        d += 0.070 * _gauss(u, v, 0.5, 0.470, 0.052, 0.130)
        d += 0.062 * _gauss(u, v, 0.5, 0.400, 0.058, 0.042)
        d -= 0.030 * _gauss(u, v, 0.5, 0.352, 0.070, 0.030)   # under-nose
        # lips
        d += 0.024 * _gauss(u, v, 0.5, 0.318, 0.060, 0.028)
        d -= 0.012 * _gauss(u, v, 0.5, 0.300, 0.055, 0.012)   # mouth line
        # chin
        d += 0.018 * _gauss(u, v, 0.5, 0.240, 0.070, 0.055)
        # raised hairband (matches the shiny band in her phong mask)
        band = np.exp(-((v - 0.815) / 0.028) ** 2)
        # cos() instead of |u-0.5| : np.abs() puts a C1 kink down the centre of
        # the face, which shows up as a crease line in the shaded normal
        frontness = np.cos((u - 0.5) * 2.0 * np.pi)
        d += 0.030 * band * _smoothstep(0.10, 0.30, frontness)
        # ears
        d += 0.045 * _gauss(u, v, 0.5 - 0.25, 0.520, 0.030, 0.055)
        d += 0.045 * _gauss(u, v, 0.5 + 0.25, 0.520, 0.030, 0.055)
        return np.stack([x, y, z], -1) + np.stack([x, y, z], -1) * d[..., None]

    return np.stack([x, y, z], -1)


def tangent_frame(U: np.ndarray, V: np.ndarray, detail: float = 1.0, eps: float = 1e-3):
    """Return (P, N, T, B, du_len, dv_len) for the parametric surface.

    T is the unit u-tangent orthogonalised against N, B the unit v-tangent
    orthogonalised against N, so  world = T*ts.x + B*ts.y + N*ts.z  is exactly
    the reconstruction the shader performs (mat3(T,B,N) * tangentSpaceNormal).
    du_len / dv_len are |dP/du| and |dP/dv| -- the object-space arc length per
    unit of UV, which is what turns a height field into a tangent-space slope.
    """
    P = head_position(U, V, detail)
    # central differences where possible, squeezed one-sided at v = 0 and v = 1
    # (a plain V+eps at the top row steps *past* the pole, where the
    #  parametrisation folds back on itself and the frame comes out garbage)
    up = head_position(U + eps, V, detail)
    um = head_position(U - eps, V, detail)
    tu = (up - um) / (2.0 * eps)                   # u wraps, no boundary needed
    vp = np.clip(V + eps, 0.0, 1.0)
    vm = np.clip(V - eps, 0.0, 1.0)
    tv = (head_position(U, vp, detail) - head_position(U, vm, detail)) / (vp - vm)[..., None]
    du_len = np.linalg.norm(tu, axis=-1, keepdims=True)
    dv_len = np.linalg.norm(tv, axis=-1, keepdims=True)

    N = np.cross(tu, tv)
    N /= np.maximum(np.linalg.norm(N, axis=-1, keepdims=True), 1e-12)
    # One global sign: the surface is star-shaped about its centre, so the
    # per-point test N.(P-centre) > 0 is unanimous -- and a single boolean
    # avoids sign flicker in regions where the two are nearly perpendicular.
    centre = np.array([0.0, 0.05, 0.05])
    if float(np.sum(N * (P - centre))) < 0.0:
        N = -N

    tu_h = tu / np.maximum(du_len, 1e-12)
    tv_h = tv / np.maximum(dv_len, 1e-12)
    T = tu_h - N * np.sum(tu_h * N, axis=-1, keepdims=True)
    T /= np.maximum(np.linalg.norm(T, axis=-1, keepdims=True), 1e-12)
    B = tv_h - N * np.sum(tv_h * N, axis=-1, keepdims=True)
    B /= np.maximum(np.linalg.norm(B, axis=-1, keepdims=True), 1e-12)
    return P, N, T, B, du_len, dv_len


def encode_tangent_space_normal(n_obj: np.ndarray, T: np.ndarray, B: np.ndarray,
                                N: np.ndarray) -> np.ndarray:
    """Project object-space normals onto the (T,B,N) frame and pack to RGB.
    This is the exact inverse of `T*ts.x + B*ts.y + N*ts.z` in the vertex shader,
    so a round-trip through the map is lossless by construction."""
    ts = np.stack([np.sum(n_obj * T, -1), np.sum(n_obj * B, -1), np.sum(n_obj * N, -1)], -1)
    ts /= np.maximum(np.linalg.norm(ts, axis=-1, keepdims=True), 1e-12)
    return (ts * 0.5 + 0.5).astype(np.float32)


def build_head(nu: int = 96, nv: int = 72, detail: float = 1.0) -> Mesh:
    """Grid mesh; nu x nv quads, plus a pole cap at each end.

    Vertex layout:  U, V = meshgrid(us, vs, indexing="ij") means the first axis
    is u and the second is v, so the flattened index of grid cell (i, j) is

        index(i, j) = i * (nv + 1) + j

    (i.e. v runs fastest).  Getting this wrong stitches the two triangles of
    every quad to the wrong neighbours -- the surface stays in the right place,
    the silhouette stays smooth, but the interpolated normals alternate column
    to column and the whole head renders as vertical stripes.
    """
    us = np.linspace(0.0, 1.0, nu + 1)[:-1]          # wraps in u
    # Stop just short of the poles and cap the ends.  A UV sphere that actually
    # reaches v = 0 / 1 collapses a whole row of vertices to a point and both
    # the tangents and the shading normals go singular there.
    v_lo, v_hi = 0.044, 0.956
    vs = np.linspace(v_lo, v_hi, nv + 1)

    U, V = np.meshgrid(us, vs, indexing="ij")        # (nu, nv+1)

    # frame comes from the shared helper so the mesh and the normal map are
    # built from byte-identical T/B/N definitions
    P, N, T, B, _, _ = tangent_frame(U, V, detail)

    veclen = nv + 1
    def vid(i, j):
        return (i % nu) * veclen + j

    idx = []
    for j in range(nv):
        for i in range(nu):
            a = vid(i, j)
            b = vid(i + 1, j)
            c = vid(i + 1, j + 1)
            d = vid(i, j + 1)
            idx.append([a, c, b])
            idx.append([a, d, c])

    # --- pole caps: one triangle fan per end -------------------------------
    verts_p = [P.reshape(-1, 3)]
    verts_n = [N.reshape(-1, 3)]
    verts_t = [T.reshape(-1, 3)]
    verts_b = [B.reshape(-1, 3)]
    verts_uv = [np.stack([U, V], -1).reshape(-1, 2)]

    # the two fans wind in opposite senses as seen from outside, so the top cap
    # reverses its triangle order
    for v_pole, ring_j, flip in ((v_lo - 0.010, 0, False), (v_hi + 0.010, nv, True)):
        p_pole = head_position(np.array([0.5], np.float32),
                               np.array([v_pole], np.float32), detail)[0].astype(np.float32)
        n_pole = N[:, ring_j].mean(0)
        n_pole /= np.linalg.norm(n_pole)
        t_pole = np.array([1.0, 0.0, 0.0], np.float32)      # u-tangent stays +x
        b_pole = np.cross(n_pole, t_pole)
        b_pole /= np.linalg.norm(b_pole)
        pole_index = sum(p.shape[0] for p in verts_p)
        verts_p.append(p_pole.reshape(1, 3))
        verts_n.append(n_pole.astype(np.float32).reshape(1, 3))
        verts_t.append(t_pole.reshape(1, 3))
        verts_b.append(b_pole.astype(np.float32).reshape(1, 3))
        verts_uv.append(np.array([[0.5, v_pole]], np.float32))
        for i in range(nu):
            a = vid(i, ring_j)
            b = vid(i + 1, ring_j)
            idx.append([pole_index, b, a] if flip else [pole_index, a, b])

    indices = np.array(idx, dtype=np.uint32)

    pos = np.concatenate(verts_p).astype(np.float32)
    nrm = np.concatenate(verts_n).astype(np.float32)
    tan = np.concatenate(verts_t).astype(np.float32)
    bit = np.concatenate(verts_b).astype(np.float32)
    uvs = np.concatenate(verts_uv).astype(np.float32)

    # --- winding check: every triangle's geometric normal must agree with the
    #     analytic vertex normals, or GL_CULL_FACE throws the face away -------
    tri = indices.reshape(-1, 3)
    e1 = pos[tri[:, 1]] - pos[tri[:, 0]]
    e2 = pos[tri[:, 2]] - pos[tri[:, 0]]
    gn = np.cross(e1, e2)
    vn = nrm[tri].mean(1)
    agree = np.sum(gn * vn, -1)
    if (agree < 0).any():
        raise AssertionError(f"{int((agree < 0).sum())} triangles wound inward "
                             "-- flip the quad order in build_head()")
    return Mesh(positions=pos, normals=nrm, uvs=uvs, tangents=tan,
                bitangents=bit, indices=indices)


# ---------------------------------------------------------------------------
# the eyeballs -- the reason a character model is *not* one shader
# ---------------------------------------------------------------------------
# Alyx's real eyes are a separate .mdl (`models/alyx/alyx_eyes.mdl`) drawn with
# EyeRefract, whose pixel shader is ported alongside this file
# (engine-sources/eye_refract_ps2x.fxc).  The two spheres here exist so that the
# showcase can draw *two materials from one model in sequence* and show where
# the split comes from: the eyeball needs a refraction/lens term, its own
# cubemap and its own dilation animation, none of which the skin shader has.
EYE_U = 0.5, 0.5          # u=0.5 is the front of the face
EYE_DU = 0.072            # the eye sockets in head_position(): 0.5 +/- 0.072
EYE_V = 0.575             # seen at u +/- 0.072, v 0.575  (textures.py: eye_l/eye_r)
EYE_RADIUS = 0.068        # stand-in head units; $eyeballradius in EyeRefract's
                          # own constant map defaults to 0.51 for the real model
EYE_PROTRUDE = 0.020      # how far the front pole pokes out of the socket


def eye_anchors(detail: float = 1.0):
    """Both eyeball centres in *model space* (the head mesh's own space, before
    the 0.62 scale render.py applies).  Sampled off the same parametric surface
    the eye sockets were cut into, so they sit in the sockets by construction."""
    centers, forwards = [], []
    for du in (-EYE_DU, +EYE_DU):
        u = np.array([EYE_U[0] + du], np.float32)
        v = np.array([EYE_V], np.float32)
        p = head_position(u, v, detail)[0]
        n = tangent_frame(u, v, detail)[1][0]        # outward normal there
        n = n / max(np.linalg.norm(n), 1e-9)
        # pull the centre back along the socket normal so the sphere bulges out
        # of the socket the way a real eyeball sits in its orbit
        centers.append((p - n * (EYE_RADIUS - EYE_PROTRUDE)).astype(np.float32))
        forwards.append(n.astype(np.float32))        # the pole = the iris axis
    return np.stack(centers, 0), np.stack(forwards, 0)


def build_eye_sphere(radius: float = EYE_RADIUS, nu: int = 40, nv: int = 28) -> Mesh:
    """UV sphere with the same vertex layout build_head() uses, so the web
    exporter can hand it to the same attribute bindings."""
    us = np.linspace(0.0, 1.0, nu + 1)[:-1]
    vs = np.linspace(-0.5 * math.pi, 0.5 * math.pi, nv + 1)
    U, V = np.meshgrid(us, vs, indexing="ij")
    theta = U * 2.0 * math.pi
    P = np.stack([np.sin(theta) * np.cos(V), np.sin(V), -np.cos(theta) * np.cos(V)], -1)
    N = P.copy()
    T = np.stack([np.cos(theta), np.zeros_like(theta), np.sin(theta)], -1)
    B = np.cross(N, T)
    B /= np.maximum(np.linalg.norm(B, axis=-1, keepdims=True), 1e-9)
    veclen = nv + 1

    def vid(i, j):
        return (i % nu) * veclen + j

    idx = []
    for j in range(nv):
        for i in range(nu):
            a, b, c, d = vid(i, j), vid(i + 1, j), vid(i + 1, j + 1), vid(i, j + 1)
            idx.append([a, c, b]); idx.append([a, d, c])
    indices = np.array(idx, np.uint32)
    # The sphere is generated with its pole on +y; rotate it so the pole points
    # down -z, i.e. out through the front of the face.  The iris then lives at
    # the centre of the UV map (u=0.5, v=0.5), which is where EyeRefract's iris
    # projection expects it.
    R = np.array([[1, 0, 0], [0, 0, 1], [0, -1, 0]], np.float32)   # (x,y,z) -> (x, z, -y)
    P, N, T, B = (P @ R.T, N @ R.T, T @ R.T, B @ R.T)
    pos = (P.reshape(-1, 3) * radius).astype(np.float32)
    return Mesh(positions=pos, normals=N.reshape(-1, 3).astype(np.float32),
                uvs=np.stack([U, V / math.pi + 0.5], -1).reshape(-1, 2).astype(np.float32),
                tangents=T.reshape(-1, 3).astype(np.float32),
                bitangents=B.reshape(-1, 3).astype(np.float32), indices=indices)


# ---------------------------------------------------------------------------
# face flexes -- the *other* vertex stream
# ---------------------------------------------------------------------------
# A real model ships .vta files: one float3 delta per vertex per flex, plus a
# rule for how the animation drives them.  common_vs_fxc.h doesn't read them as
# attributes at all on the VS_3_0 path -- ApplyMorph() samples the delta out of a
# vertex texture (SampleMorphDelta) -- and the older path multiplies a second
# stream by cFlexScale.x.  Both end in the same one line:
#
#     vPosition.xyz += vPosDelta;
#
# No .vta is redistributable with a stand-in head, so these two deltas are
# synthesised *from the parametric surface* : they are honest geometry deltas,
# they are applied by that same line, and they demonstrate the mechanism the
# question is about -- they are not Alyx's flexes.
def flex_deltas(mesh: Mesh, verbose: bool = True):
    """Return (names, deltas) -- deltas is (nflex, nverts, 3) float32, in model
    space, i.e. exactly what cFlexScale.x multiplies."""
    P, UV = mesh.positions, mesh.uvs
    u, v = UV[:, 0], UV[:, 1]
    n = P.shape[0]
    # "blink": the eyelids come down.  Everything above the eye socket moves
    # down and slightly back; the mask is a soft band around v = 0.575.
    lid = np.clip(_gauss(u, v, 0.5 - EYE_DU, EYE_V + 0.012, 0.055, 0.026)
                  + _gauss(u, v, 0.5 + EYE_DU, EYE_V + 0.012, 0.055, 0.026), 0.0, 1.0)
    blink = np.zeros((n, 3), np.float32)
    blink[:, 1] = -0.075 * lid                      # y is up, so down is -y
    blink[:, 2] = -0.028 * lid                      # and tuck back into the skull
    # "jaw open": the jaw hinges, so the displacement grows with -v and is
    # rotated about the hinge; a translation is enough to show the mechanism.
    jaw = _smoothstep(0.46, 0.16, v) * (1.0 - _smoothstep(0.36, 0.13, v) * 0.35)
    jaw = np.clip(jaw, 0.0, 1.0)
    # ~7% of the head's height at full weight, which is the ballpark of a real
    # jaw-open flex on a 2004-era head mesh
    jaw_open = np.stack([np.zeros(n, np.float32),
                         -0.155 * jaw * np.clip(1.0 - np.abs(u - 0.5) / 0.22, 0.0, 1.0),
                         -0.070 * jaw * np.clip(1.0 - np.abs(u - 0.5) / 0.30, 0.0, 1.0)], -1)
    names = ["blink", "jaw_open"]
    deltas = np.stack([blink, jaw_open], 0).astype(np.float32)
    if verbose:
        print(f"[flex] synthesised {len(names)} deltas over {n} verts: "
              f"{', '.join(f'{k}(max {np.abs(d).max():.3f})' for k, d in zip(names, deltas))}")
    return names, deltas
