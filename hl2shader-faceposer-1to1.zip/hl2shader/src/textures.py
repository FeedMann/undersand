"""
textures.py -- author the four maps Alyx's material needs, as .vtf + .vmt,
and lay them out the way Valve's art does:

  alyx_faceandhair.vtf          albedo            (RGB, implicit alpha)
  alyx_head_normal.vtf          tangent-space     (RGB = normal, A = PHONG MASK)
  alyx_head_exponent.vtf        R = exponent, G = albedo tint, A = rim mask
  lightwarps/face_lightwarp.vtf 1D strip used by $lightwarptexture

The zone layout follows the real maps (the wiki reproduces Alyx's mask and
exponent textures): the hairband and lips carry the strong specular, the nose
carries a tight hotspot, the eyes/brows carry none at all, and the cheeks are a
broad dull sheen.
"""
from __future__ import annotations

import numpy as np



# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _fbm(shape, seed, octaves=5, base=4):
    """Cheap fractal noise from summed random grids (no scipy needed)."""
    rng = np.random.default_rng(seed)
    h, w = shape
    acc = np.zeros(shape, np.float32)
    amp, total = 1.0, 0.0
    for o in range(octaves):
        n = base * 2 ** o
        g = rng.random((max(2, n), max(2, n))).astype(np.float32)
        # bilinear upscale with wrap in x (the texture wraps around the head)
        ys = np.linspace(0, n - 1, h)
        xs = np.linspace(0, n, w, endpoint=False) % n
        y0 = np.floor(ys).astype(int); y1 = (y0 + 1) % n
        x0 = np.floor(xs).astype(int); x1 = (x0 + 1) % n
        fy = (ys - y0)[:, None]; fx = (xs - x0)[None, :]
        top = g[np.ix_(y0, x0)] * (1 - fx) + g[np.ix_(y0, x1)] * fx
        bot = g[np.ix_(y1, x0)] * (1 - fx) + g[np.ix_(y1, x1)] * fx
        acc += amp * (top * (1 - fy) + bot * fy)
        total += amp
        amp *= 0.5
    return acc / total


def _smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0.0, 1.0)
    return t * t * (3 - 2 * t)


def _gauss(u, v, cu, cv, su, sv):
    du = (u - cu + 0.5) % 1.0 - 0.5
    return np.exp(-((du / su) ** 2 + ((v - cv) / sv) ** 2))


def normal_from_height(height: np.ndarray, strength: float = 1.0) -> np.ndarray:
    """Tangent-space normal map from a height field. +u -> +x, +v -> -y (OpenGL/D3D
    convention: green = +y downward in texture space, which is what Source uses)."""
    du = np.gradient(height, axis=1)
    dv = np.gradient(height, axis=0)
    nx = -du * strength
    ny = dv * strength
    nz = np.ones_like(height)
    n = np.stack([nx, ny, nz], -1)
    n /= np.linalg.norm(n, axis=-1, keepdims=True)
    return (n * 0.5 + 0.5).astype(np.float32)


# ---------------------------------------------------------------------------
# the four maps
# ---------------------------------------------------------------------------
def synth_face_textures(res: int = 768, seed: int = 7):
    h = w = res
    v1 = np.linspace(0, 1, h, dtype=np.float32)[:, None]
    u1 = np.linspace(0, 1, w, dtype=np.float32)[None, :]
    # make full 2D grids so every derived field is (h, w)
    u = np.broadcast_to(u1, (h, w)).copy()
    v = np.broadcast_to(v1, (h, w)).copy()

    # ---------- zone fields ------------------------------------------------
    front = _smoothstep(0.62, 0.30, np.abs(u - 0.5))          # 1 on the face
    band = np.exp(-((v - 0.815) / 0.055) ** 2)                # hairband
    hair = _smoothstep(0.90, 0.96, v)                         # crown / top of head
    brow = _gauss(u, v, 0.5, 0.612, 0.115, 0.022)
    eye_l = _gauss(u, v, 0.5 - 0.072, 0.575, 0.036, 0.024)
    eye_r = _gauss(u, v, 0.5 + 0.072, 0.575, 0.036, 0.024)
    eye = np.clip(eye_l + eye_r, 0, 1)
    lips = _gauss(u, v, 0.5, 0.318, 0.062, 0.026)
    mouthline = _gauss(u, v, 0.5, 0.303, 0.058, 0.006)
    nose = _gauss(u, v, 0.5, 0.455, 0.030, 0.075) + _gauss(u, v, 0.5, 0.400, 0.040, 0.030)
    cheeks = (_gauss(u, v, 0.5 - 0.105, 0.470, 0.070, 0.070) +
              _gauss(u, v, 0.5 + 0.105, 0.470, 0.070, 0.070))
    neck = _smoothstep(0.26, 0.10, v)
    scalp = _smoothstep(0.70, 0.80, v) * (1 - band)

    n1 = _fbm((h, w), seed, octaves=6, base=4)          # pores / cloth
    n2 = _fbm((h, w), seed + 11, octaves=4, base=8)     # fine grain
    n3 = _fbm((h, w), seed + 23, octaves=3, base=2)     # large mottling

    # ---------- albedo -----------------------------------------------------
    skin_base = np.array([0.62, 0.44, 0.36], np.float32)
    skin_deep = np.array([0.42, 0.27, 0.22], np.float32)
    albedo = (skin_base[None, None, :] * (0.85 + 0.3 * n3[..., None])
              + skin_deep[None, None, :] * 0.35 * (1 - front)[..., None])
    albedo *= (0.94 + 0.12 * n1[..., None])                             # pore variation
    albedo += 0.05 * cheeks[..., None] * np.array([1.0, 0.6, 0.5])      # blush
    albedo -= 0.10 * brow[..., None]
    albedo = albedo * (1 - eye[..., None]) + np.array([0.10, 0.08, 0.09]) * eye[..., None]
    lp = lips[..., None]
    albedo = albedo * (1 - lp * 0.85) + np.array([0.62, 0.26, 0.26]) * (lp * 0.85)
    albedo -= 0.35 * mouthline[..., None] * lips[..., None]
    albedo *= (1 - 0.12 * nose[..., None])
    band_mask = np.clip(band * (1 - hair), 0, 1)[..., None]
    albedo = albedo * (1 - band_mask) + np.array([0.30, 0.33, 0.40]) * band_mask
    albedo -= 0.05 * band_mask * n1[..., None]
    hair_mask = hair[..., None]
    albedo = albedo * (1 - hair_mask) + np.array([0.12, 0.10, 0.10]) * hair_mask
    neck_mask = neck[..., None] * 0.5
    albedo = albedo * (1 - neck_mask * 0.4) + np.array([0.30, 0.20, 0.17]) * (neck_mask * 0.4)
    albedo = np.clip(albedo, 0, 1)

    # ---------- height -> normal (in the mesh's own tangent frame) ----------
    # The map must be built from the SAME T/B/N the vertex shader interpolates,
    # or the round trip world = T*ts.x + B*ts.y + N*ts.z is not the identity.
    # Slopes are converted from "height per UV unit" to "height per unit of
    # object-space arc length" using |dP/du|, |dP/dv| -- without that factor the
    # gradients are ~1e-4 per texel and the map comes out flat lavender.
    import model as model_mod
    # The frame is only defined where the parametrisation is: v = 0 and v = 1
    # are the poles, where the surface collapses and dP/dv folds back on
    # itself.  The mesh caps its ends inside [0.044, 0.956] and the pole
    # vertices sample v = 0.034 / 0.966, so clamping the frame grid at the
    # outermost half-percent keeps every texel the mesh can address valid.
    v_frame = np.clip(v, 0.005, 0.995)
    _, Nf, Tf, Bf, du_len, dv_len = model_mod.tangent_frame(u, v_frame, 1.0)
    du_len = np.maximum(du_len, 1e-3)
    dv_len = np.maximum(dv_len, 1e-3)

    fine = n1 - 0.5                      # pore-scale break-up
    mid = n2 - 0.5                       # grain
    # vertical creases across the lips (vermilion lines)
    lip_crease = np.sin((u - 0.5) * 2.0 * np.pi * 46.0)
    # weave of the hairband: one ridge system along v, a fainter one across u
    weave_v = np.sin((v - 0.815) * 2.0 * np.pi * 34.0)
    weave_u = np.sin((u - 0.5) * 2.0 * np.pi * 22.0)
    # eyelid crease sits as a thin ridge along the top of each eye
    lid = (_gauss(u, v, 0.5 - 0.072, 0.593, 0.036, 0.009) +
           _gauss(u, v, 0.5 + 0.072, 0.593, 0.036, 0.009))
    # under-eye bag
    bag = (_gauss(u, v, 0.5 - 0.070, 0.552, 0.034, 0.012) +
           _gauss(u, v, 0.5 + 0.070, 0.552, 0.034, 0.012))
    # nostril wells
    nostril = (_gauss(u, v, 0.5 - 0.022, 0.383, 0.014, 0.012) +
               _gauss(u, v, 0.5 + 0.022, 0.383, 0.014, 0.012))
    skin_mask = front * (1 - band) * (1 - hair) * (1 - eye * 0.9)

    # amplitudes are in OBJECT UNITS (the head is ~2 units tall): a 0.002 bump
    # spread over ~0.03 units of surface reads as roughly a 12 degree tilt
    height = (0.0032 * fine * (0.45 + 0.55 * skin_mask)
              + 0.0015 * mid * (0.30 + 0.70 * front)
              + 0.0040 * lip_crease * lips * front
              - 0.0006 * mouthline
              + 0.0034 * weave_v * band * (1 - hair)
              + 0.0018 * weave_u * band * (1 - hair)
              + 0.0016 * band * (1 - hair)
              + 0.0044 * lid - 0.0032 * bag
              - 0.0044 * nostril
              + 0.0012 * brow * fine)

    dh_du = np.gradient(height, axis=1)          # height change per texel in u
    dh_dv = np.gradient(height, axis=0)          # height change per texel in v
    # object-space arc length covered by one texel, per axis
    texel_u = du_len[..., 0] / w
    texel_v = dv_len[..., 0] / h
    # slope = rise / run, both in object units
    dh_dx = dh_du / np.maximum(texel_u, 1e-6)
    dh_dy = dh_dv / np.maximum(texel_v, 1e-6)
    # tilt the surface normal back along -T/-B in proportion to the slope
    n_obj = Nf - dh_dx[..., None] * Tf - dh_dy[..., None] * Bf
    n_obj /= np.maximum(np.linalg.norm(n_obj, axis=-1, keepdims=True), 1e-12)
    nrm = model_mod.encode_tangent_space_normal(n_obj, Tf, Bf, Nf)
    slope = np.sqrt(dh_dx ** 2 + dh_dy ** 2)

    # ---------- PHONG MASK -> alpha of the normal map ----------------------
    # (this is the whole point: $phong uses the bumpmap's alpha unless
    #  $basemapalphaphongmask is set)
    mask = np.zeros((h, w), np.float32)
    mask += 0.90 * np.clip(band * (1 - hair), 0, 1)      # hairband: strong
    mask += 0.55 * lips
    mask += 0.42 * nose
    mask += 0.28 * cheeks
    mask += 0.20 * front * (1 - eye) * (1 - band)
    mask += 0.34 * np.clip(scalp * 0.0, 0, 1)            # scalp stays matte
    mask *= (1 - eye)                                    # eyelids: nothing
    mask *= (1 - brow * 0.9)
    mask *= (1 - mouthline * 0.8)
    mask *= (1 - neck)                                   # neck cloth is dull
    mask += 0.06 * n2 * mask                             # subtle breakup
    mask = np.clip(mask, 0, 1)

    # a quick sanity line -- a flat map would mean the gradients vanished again
    ts = nrm[..., :2] * 2.0 - 1.0
    print(f"[bump ] normal map: slope p50={np.percentile(slope,50):.3f} "
          f"p99={np.percentile(slope,99):.3f} | ts.xy std=({ts[...,0].std():.3f},"
          f"{ts[...,1].std():.3f}) max tilt={np.degrees(np.arctan(np.percentile(slope,99))):.1f} deg")

    normal_rgba = np.concatenate([nrm, mask[..., None]], -1)

    # ---------- PHONG EXPONENT --------------------------------------------
    # red = exponent texel (0 => broad highlight, 1 => tight hotspot)
    exponent = np.zeros((h, w), np.float32)
    exponent += 0.46 * np.clip(band * (1 - hair), 0, 1)   # hairband: tightish
    exponent += 0.62 * nose                               # nose hotspot is very tight
    exponent += 0.52 * lips
    exponent += 0.34 * cheeks
    exponent += 0.12 * front * (1 - band)                 # skin: broad sheen
    exponent *= (1 - eye) * (1 - brow * 0.8)
    exponent *= (1 - neck)
    exponent += 0.05 * n1                                 # per-texel variation
    exponent = np.clip(exponent, 0.0, 1.0)
    # green = albedo-tint mask (only read when $phongalbedotint 1)
    tint_mask = np.clip(0.75 * np.clip(band * (1 - hair), 0, 1) + 0.5 * lips, 0, 1)
    # alpha = rim-light mask (only read when $rimmask 1)
    rim_mask = np.clip(0.6 * front, 0, 1)
    exponent_rga = np.concatenate([exponent[..., None], tint_mask[..., None],
                                   np.zeros_like(exponent)[..., None]], -1)
    exponent_rgba = np.concatenate([exponent_rga, rim_mask[..., None]], -1)

    return albedo, normal_rgba, exponent_rgba


def synth_lightwarp(n: int = 256) -> np.ndarray:
    """A 1D 'lightwarp' strip.  Dark texels tint with the left colour, bright
    with the right; 50% grey is neutral.  Note the shader multiplies the lookup
    by 2.0, so these are authored at roughly half brightness."""
    t = np.linspace(0, 1, n, dtype=np.float32)
    # The shader evaluates  diffuse = 2.0 * tex1D(lightWarpSampler, ndotl*0.5+0.5),
    # so the *stored* values are roughly half of the light they stand for:
    #   x = 0    -> 2 * 0.125 = 0.25   fully self-shadowed, never black
    #   x = 0.5  -> 2 * 0.5   = 1.0    the neutral side of the terminator
    #   x = 1    -> 2 * 0.62  = 1.24   fully lit, a little over-bright
    # The low half uses a power > 1, which flattens the toe: that soft "lift"
    # under the terminator is the whole point of a lightwarp -- it is what makes
    # a character read as sub-surface rather than as a plastic ball.
    shadow = np.array([0.125, 0.120, 0.135], np.float32)   # cool, very dark
    mid = np.array([0.500, 0.500, 0.500], np.float32)      # 50% grey == identity
    high = np.array([0.620, 0.565, 0.500], np.float32)     # warm highlight rolloff
    lo = (t / 0.5) ** 1.25
    hi = np.clip((t - 0.5) / 0.5, 0.0, None) ** 1.60   # clip: t<0.5 gives a NaN here otherwise
    left = (t < 0.5)[:, None]
    out = np.zeros((1, n, 3), np.float32)
    out[0] = np.where(left, shadow + (mid - shadow) * lo[:, None],
                             mid + (high - mid) * hi[:, None])
    return out


# ---------------------------------------------------------------------------
# on-disk material set
# ---------------------------------------------------------------------------
def write_material_set(outdir: str, res: int = 768, seed: int = 7, verbose=True):
    """Writes .vtf + .vmt into a mod-style folder tree."""
    import os
    import vtf

    mat_dir = os.path.join(outdir, "materials", "models", "alyx")
    warp_dir = os.path.join(outdir, "materials", "models", "lightwarps")
    os.makedirs(mat_dir, exist_ok=True)
    os.makedirs(warp_dir, exist_ok=True)

    albedo, normal_rgba, exponent_rgba = synth_face_textures(res=res, seed=seed)
    lightwarp = synth_lightwarp()

    paths = {
        "albedo": os.path.join(mat_dir, "alyx_faceandhair.vtf"),
        "normal": os.path.join(mat_dir, "alyx_head_normal.vtf"),
        "exponent": os.path.join(mat_dir, "alyx_head_exponent.vtf"),
        "lightwarp": os.path.join(warp_dir, "face_lightwarp.vtf"),
    }
    vtf.write(paths["albedo"], albedo)
    vtf.write(paths["normal"], normal_rgba)
    vtf.write(paths["exponent"], exponent_rgba)
    vtf.write(paths["lightwarp"], lightwarp)

    # ---- the VMTs, byte-for-byte in Valve's dialect ----------------------
    ep1 = """// materials/models/Alyx/alyx_faceandhair.vmt
// Reproduction of the Episode One face material quoted on the VDC wiki page
// "Phong materials".  $phongboost 6 + fresnelranges [0.05 0.5 1] are her values.
"VertexLitGeneric"
{
\t"$basetexture"           "models/Alyx/alyx_faceandhair"
\t"$bumpmap"               "models/alyx/alyx_head_normal"
\t"$halflambert"           "1"
\t"$nodecal"               "1"
\t"$model"                 "1"

\t"$phong"                 "1"
//\t"$phongexponent"       "33"
\t"$phongexponenttexture"  "models/Alyx/alyx_head_exponent"
\t"$phongboost"            "6"
\t"$phongfresnelranges"    "[0.05 0.5 1]"
}
"""
    vanilla = """// The same material as Half-Life 2 (2004) shipped it: no $phong at all.
// Specular was a masked cubemap reflection, not a light-tracking highlight.
"VertexLitGeneric"
{
\t"$basetexture"           "models/Alyx/alyx_faceandhair"
\t"$bumpmap"               "models/alyx/alyx_head_normal"
\t"$halflambert"           "1"
\t"$nodecal"               "1"
\t"$model"                 "1"

\t"$envmap"                "env_cubemap"
\t"$normalmapalphaenvmapmask" "1"
\t"$envmaptint"            "[.1 .1 .1]"
}
"""
    litwarp = """// Episode-era addition: a 1D lookup that re-tints the diffuse response.
"VertexLitGeneric"
{
\t"$basetexture"           "models/Alyx/alyx_faceandhair"
\t"$bumpmap"               "models/alyx/alyx_head_normal"
\t"$halflambert"           "1"
\t"$model"                 "1"

\t"$phong"                 "1"
\t"$phongexponenttexture"  "models/Alyx/alyx_head_exponent"
\t"$phongboost"            "6"
\t"$phongfresnelranges"    "[0.05 0.5 1]"

\t"$lightwarptexture"      "models/lightwarps/face_lightwarp"
\t"$phongalbedotint"       "1"
}
"""
    # rimlight variant, to exercise the RIMLIGHT branch that already existed in 2007
    rim = """// exercises the RIMLIGHT combos that were already present in the 2007 shader
"VertexLitGeneric"
{
\t"$basetexture"           "models/Alyx/alyx_faceandhair"
\t"$bumpmap"               "models/alyx/alyx_head_normal"
\t"$halflambert"           "1"
\t"$model"                 "1"

\t"$phong"                 "1"
\t"$phongexponenttexture"  "models/Alyx/alyx_head_exponent"
\t"$phongboost"            "6"
\t"$phongfresnelranges"    "[0.05 0.5 1]"

\t"$rimlight"              "1"
\t"$rimmask"               "1"
\t"$rimlightpower"         "4"
\t"$rimlightboost"         "1"
}
"""
    vmt_paths = {
        "ep1": os.path.join(mat_dir, "alyx_faceandhair.vmt"),
        "vanilla": os.path.join(mat_dir, "alyx_faceandhair_2004.vmt"),
        "lightwarp": os.path.join(mat_dir, "alyx_faceandhair_lightwarp.vmt"),
        "rim": os.path.join(mat_dir, "alyx_faceandhair_rim.vmt"),
    }
    for k, txt in (("ep1", ep1), ("vanilla", vanilla), ("lightwarp", litwarp), ("rim", rim)):
        open(vmt_paths[k], "w").write(txt)

    if verbose:
        print(f"[assets] wrote material set to {outdir}")
        for k, p in list(paths.items()) + list(vmt_paths.items()):
            print(f"[assets]   {k:10s} {p}")

    return paths, vmt_paths
