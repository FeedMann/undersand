"""Patch 2: the VBMOD4 draw path, the CPU flex application, and the UI."""
import io

P = "web_template.html"
s = io.open(P, encoding="utf-8").read()

# ------------------------------------------------- 1. the draw, after the head
DRAW = r'''
  /* ---- your model: VBMOD4 + VBFLX1, drawn with the same pixel shaders -----
     The vertex program is the adapter (VBMOD_VS); the fragment program is the
     material, unchanged -- the ported skin_ps20b.fxc for the body and
     eye_refract_ps2x.fxc for the eyeballs, exactly as the stand-in head uses
     them.  The CPU-side flex application mirrors the package's own
     ApplyFaceFlexTargets(): weights are supplied per target and the sparse
     records accumulate linearly into positions and normals. */
  if(state.model.src==="vbmod" && gpu.vb && gpu.vbSkin){
    const V=gpu.vb, p=gpu.vbSkin;
    gl.useProgram(p);
    const L=(n)=>gl.getUniformLocation(p,n);
    gl.uniformMatrix4fv(L("u_model"),false,IDENT4);
    gl.uniformMatrix4fv(L("u_view"),false,viewM);
    gl.uniformMatrix4fv(L("u_proj"),false,projM);
    gl.uniformMatrix3fv(L("u_normalMat"),false,IDENT3);
    setUniform(p,"u_cFlexScale",0.0);
    const R=state.regs, eye=DATA.camEye;
    gl.uniform4f(L("g_EyePos_SpecExponent"),eye[0],eye[1],eye[2],R.EyePos_SpecExponent[3]);
    gl.uniform4fv(L("g_FresnelRanges_SpecBoost"),new Float32Array(R.FresnelRanges_SpecBoost));
    gl.uniform4fv(L("g_SpecularRimParams"),new Float32Array(R.SpecularRimParams));
    gl.uniform4fv(L("g_FlashlightPos_RimBoost"),new Float32Array(R.FlashlightPos_RimBoost));
    gl.uniform4fv(L("g_FlashlightAttenuation_RimMask"),new Float32Array(R.FlashlightAttenuation_RimMask));
    gl.uniform4fv(L("g_ShaderControls"),new Float32Array(R.ShaderControls));
    gl.uniform4f(L("g_DiffuseModulation"),1,1,1,1);
    gl.uniform4fv(L("g_EnvmapTint_ShadowTweaks"),new Float32Array(R.EnvmapTint_ShadowTweaks));
    gl.uniform4fv(L("g_EnvMapFresnel_SelfIllumMask"),new Float32Array(R.EnvMapFresnel_SelfIllumMask));
    gl.uniform3fv(L("u_ambientCube"),new Float32Array(vbCube().flat()));
    const lp=new Float32Array(16), lc=new Float32Array(16);
    state.lights.slice(0,4).forEach((l,i)=>{ lp.set(l.pos,i*4); lc.set(l.color,i*4); });
    gl.uniform4fv(L("g_LightPos"),lp);
    gl.uniform4fv(L("g_LightColor"),lc);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D,V.maps.albedo); gl.uniform1i(L("u_baseTex"),0);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D,V.maps.bump);   gl.uniform1i(L("u_normalTex"),1);
    gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D,V.maps.expo);   gl.uniform1i(L("u_exponentTex"),2);
    gl.activeTexture(gl.TEXTURE3); gl.bindTexture(gl.TEXTURE_2D,gpu.warp);      gl.uniform1i(L("u_lightwarpTex"),3);
    gl.activeTexture(gl.TEXTURE5); gl.bindTexture(gl.TEXTURE_CUBE_MAP,gpu.env); gl.uniform1i(L("u_envCube"),5);
    if(perPixelProbes()){
      gl.activeTexture(gl.TEXTURE6); gl.bindTexture(gl.TEXTURE_3D,gpu.lightgrid);
      setUniform(p,"u_lightgrid",6);
      setUniform(p,"u_gridLo",new Float32Array(LG.lo));
      setUniform(p,"u_gridCell",new Float32Array(LG.cell));
      setUniform(p,"u_gridDims",new Float32Array(LG.dims));
    }
    gl.bindVertexArray(null);
    gl.bindBuffer(gl.ARRAY_BUFFER,gpu.vbVBO);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,gpu.vbIBO);
    const A=(name,size,off)=>{ const a=gl.getAttribLocation(p,name);
      if(a<0) return; gl.enableVertexAttribArray(a);
      gl.vertexAttribPointer(a,size,gl.FLOAT,false,V.stride*4,off*4); };
    A("a_pos",3,0); A("a_normal",3,3); A("a_uv",2,6); A("a_tangent",3,8); A("a_sign",1,11);
    for(const m of V.meshes){
      if(m.slot!=="skin") continue;
      gl.drawElements(gl.TRIANGLES,m.indexCount,gpu.vbIndexType,m.firstIndex*4);
    }
    /* ---- the eyeballs: the second material, on the same vertex buffer ----- */
    const ep=gpu.vbEye; if(ep){
      gl.useProgram(ep);
      const EL=(n)=>gl.getUniformLocation(ep,n);
      gl.uniformMatrix4fv(EL("u_model"),false,IDENT4);
      gl.uniformMatrix4fv(EL("u_view"),false,viewM);
      gl.uniformMatrix4fv(EL("u_proj"),false,projM);
      gl.uniformMatrix3fv(EL("u_normalMat"),false,IDENT3);
      gl.uniform4f(EL("g_EyePos"),eye[0],eye[1],eye[2],0);
      gl.activeTexture(gl.TEXTURE5); gl.bindTexture(gl.TEXTURE_CUBE_MAP,gpu.env);
      gl.uniform1i(EL("u_envCube"),5);
      const lp3=new Float32Array(12), lc3=new Float32Array(12);
      state.lights.slice(0,3).forEach((l,i)=>{ lp3.set(l.pos,i*4); lc3.set(l.color,i*4); });
      gl.uniform4fv(EL("g_sLightInfoPos"),lp3);
      gl.uniform4fv(EL("g_sLightInfoColor"),lc3);
      gl.uniform3fv(EL("g_cAmbientOcclColor"),new Float32Array([0.35,0.30,0.28]));
      gl.uniform1f(EL("g_flAOStandIn"),state.eye.ao);
      gl.uniform1f(EL("u_eyeShow"),state.eye.show);
      V.eyes.forEach((e,i)=>{
        const amb=LG.sampleAmbient(e.centre,e.forward,1);
        const avg=luma(amb);
        gl.uniform4f(EL("g_flDilation_Glossiness_AvgAmbient_CorneaBump"),
                     state.eye.dilation,state.eye.gloss,avg,0.0);
        gl.uniform4f(EL("g_EyeCentre_Radius"),e.centre[0],e.centre[1],e.centre[2],e.radius);
        gl.uniform3fv(EL("g_EyeForward"),new Float32Array(e.forward));
        gl.uniform4fv(EL("g_IrisColor"),new Float32Array(state.eye.iris));
        gl.uniform4fv(EL("g_IrisParams"),new Float32Array([state.eye.irisR,state.eye.pupilR,
                                                           0.03,state.eye.bright]));
        for(const m of V.meshes){
          if(m.slot!=="eye"||m.material!==e.material) continue;
          gl.drawElements(gl.TRIANGLES,m.indexCount,gpu.vbIndexType,m.firstIndex*4);
        }
      });
    }
  }

'''
anchor = "  /* ---- the eyes: a second material, drawn after the skin -----------------"
assert s.count(anchor) == 1
s = s.replace(anchor, DRAW + anchor)

# --------------------------------------------- 2. helpers: cube + flex apply
HELPERS = r'''
/* Which probe cube a *model* gets: cAmbientCube is resolved once per entity, at
   the entity's origin -- for a character that origin is at the feet, not the
   head, which is exactly why a tall model can look flat.  The read-out prints
   both so the difference is visible. */
function vbCube(){
  if(!gpu.vb||!gpu.vb.cube){
    const o=(DATA.vbmod&&DATA.vbmod.origin)||[0,0,0];
    gpu.vb.cube=LG.sampleCube(o,1);
    gpu.vb.headCube=LG.sampleCube(DATA.vbmod.eyeCentre,1);
  }
  return (state.light.mode==="flat")?DATA.ambientCube
       : (state.light.mode==="probe"?gpu.vb.headCube:gpu.vb.cube);
}
function perPixelProbes(){ return state.light.mode==="probe"; }

/* ApplyFaceFlexTargets(), on the JS side: linear accumulation of the sparse
   records into position and normal, then one buffer upload.  The format's own
   C++ does this on the CPU too (src/vb/vb_model.cpp); the stand-in head shows
   the GPU alternative (one delta attribute stream + cFlexScale). */
function applyVbFlex(){
  const V=gpu.vb; if(!V) return;
  V.live.set(V.base);
  const w=state.model.vbWeight;
  const use=[];
  if(w>0.001){
    use.push([state.model.vbSel,w]);
    if(state.model.vbMirror){
      const t=V.targets[state.model.vbSel];
      if(t&&t.pair){
        const pi=DATA.vbmod.targetIndex[t.pair];
        if(pi!==undefined) use.push([pi,w]);
      }
    }
  }
  for(const [ti,wt] of use){
    const t=V.targets[ti]; if(!t||!t.count) continue;
    const idx=new Uint16Array(b64ToBytes(t.idx16).buffer);
    const dl=new Uint16Array(b64ToBytes(t.delta16).buffer);
    for(let k=0;k<t.count;k++){
      const v=idx[k], o=v*V.stride;
      V.live[o+0]+=h2f(dl[k*6+0])*wt;
      V.live[o+1]+=h2f(dl[k*6+1])*wt;
      V.live[o+2]+=h2f(dl[k*6+2])*wt;
      V.live[o+3]+=h2f(dl[k*6+3])*wt;
      V.live[o+4]+=h2f(dl[k*6+4])*wt;
      V.live[o+5]+=h2f(dl[k*6+5])*wt;
    }
  }
  // renormalise the normals that moved, then upload
  for(let i=0;i<V.nverts;i++){
    const o=i*V.stride;
    if(w<=0.001) break;
    const x=V.live[o+3], y=V.live[o+4], z=V.live[o+5];
    const l=Math.hypot(x,y,z)||1;
    V.live[o+3]=x/l; V.live[o+4]=y/l; V.live[o+5]=z/l;
  }
  gl.bindBuffer(gl.ARRAY_BUFFER,gpu.vbVBO);
  gl.bufferSubData(gl.ARRAY_BUFFER,0,V.live);
  refreshVbReadout();
}

/* The read-out that answers "what is my file actually supplying": the payload
   counters, and the two probe lookups a real engine would do for this entity
   (cAmbientCube at the entity origin, the per-pixel lookup at the point). */
function refreshVbReadout(){
  const el=document.getElementById("vbread"); if(!el||!gpu.vb) return;
  const V=gpu.vb, L=[];
  L.push("file     "+V.name+" \u00b7 "+V.nverts+" verts \u00b7 "+V.meshes.length+" meshes");
  L.push("meshes   "+V.meshes.map(m=>m.material+"("+m.vertexCount+"v/"+m.indexCount/3+"t)").join("  "));
  L.push("targets  "+V.targets.length+" flexes, active "+(V.targets[state.model.vbSel].name)+
         " @ "+state.model.vbWeight.toFixed(2)+(state.model.vbMirror?" (+mirror)":""));
  L.push("cube@origin "+(V.cube?LG.fmt(LG.ambientLight([0,1,0],V.cube)):"\u2014")+
         "   cube@eye "+(V.headCube?LG.fmt(LG.ambientLight([0,1,0],V.headCube)):"\u2014"));
  el.textContent=L.join("\n");
}
'''
anchor2 = "/* Uniforms, set by the type the driver reports rather than by guesswork:"
assert s.count(anchor2) == 1
s = s.replace(anchor2, HELPERS + "\n" + anchor2)

io.open(P, "w", encoding="utf-8").write(s)
print("template: draw + helpers in")
