#!/usr/bin/env python3
"""Bake an Alyx-style skin material set for a VBMOD model.

The VBMOD carries geometry, UVs and base normals -- no textures at all.  This
module invents the four maps the ported shader wants and bakes them into the
model's own UV atlas, so the material that comes out is a real texture set for
*that* mesh, not a swatch:

    albedo   (RGB)      skin tone, mottling, freckles, brows, lips, blush, hair
    normal   (RGBA)     tangent-space normal, alpha = phong mask
                        (skin_ps20b.fxc's fSpecMask defaults to $bumpmap's alpha)
    exponent (R)        what texture() returns for 1 + 149 * r
    lightwarp(1D)       the Ep1 $lightwarptexture ramp (shared with the port)

How a face ends up on an arbitrary model: the *geometry* tells us where the
face is.  Each eyeball is its own mesh, so the eye centres give the face
origin, the eyeball midpoint minus the head centroid gives the forward axis,
and the model's own up axis (+Z in this format) gives the frame.  Every texel
of the atlas is then mapped back to a 3D point by barycentric rasterisation of
the triangles, and the face features are painted in that 3D frame -- so the
eyes, brows, lips and hairline land on the model's actual face, whatever its UV
layout is.  Only the *style* is a stand-in: there is no Alyx VTF here, so the
skin tone, freckles and colours are synthesised, exactly like the stand-in
head's maps in textures.py.
"""
from __future__ import annotations

import base64
import io
import json
from pathlib import Path

import numpy as np

import textures as tex
import vbmod as vbmod_mod

# ---------------------------------------------------------------- utilities


def _hash_noise(shape, seed, base=6, octaves=4):
    return tex._fbm(shape, seed, octaves=octaves, base=base)


def _smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a + 1e-9), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def face_frame(m: dict) -> dict:
    """Derive the face frame from the model's own eyeball meshes.

    Everything here is measured off the geometry, because a VBMOD has no
    skeleton convention attached to the *texture* job: the format says which
    axis is up (+Z) and the eyeball meshes say where the face is.  The two
    eyes give the origin (their midpoint), the lateral axis (eye to eye) and
    the scale (the interpupillary distance -- human anatomy supplies the rest
    of the proportions, in units of that distance).

    The forward axis is the one the model does *not* state, so it is settled
    by measuring instead of guessing: take the vertices within a few eye
    separations of the eye midpoint, average them (that is the skull's own
    centre) and point forward from there to the eyes.  Eyes sit in the front
    half of a head, so the sign that makes `mid - skull_centre` positive is
    the face's forward.
    """
    pos = m["positions"]
    body = max(m["meshes"], key=lambda mm: mm["vertex_count"])
    centres = []
    for mesh in m["meshes"]:
        if "eyeball" not in mesh["name"] and "eye" not in mesh["material"]:
            continue
        fv, vc = mesh["first_vertex"], mesh["vertex_count"]
        centres.append(pos[fv:fv + vc].mean(0))
    if len(centres) < 2:
        raise ValueError("no eyeball meshes -- cannot find the face")
    centres = np.asarray(centres, np.float32)
    order = np.argsort(centres[:, 0])
    pa, pb = centres[order[0]], centres[order[1]]        # pa has the smaller x

    up = np.array([0.0, 0.0, 1.0], np.float32)           # VBMOD is Z-up
    mid = 0.5 * (pa + pb)
    eye_sep = float(np.linalg.norm(pa - pb))
    lat = pb - pa                                        # +x is the model's own left
    lat -= up * np.dot(lat, up)
    lat /= np.linalg.norm(lat)
    fwd = np.cross(lat, up)
    fwd /= np.linalg.norm(fwd)

    fv, vc = body["first_vertex"], body["vertex_count"]
    P = pos[fv:fv + vc]
    near = np.linalg.norm(P - mid, axis=1) < 2.8 * eye_sep
    skull = P[near]
    if np.dot(mid - skull.mean(0), fwd) < 0.0:
        fwd = -fwd
    # measured extents of the head, in interpupillary units
    q = (skull - mid)
    s_ = q @ lat / eye_sep
    t_ = q @ up / eye_sep
    f_ = q @ fwd / eye_sep
    crown = float(np.quantile(t_, 0.995))
    chin = float(max(np.quantile(t_, 0.005), crown - 3.9))
    side = float(np.quantile(np.abs(s_), 0.995))
    back = float(np.quantile(-f_, 0.995))
    return dict(origin=mid, lat=lat, up=up, fwd=fwd, eye_sep=eye_sep,
                eye_a=pa, eye_b=pb, skull_centre=skull.mean(0).astype(np.float32),
                crown_t=crown, chin_t=chin, side_s=side, back_f=back,
                head_top=float(skull[:, 2].max()),
                scale=eye_sep)


def tangents(m: dict, mesh_index: int):
    """Per-vertex tangents (xyz) + handedness (w) from positions and UVs.

    VBMOD has no tangent space -- the fixed vertex record is position, UV, four
    joint indices, four weights -- so the frame the normal map needs has to be
    built from the UV parametrisation, which is what this does: accumulate the
    per-triangle derivative and orthonormalise against the base normal.
    """
    mesh = m["meshes"][mesh_index]
    fv, vc = mesh["first_vertex"], mesh["vertex_count"]
    fi, ic = mesh["first_index"], mesh["index_count"]
    P = m["positions"][fv:fv + vc].astype(np.float64)
    UV = m["uvs"][fv:fv + vc].astype(np.float64)
    N = m["normals"][fv:fv + vc].astype(np.float64)
    idx = m["indices"][fi:fi + ic].reshape(-1, 3).astype(np.int64) - fv

    tan = np.zeros((vc, 3)); bit = np.zeros((vc, 3))
    e1 = P[idx[:, 1]] - P[idx[:, 0]]
    e2 = P[idx[:, 2]] - P[idx[:, 0]]
    d1 = UV[idx[:, 1]] - UV[idx[:, 0]]
    d2 = UV[idx[:, 2]] - UV[idx[:, 0]]
    det = d1[:, 0] * d2[:, 1] - d2[:, 0] * d1[:, 1]
    r = np.where(np.abs(det) < 1e-12, 0.0, 1.0 / np.where(det == 0, 1.0, det))[:, None]
    T = (e1 * d2[:, 1:2] - e2 * d1[:, 1:2]) * r
    B = (e2 * d1[:, 0:1] - e1 * d2[:, 0:1]) * r
    for k in range(3):
        np.add.at(tan, idx[:, k], T)
        np.add.at(bit, idx[:, k], B)
    n = np.linalg.norm(tan, axis=1, keepdims=True)
    bad = (n[:, 0] < 1e-9)
    tan = tan / np.where(n == 0, 1.0, n)
    tan[bad] = np.array([1.0, 0.0, 0.0])
    # Gram-Schmidt against the base normal, then handedness from the bitangent
    tan -= N * np.sum(tan * N, axis=1, keepdims=True)
    n = np.linalg.norm(tan, axis=1, keepdims=True)
    tan = tan / np.where(n == 0, 1.0, n)
    w = np.sign(np.sum(np.cross(N, tan) * bit, axis=1))
    w[w == 0] = 1.0
    return tan.astype(np.float32), w.astype(np.float32)


def dilate_uv(pos, nrm, cov, passes: int = 4):
    """Fill uncovered texels from their covered neighbours, in UV space.

    A UV island whose triangles are thinner than a texel leaves texels whose
    centres no triangle reaches -- and every one of those texels is a hole in
    the *material*, not in the mesh (the model samples them).  Dilating the
    rasterised position/normal buffers outward fixes that, and because the look
    is evaluated *after* the fill, the new texels come out with the skin that
    belongs at their 3D point rather than a smear of their neighbour's uv.
    """
    pos = pos.copy(); nrm = nrm.copy(); cov = cov.copy()
    for _ in range(passes):
        hole = cov <= 0
        if not hole.any():
            break
        accp = np.zeros_like(pos); accn = np.zeros_like(nrm)
        cnt = np.zeros(cov.shape, np.float32)
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    continue
                sp = np.roll(np.roll(pos, dy, 0), dx, 1)
                sn = np.roll(np.roll(nrm, dy, 0), dx, 1)
                sc = np.roll(np.roll(cov > 0, dy, 0), dx, 1).astype(np.float32)
                accp += sp * sc[..., None]
                accn += sn * sc[..., None]
                cnt += sc
        fill = hole & (cnt > 0)
        pos[fill] = accp[fill] / cnt[fill][:, None]
        nn = accn[fill] / cnt[fill][:, None]
        ln = np.maximum(np.linalg.norm(nn, axis=-1, keepdims=True), 1e-9)
        nrm[fill] = nn / ln
        cov[fill] = -1.0                     # filled: sampled, but not measured
    return pos, nrm, cov


def atlas_rect(m: dict, mesh_index: int, pad=0.06):
    mesh = m["meshes"][mesh_index]
    fv, vc = mesh["first_vertex"], mesh["vertex_count"]
    UV = m["uvs"][fv:fv + vc]
    return (float(UV[:, 0].min() - pad), float(UV[:, 0].max() + pad),
            float(UV[:, 1].min() - pad), float(UV[:, 1].max() + pad))


def rasterize_uv(m: dict, mesh_index: int, W: int, H: int, rect=None):
    """Map every atlas texel back to the surface: (pos, normal, coverage).

    Plain scanline rasterisation in UV space, barycentric inside each triangle.
    The result is what makes a *3D-defined* look composable with an arbitrary
    UV layout: features are evaluated at the texel's 3D point, not at its uv.
    """
    u0, u1, v0, v1 = rect or atlas_rect(m, mesh_index)
    mesh = m["meshes"][mesh_index]
    fv, vc = mesh["first_vertex"], mesh["vertex_count"]
    fi, ic = mesh["first_index"], mesh["index_count"]
    P = m["positions"][fv:fv + vc]
    N = m["normals"][fv:fv + vc]
    UV = m["uvs"][fv:fv + vc]
    idx = (m["indices"][fi:fi + ic].reshape(-1, 3).astype(np.int64) - fv)

    pos = np.zeros((H, W, 3), np.float32)
    nrm = np.zeros((H, W, 3), np.float32)
    cov = np.zeros((H, W), np.float32)

    # texel centres -> uv
    us = u0 + (np.arange(W) + 0.5) / W * (u1 - u0)
    vs = v0 + (np.arange(H) + 0.5) / H * (v1 - v0)

    # triangle setup in uv space
    tuv = UV[idx]                                     # (t,3,2)
    x0, y0 = tuv[:, 0, 0], tuv[:, 0, 1]
    x1, y1 = tuv[:, 1, 0], tuv[:, 1, 1]
    x2, y2 = tuv[:, 2, 0], tuv[:, 2, 1]
    area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)
    keep = np.abs(area) > 1e-12
    idx_k, area_k = idx[keep], area[keep]
    x0, y0, x1, y1, x2, y2 = (a[keep] for a in (x0, y0, x1, y1, x2, y2))
    inv_area = 1.0 / area_k
    ymin = np.floor((np.minimum(np.minimum(y0, y1), y2) - v0) / (v1 - v0) * H).astype(int)
    ymax = np.ceil((np.maximum(np.maximum(y0, y1), y2) - v0) / (v1 - v0) * H).astype(int)
    for t in range(len(idx_k)):
        j0, j1 = max(ymin[t], 0), min(ymax[t] + 1, H)
        if j0 >= j1:
            continue
        py = vs[j0:j1]
        # barycentric via edge functions, vectorised over the scanline
        px = us
        d = inv_area[t]
        l1 = ((px[None, :] - x0[t]) * (y2[t] - y0[t]) - (py[:, None] - y0[t]) * (x2[t] - x0[t])) * d
        l2 = ((px[None, :] - x0[t]) * (y1[t] - y0[t]) - (py[:, None] - y0[t]) * (x1[t] - x0[t])) * -d
        l0 = 1.0 - l1 - l2
        m3 = (l0 >= 0) & (l1 >= 0) & (l2 >= 0)
        if not m3.any():
            continue
        q = np.stack([l0, l1, l2], -1)[m3]
        tri = idx_k[t]
        pos[j0:j1][m3] = q @ P[tri]
        nn = q @ N[tri]
        nrm[j0:j1][m3] = nn / np.maximum(np.linalg.norm(nn, axis=-1, keepdims=True), 1e-9)
        cov[j0:j1][m3] = 1.0
    return pos, nrm, cov


# ---------------------------------------------------------------- the look

# Alyx's own skin is a masked cubemap + phong 6 + halflambert (see the VMT in
# material_set/), and the port's skin shader is what shades this.  The *pixels*
# are invented here: pale warm skin, freckles across the nose, dark hair with a
# fringe, rosy lips.  Nothing is sampled from a Valve texture.
# The same linear reflectances textures.py gives the port's stand-in head, so
# the two models read as the same character under the same shader -- skin
# [0.62 0.44 0.36], lips [0.62 0.26 0.26], hair [0.12 0.10 0.10].
SKIN = np.array([0.60, 0.43, 0.35], np.float32)
SKIN_DEEP = np.array([0.40, 0.26, 0.21], np.float32)
LIP = np.array([0.60, 0.26, 0.26], np.float32)
# Linear-space reflectances, not display colours: the page (and render.py) run
# a linear pipeline and tonemap with pow(1/2.2), so a "dark brown hair" is
# ~4-6% here, not the 30% it would be in an sRGB paint program.
HAIR = np.array([0.10, 0.070, 0.055], np.float32)
BROW = np.array([0.14, 0.095, 0.070], np.float32)


def bake(m: dict, mesh_index: int | None = None, W: int = 1536, H: int | None = None,
         seed: int = 11, verbose: bool = True, dilate: int = 4):
    """Bake albedo / normal+mask / exponent in the model's own UV atlas.

    All the feature sizes below are in *interpupillary units*, which is the one
    length the geometry and human anatomy agree on (63 mm average).  The frame
    is measured, but the proportions -- where a brow sits above a pupil, how
    wide a mouth is, where the hairline is -- are the standard ones.  Nothing
    is sampled from a Valve texture; the *colour* is synthesised too.
    """
    fr = face_frame(m)
    if mesh_index is None:
        mesh_index = max(range(len(m["meshes"])), key=lambda i: m["meshes"][i]["vertex_count"])
    rect = atlas_rect(m, mesh_index)
    if H is None:
        # one texel size for both axes: the atlas rectangle is what the model's
        # UVs cover, so the image should have that aspect -- bake it square-ish
        # and the features are stretched (the first attempt did exactly that)
        H = max(64, int(round(W * (rect[3] - rect[2]) / (rect[1] - rect[0]))))
    pos, nrm, cov = rasterize_uv(m, mesh_index, W, H, rect)
    raw_cov = float((cov > 0).mean())
    pos, nrm, cov = dilate_uv(pos, nrm, cov, passes=dilate)
    if verbose:
        print(f"[skin] atlas {W}x{H}  rect aspect {(rect[1]-rect[0])/(rect[3]-rect[2]):.3f}"
              f"  rasterised {100*raw_cov:.1f}%  after {dilate} dilate passes"
              f" {100*float((cov != 0).mean()):.1f}%")
    if verbose:
        print(f"[skin] atlas {W}x{H} over u[{rect[0]:.2f},{rect[1]:.2f}] "
              f"v[{rect[2]:.2f},{rect[3]:.2f}]  covered texels {100*cov.mean():.1f}%")
        print(f"[skin] head frame: eye_sep {fr['eye_sep']:.2f}u  crown t=+{fr['crown_t']:.2f}"
              f"  chin t={fr['chin_t']:.2f}  side |s|<={fr['side_s']:.2f}"
              f"  back -f<={fr['back_f']:.2f}  (units of the eye separation)")

    # face-local coordinates, in units of the interpupillary distance
    q = pos - fr["origin"]
    s = (q @ fr["lat"]) / fr["eye_sep"]             # + toward the model's left eye
    t = (q @ fr["up"]) / fr["eye_sep"]              # + up  (the eye line is t = 0)
    f = (q @ fr["fwd"]) / fr["eye_sep"]             # + toward the viewer

    # ---- where the head is: measured, not assumed --------------------------
    C, T_ = fr["chin_t"], fr["crown_t"]
    # the crown is *inside* the head: the vertical fade has to start above the
    # measured crown, or the hair fades out exactly where the skull is
    head_z = (_smoothstep(C - 0.55, C + 0.25, t) * (1.0 - _smoothstep(T_ + 0.25, T_ + 0.60, t)))
    head_x = 1.0 - _smoothstep(fr["side_s"] * 0.85, fr["side_s"] * 1.30, np.abs(s))
    head_b = 1.0 - _smoothstep(fr["back_f"] * 0.80, fr["back_f"] * 1.25, -f)
    head = np.clip(head_z * head_x * head_b, 0.0, 1.0)
    frontness = _smoothstep(-0.05, 0.50, f)         # the face itself: in front of the eye plane
    face = np.clip(head * frontness, 0.0, 1.0)

    n_big = _hash_noise((H, W), seed + 3, base=3, octaves=4)      # mottling
    n_mid = _hash_noise((H, W), seed + 17, base=9, octaves=4)     # blotches
    n_fine = _hash_noise((H, W), seed + 29, base=26, octaves=3)   # pores
    n_freck = _hash_noise((H, W), seed + 41, base=28, octaves=2)  # freckles

    # ---- hair: above the hairline, plus the back of the skull --------------
    hairline = T_ - 0.57
    hair_top = _smoothstep(hairline - 0.18, hairline + 0.22, t)
    # ...but not over the ears: they sit at the widest part of the skull and
    # further back than the eye plane, so without this gate a bob of hair grows
    # over them.
    ears = 1.0 - _smoothstep(0.70 * fr["side_s"], 0.95 * fr["side_s"], np.abs(s))
    hair_back = (_smoothstep(0.15, 0.85, -f) * _smoothstep(C + 0.30, C + 1.10, t)
                 * (0.25 + 0.75 * ears))
    hair = np.clip((hair_top + hair_back - hair_top * hair_back) * head, 0.0, 1.0)

    # ---- face features (all in interpupillary units) -----------------------
    # The frame is measured; the *proportions* are the standard anthropometric
    # ones, and they are worth writing down because they are the whole reason
    # this lands on the face: with 1.0 = the interpupillary distance (~63 mm),
    #   brow ridge      t = +0.40      (pupil to brow        ~25 mm)
    #   hairline        t = +1.19      (pupil to hairline    ~75 mm)
    #   crown           t = +1.76      (pupil to crown      ~110 mm -- measured)
    #   nose tip        t = -0.63      (pupil to nose tip    ~40 mm)
    #   mouth line      t = -0.85      (pupil to mouth       ~55 mm)
    #   chin            t = -1.95      (pupil to chin       ~120 mm)
    #   mouth width     0.85 across, nose width 0.35, eye socket 0.60
    lips = np.exp(-(((s - 0.0) / 0.40) ** 2 + ((t + 0.85) / 0.19) ** 2) * 2.2)
    mouthline = np.exp(-(((s - 0.0) / 0.38) ** 2 + ((t + 0.85) / 0.040) ** 2) * 2.0)
    brow_l = np.exp(-(((s + 0.52) / 0.40) ** 2 + ((t - 0.40) / 0.11) ** 2) * 2.0)
    brow_r = np.exp(-(((s - 0.52) / 0.40) ** 2 + ((t - 0.40) / 0.11) ** 2) * 2.0)
    brow = np.clip(brow_l + brow_r, 0, 1)
    socket = np.clip(np.exp(-(((s + 0.50) / 0.42) ** 2 + ((t - 0.04) / 0.26) ** 2) * 2.0)
                     + np.exp(-(((s - 0.50) / 0.42) ** 2 + ((t - 0.04) / 0.26) ** 2) * 2.0), 0, 1)
    nose = np.exp(-(((s) / 0.17) ** 2 + ((t + 0.40) / 0.45) ** 2) * 2.0)
    nostrils = (np.exp(-(((s + 0.15) / 0.09) ** 2 + ((t + 0.56) / 0.07) ** 2) * 2.0)
                + np.exp(-(((s - 0.15) / 0.09) ** 2 + ((t + 0.56) / 0.07) ** 2) * 2.0))
    cheeks = (np.exp(-(((s + 0.80) / 0.45) ** 2 + ((t + 0.18) / 0.34) ** 2) * 2.0)
              + np.exp(-(((s - 0.80) / 0.45) ** 2 + ((t + 0.18) / 0.34) ** 2) * 2.0))

    # ---- albedo ------------------------------------------------------------
    albedo = (SKIN[None, None, :] * (0.93 + 0.14 * n_big[..., None])
              + SKIN_DEEP[None, None, :] * 0.18 * (1.0 - face)[..., None]
              + SKIN_DEEP[None, None, :] * 0.10 * n_mid[..., None] * face[..., None])
    albedo *= 0.975 + 0.05 * n_fine[..., None]
    freck = np.clip((n_freck - 0.70) * 7.0, 0, 1) * face * (0.20 + 0.80 * np.maximum(nose, cheeks))
    albedo = albedo * (1.0 - 0.35 * freck[..., None]) + np.array([0.33, 0.20, 0.14]) * (0.35 * freck[..., None])
    albedo += 0.12 * cheeks[..., None] * face[..., None] * np.array([0.95, 0.52, 0.50])
    albedo -= 0.10 * socket[..., None] * face[..., None]
    albedo = albedo * (1.0 - 0.75 * brow[..., None] * face[..., None]) + BROW * (0.75 * brow[..., None] * face[..., None])
    albedo = albedo * (1.0 - 0.85 * lips[..., None] * face[..., None]) + LIP * (0.85 * lips[..., None] * face[..., None])
    albedo -= 0.30 * mouthline[..., None] * face[..., None]
    albedo -= 0.06 * nostrils[..., None] * face[..., None]
    albedo = albedo * (1.0 - hair[..., None]) + HAIR * hair[..., None]
    albedo += 0.012 * (n_fine[..., None] - 0.5) * (1.0 - hair[..., None])
    albedo = np.clip(albedo, 0.0, 1.0)

    # ---- height -> tangent-space normal (alpha = phong mask) ---------------
    height = (0.35 * n_fine + 0.20 * n_mid
              + 0.22 * lips - 0.35 * mouthline + 0.10 * brow
              + 0.06 * nose - 0.05 * nostrils + 0.20 * freck)
    height = np.where(cov > 0, height, 0.0)
    strength = 0.9 * (1.0 - 0.7 * hair)
    nz = np.ones_like(height)
    gy, gx = np.gradient(height)
    nx = -gx * 26.0 * strength
    ny = -gy * 26.0 * strength
    ln = np.sqrt(nx * nx + ny * ny + nz * nz)
    normal = np.stack([nx / ln, ny / ln, nz / ln], -1).astype(np.float32)

    phong_mask = np.clip(0.85 * (1.0 - 0.75 * hair) * (0.75 + 0.25 * (1.0 - lips)), 0, 1)

    # ---- exponent map: oily T-zone, softer lips and hair -------------------
    expo = (0.22 + 0.28 * face + 0.18 * nose + 0.10 * (1.0 - lips)
            - 0.12 * lips - 0.10 * hair + 0.06 * (n_big - 0.5))
    expo = np.clip(expo, 0.02, 0.95)

    return dict(albedo=albedo, normal=normal, phong_mask=phong_mask,
                exponent=expo, height=height, coverage=cov, rect=rect,
                frame=fr, mesh_index=mesh_index,
                masks=dict(head=head, face=face, hair=hair),
                _pos=pos, _nrm=nrm)


def lightwarp_ramp():
    """The Ep1 lightwarp ramp as a 1x256 RGB texture -- the same function the
    stand-in head ships (textures.synth_lightwarp), so $lightwarptexture means
    one thing in this port."""
    return tex.synth_lightwarp()


def data_uris(bake_result: dict, res_w: int = 1024, warp=None):
    """PNG data URIs for the viewer, at display resolution.

    The bake runs at full atlas resolution; the page gets a smaller copy so the
    HTML stays a *file* rather than a download.  8 bits is all a human sees in
    an albedo; the exporter says so in the notes.
    """
    from PIL import Image
    u0, u1, v0, v1 = bake_result["rect"]
    H = max(32, int(round(res_w * (v1 - v0) / (u1 - u0))))
    def uri(a, mode, scale=1.0, jpeg=None):
        w = max(16, int(round(res_w * scale)))
        h = max(16, int(round(H * scale)))
        img = Image.fromarray((np.clip(a, 0, 1) * 255 + 0.5).astype(np.uint8), mode)
        if img.size != (w, h):
            img = img.resize((w, h), Image.LANCZOS)
        buf = io.BytesIO()
        if jpeg:
            img.convert("RGB").save(buf, format="JPEG", quality=jpeg, optimize=True)
            mime = "image/jpeg"
        else:
            img.save(buf, format="PNG", optimize=True)
            mime = "image/png"
        return ("data:" + mime + ";base64,"
                + base64.b64encode(buf.getvalue()).decode("ascii"))
    n = bake_result["normal"].copy()
    n[..., 0] = n[..., 0] * 0.5 + 0.5
    n[..., 1] = n[..., 1] * 0.5 + 0.5
    rgba = np.concatenate([n, bake_result["phong_mask"][..., None]], -1)
    expo = np.repeat(bake_result["exponent"][..., None], 3, -1)
    # The albedo is the one a human looks at, so it keeps the most texels and
    # travels as JPEG; the normal map's alpha is the phong mask and must not be
    # JPEG'd, and the exponent map is smooth, so both stay PNG at half size.
    return dict(albedo=uri(bake_result["albedo"], "RGB", 1.0, jpeg=92),
                normal=uri(rgba, "RGBA", 0.5),
                exponent=uri(expo, "RGB", 0.5),
                lightwarp=uri(np.asarray(warp if warp is not None else lightwarp_ramp()), "RGB"))


def preview_front(bake_result: dict, out_png: str, size: int = 900,
                  zoom_units: float | None = None, dilate: int = 3, key=None):
    """A flat front view of the skin, straight off the baked atlas.

    This exists to *verify the bake*: every covered texel knows the 3D point it
    belongs to, so the texels can be splatted back into a front orthographic
    view (frontmost sample wins), holes filled by dilation because a sparse
    atlas region maps fewer texels than the view has pixels.  What you see is
    the model's own skin shaded with one Lambert key -- no GPU, no scene, no
    viewer.  If the face is on the face, the frame and the feature placement
    are right.  `zoom_units` crops to that many model units across (for
    checking the face); the default frames the whole model.
    """
    from PIL import Image
    fr = bake_result["frame"]
    pos, nrm, alb = bake_result["_pos"], bake_result["_nrm"], bake_result["albedo"]
    cam_axis = np.cross(fr["up"], fr["lat"])                   # viewing direction
    if np.dot(cam_axis, fr["fwd"]) < 0:
        cam_axis = -cam_axis
    q = pos - fr["origin"]
    sx = (q @ fr["lat"])
    sy = (q @ fr["up"])
    dp = (q @ cam_axis)
    if key is None:
        key = fr["up"] * 0.45 + fr["lat"] * -0.35 + cam_axis * 0.75
    key = np.asarray(key, np.float32)
    key /= np.linalg.norm(key)
    lam = np.clip(nrm @ key, 0.0, 1.0)
    rgb = alb * (0.30 + 0.85 * lam[..., None])
    rgb = rgb / (1.0 + rgb) * 1.55                              # soft tonemap

    if zoom_units is None:
        lo = np.array([sx.min(), sy.min()])
        hi = np.array([sx.max(), sy.max()])
        cx, cy = (lo + hi) * 0.5
        span = max((hi - lo).max(), 1e-6)
    else:
        cx = cy = 0.0
        span = float(zoom_units)
    W = H = size
    scale = (size * 0.92) / span
    px = (sx - cx) * scale + W * 0.5
    py = H * 0.5 - (sy - cy) * scale
    ix = np.clip(px.astype(np.int32), 0, W - 1)
    iy = np.clip(py.astype(np.int32), 0, H - 1)
    ok = bake_result["coverage"] > 0
    order = np.argsort(dp[ok])                                  # far to near
    flat = np.zeros((H, W, 3), np.float32)
    X = ix[ok][order]; Y = iy[ok][order]; C = rgb[ok][order]
    flat[Y, X] = C
    bg = (flat.sum(-1) <= 1e-6)
    for _ in range(dilate):
        acc = np.zeros_like(flat); cnt = np.zeros((H, W), np.float32)
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    continue
                sh = np.roll(np.roll(flat, dy, 0), dx, 1)
                shm = np.roll(np.roll(~bg, dy, 0), dx, 1)
                acc += sh * shm[..., None]
                cnt += shm
        fill = bg & (cnt > 0)
        flat[fill] = acc[fill] / cnt[fill][:, None]
        bg = bg & ~fill
    flat[bg] = 0.05
    Image.fromarray((np.clip(flat, 0, 1) * 255 + 0.5).astype(np.uint8), "RGB").save(out_png)
    return out_png


def write(outdir: str, bake_result: dict, model_name: str = "leanna",
          material="xana", vmt_text: str | None = None, verbose=True):
    """Write the maps + a .vmt + a .vbm stub next to them."""
    from PIL import Image
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    name = f"{material}_skin"
    res = {}
    a = (np.clip(bake_result["albedo"], 0, 1) * 255 + 0.5).astype(np.uint8)
    Image.fromarray(a, "RGB").save(out / f"{name}_albedo.png")
    n = bake_result["normal"].copy()
    n[..., 0] = n[..., 0] * 0.5 + 0.5
    n[..., 1] = n[..., 1] * 0.5 + 0.5
    n[..., 2] = n[..., 2] * 0.5 + 0.5
    rgba = np.concatenate([(n * 255 + 0.5).astype(np.uint8),
                           (bake_result["phong_mask"][..., None] * 255 + 0.5).astype(np.uint8)], -1)
    Image.fromarray(rgba, "RGBA").save(out / f"{name}_normal.png")
    Image.fromarray((bake_result["exponent"] * 255 + 0.5).astype(np.uint8), "L").save(
        out / f"{name}_exponent.png")
    warp = lightwarp_ramp()
    Image.fromarray((np.clip(warp, 0, 1) * 255 + 0.5).astype(np.uint8), "RGB").save(
        out / "lightwarp.png")
    res["files"] = sorted(p.name for p in out.glob(f"{name}_*"))
    res["lightwarp"] = "lightwarp.png"

    if vmt_text is not None:
        (out / f"{material}.vmt").write_text(vmt_text)
        res["vmt"] = f"{material}.vmt"
    if verbose:
        print(f"[skin] wrote {len(res['files'])} maps + {res.get('vmt','no vmt')} to {out}")
    return res


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description="bake a skin material set for a .vbmod")
    ap.add_argument("model")
    ap.add_argument("--out", default="/home/user/hl2shader/material_set/vbmod")
    ap.add_argument("-W", type=int, default=1536)
    ap.add_argument("-H", type=int, default=None)
    ap.add_argument("--preview", default=None, help="write a PNG preview of the maps")
    ap.add_argument("--front", default=None, help="write a shaded front view of the baked skin")
    args = ap.parse_args(argv)

    m = vbmod_mod.read(args.model)
    print(vbmod_mod.summary(m))
    res = bake(m, W=args.W, H=args.H)
    write(args.out, res)
    if args.preview:
        from PIL import Image
        a = (res["albedo"] * 255).astype(np.uint8)
        Image.fromarray(a, "RGB").save(args.preview)
        print("preview ->", args.preview)
    if args.front:
        print("front view ->", preview_front(res, args.front))


if __name__ == "__main__":
    main()


# ---------------------------------------------------------------- viewer glue

def place(m: dict, eye_height: float = 0.25, head_height: float = 1.24):
    """A world transform for the viewer: VBMOD is Z-up facing -Y, the viewer's
    room is Y-up with the model facing -Z (the camera sits at -Z).

    (x, y, z) -> (-x, z, y) is the rotation -- determinant +1, so winding and
    the tangent frames survive -- and the scale puts the head at the size of
    the stand-in it replaces.  Baked into the vertices; the eye material keeps
    the transformed centres so it can sample the probe field at the right spot.
    """
    fr = face_frame(m)
    R = np.array([[0.0, 0.0, 1.0], [-1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], np.float32)
    # rows: world_x = -model_x ?  build it explicitly instead of guessing:
    #   world = ( -x, z, y )  ->  rows [[-1,0,0],[0,0,1],[0,1,0]]
    R = np.array([[-1.0, 0.0, 0.0], [0.0, 0.0, 1.0], [0.0, 1.0, 0.0]], np.float32)
    body = max(m["meshes"], key=lambda mm: mm["vertex_count"])
    fv, vc = body["first_vertex"], body["vertex_count"]
    P = m["positions"][fv:fv + vc]
    # the head's *measured* span, from the crown down 3.71 interpupillary
    # distances (crown-to-chin is ~230 mm against a 63 mm interpupillary, and
    # the frame already measured the crown in skull radii) -- the chin is the
    # one landmark no amount of geometry alone can pick out, because the neck
    # starts there.
    top = fr["origin"][2] + fr["crown_t"] * fr["eye_sep"]
    chin = top - 3.71 * fr["eye_sep"]
    scale = head_height / max(top - chin, 1e-3)
    eye_world = (R @ fr["origin"]) * scale
    offset = np.array([0.0, eye_height - eye_world[1], -eye_world[2]], np.float32)
    def xf(P):
        return (P @ R.T) * scale + offset
    return dict(R=R, scale=float(scale), offset=offset, xf=xf, frame=fr,
                eye_world=xf(fr["origin"][None, :])[0],
                head_span=(chin, top))


def _f16(a):
    return np.asarray(a, np.float32).astype(np.float16)


def _u16(a):
    return np.asarray(a, np.uint16)


def _eye_sphere_unit(nu: int = 40, nv: int = 28):
    """The Eyeball sphere the eye shader expects, as *unit* geometry in the
    viewer's own convention (pole at -Z = the iris axis).  Same generator the
    stand-in head uses, so both models' eyes are the same asset."""
    import model as model_mod
    m = model_mod.build_eye_sphere(radius=1.0, nu=nu, nv=nv)
    return (m.positions, m.normals, m.uvs, m.tangents, m.bitangents, m.indices)


def _rot_from_to(a, b):
    """Shortest-arc rotation taking `a` to `b` (both normalised)."""
    a = np.asarray(a, np.float64); b = np.asarray(b, np.float64)
    a = a / np.linalg.norm(a); b = b / np.linalg.norm(b)
    v = np.cross(a, b); c = float(np.dot(a, b))
    if c < -0.999999:                       # opposite: any perpendicular axis
        axis = np.cross(a, [1.0, 0.0, 0.0])
        if np.linalg.norm(axis) < 1e-6:
            axis = np.cross(a, [0.0, 1.0, 0.0])
        axis /= np.linalg.norm(axis)
        K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
        return np.eye(3) + 2.0 * (K @ K)
    K = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + K + K @ K * (1.0 / (1.0 + c))


def viewer_section(m: dict, bake_result: dict, materials: dict, vmt_text: str,
                   name: str = "leanna.vbmod", map_res_w: int = 1024,
                   eye_bulge: float = 0.12, eye_radius_frac: float = 0.50,
                   verbose: bool = True) -> dict:
    """Everything web_export needs to draw this model with the ported shaders.

    The vertex payload is the file's own geometry, transformed once (the same
    place() the offline path can reuse) and interleaved as

        pos3 nrm3 uv2 tan3 sign1        -- 12 floats, no joint data

    which is the *adapter* this format needs: VBMOD stores joints and weights
    and no tangent space, and the renderer wants a tangent frame and no joints.
    The joints are not dropped by accident: the port's vertex program is a
    rigid-transform one (see the porting text), so the skin is baked in bind
    pose here and the deform layer is the VBFLX1 flex stream, exactly as the
    format's own C++ applies it.
    """
    def b64(a):
        return base64.b64encode(np.ascontiguousarray(a).tobytes()).decode("ascii")

    pl = place(m)
    xf = pl["xf"]
    P = xf(m["positions"])
    N = m["normals"] @ pl["R"].T
    UV = m["uvs"].copy()
    # The entity origin: the bottom centre of the geometry *as drawn*, which is
    # the point a map places and a lightcache lookup uses.  The file's own
    # origin (0,0,0) sits on the ground far below this bust, so using it here
    # would mean asking the probe grid about a point outside the model.
    bottom, top = P.min(0), P.max(0)
    origin = np.array([0.5 * (bottom[0] + top[0]), bottom[1], 0.5 * (bottom[2] + top[2])], np.float32)

    T = np.zeros_like(P); W = np.zeros(len(P), np.float32)
    for i in range(len(m["meshes"])):
        t, w = tangents(m, i)
        mm = m["meshes"][i]
        fv, vc = mm["first_vertex"], mm["vertex_count"]
        T[fv:fv + vc] = t @ pl["R"].T
        W[fv:fv + vc] = w

    # ---- the UVs, remapped into the atlas -----------------------------------
    # The converter leaves the UVs in the *source model's* ranges -- for leanna
    # u [-0.603, 1.000], v [0.317, 2.991], because the SMD it came from does and
    # VBMOD stores them verbatim.  A single 0..1 texture atlas is what the
    # material layer wants (and what a .vtf would be), so the renderer maps the
    # body mesh's own UV rectangle onto [0,1] -- exactly the rectangle the skin
    # atlas is baked over (bake()'s `rect`).  This is a renderer-side choice,
    # not a change to the file: the bytes still carry the original UVs, and
    # vbmod.py prints them.
    u0, u1, v0, v1 = bake_result["rect"]
    uv_rect = np.array([u0, u1, v0, v1], np.float32)
    UV = UV.copy()
    UV[:, 0] = (UV[:, 0] - u0) / (u1 - u0)
    UV[:, 1] = (UV[:, 1] - v0) / (v1 - v0)

    verts = np.concatenate([P, N, UV, T, W[:, None]], 1).astype(np.float32)
    idx = m["indices"].astype(np.uint32)
    use16 = bool(idx.max() < 65536)

    # ---- meshes: which draw, and with which program ------------------------
    meshes, eyeball_discs = [], []
    for mm in m["meshes"]:
        fv, vc = mm["first_vertex"], mm["vertex_count"]
        fi, ic = mm["first_index"], mm["index_count"]
        is_eye = ("eye" in mm["material"] or "eyeball" in mm["name"])
        if is_eye:
            # the file's own eyeball mesh is a 19-vertex lens patch: the socket
            # opening, flat.  Its centroid and mean normal are the socket frame
            # (that is what the eye material is placed by) -- and then the eye
            # is drawn as the sphere EyeRefract wants, not as a flat lens.
            disc = P[fv:fv + vc]
            c = disc.mean(0)
            n = N[fv:fv + vc].mean(0)
            ln = np.linalg.norm(n)
            n = n / ln if ln > 1e-6 else pl["R"] @ np.array([0.0, -1.0, 0.0], np.float32)
            span = float(max(disc[:, 0].max() - disc[:, 0].min(),
                             disc[:, 2].max() - disc[:, 2].min()))
            eyeball_discs.append(dict(material=mm["material"], centre=c, normal=n,
                                      radius=eye_radius_frac * span))
            continue
        meshes.append(dict(name=mm["name"], material=mm["material"], slot="skin",
                           firstIndex=int(fi), indexCount=int(ic), vertexCount=int(vc)))

    # ---- the eyeballs -------------------------------------------------------
    sphere = _eye_sphere_unit()
    sp, sn, su, st, sb, si = sphere
    eye_mesh = dict(verts=np.concatenate([sp, sn, su, st, sb], 1).astype(np.float32).ravel().tolist(),
                    idx=si.astype(np.uint16).ravel().tolist())
    eyes = []
    for d in eyeball_discs:
        R = float(d["radius"])
        centre = d["centre"] - d["normal"] * (R - eye_bulge)
        rot = _rot_from_to([0.0, 0.0, -1.0], d["normal"])           # pole -> socket normal
        mat = np.eye(4, dtype=np.float32)
        mat[:3, :3] = (rot * R).astype(np.float32)
        mat[:3, 3] = centre
        mat = mat.T                       # glUniformMatrix4fv wants column-major
        eyes.append(dict(material=d["material"], centre=[float(x) for x in centre],
                         forward=[float(x) for x in d["normal"]],
                         radius=R, matrix=mat.ravel().tolist()))
    if verbose:
        print(f"[vbmod] {name}: {len(meshes)} skin mesh(es) {len(P)} verts "
              f"{len(idx)//3} tris; {len(eyes)} eyeball sphere(s) r={eyes[0]['radius']:.2f} "
              f"-> scale {pl['scale']:.4f}, eye level y={pl['eye_world'][1]:.3f}")

    # ---- sparse flex targets, exactly the records the trailer stores -------
    targets = []
    for i, t in enumerate(m["targets"]):
        first, count = t["first_delta"], t["delta_count"]
        rec = m["deltas"][first:first + count]
        v = np.array([r[1] for r in rec], np.uint16)
        dp = np.array([r[2] for r in rec], np.float32) @ pl["R"].T * pl["scale"]
        dn = np.array([r[3] for r in rec], np.float32) @ pl["R"].T
        targets.append(dict(name=t["name"], pair=t["pair"] or "",
                            descriptor=t["descriptor"], count=int(count),
                            meshIndex=int(rec[0][0]) if count else -1,
                            peak=float(np.abs(np.concatenate([dp, dn], 1)).max()) if count else 0.0,
                            idx16=b64(_u16(v)) if count else "",
                            delta16=b64(_f16(np.concatenate([dp, dn], 1))) if count else ""))
    targets.sort(key=lambda t: (t["pair"] == "", -t["peak"]))

    return dict(
        name=name,
        note=("VBMOD4 + VBFLX1 exactly as shipped in the FacePoser package: skeleton, meshes, "
              "UVs, VBFLX1 base normals and 45 sparse face targets.  The vertex program is the "
              "model-format adapter (joints unused, tangents built from the UVs); the fragment "
              "program is the ported material, unchanged -- and the eyeballs are a second "
              "program, drawn the way models/alyx/alyx_eyes.mdl is a separate model."),
        source=dict(path=str(m["path"]), bytes=int(m["bytes"]),
                    tris=int(len(idx) // 3), verts=int(len(P)), scale=float(pl["scale"]),
                    frame=dict(eye_sep=float(pl["frame"]["eye_sep"]),
                               crown_t=float(pl["frame"]["crown_t"]),
                               chin_t=float(pl["frame"]["chin_t"]))),
        mesh=dict(verts=np.ascontiguousarray(_f16(verts)).tobytes().hex(),
                  idx16=b64(_u16(idx)) if use16 else "",
                  idx32="" if use16 else b64(idx),
                  index16=use16,
                  nverts=int(len(P)), nindices=int(len(idx)),
                  nvertsTotal=int(len(P)),
                  layout="pos3 nrm3 uv2 tan3 sign1, HALF_FLOAT, 12 per vertex"),
        meshes=meshes,
        eyes=eyes,
        eyeMesh=eye_mesh,
        targets=targets,
        targetNames=[t["name"] for t in m["targets"]],
        maps=data_uris(bake_result, res_w=map_res_w),
        uvRect=[float(x) for x in uv_rect],
        origin=[float(x) for x in origin],
        eyeCentre=[float(x) for x in pl["eye_world"]],
        materials=materials,
        vmt=vmt_text,
    )
