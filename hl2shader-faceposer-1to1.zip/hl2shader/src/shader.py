"""
shader.py -- the OpenGL port of Source's model-lighting pixel shader.

Everything here is a transliteration of, in order:

  common_vertexlitgeneric_dx9.h : DiffuseTerm(), SpecularAndRimTerms(),
                                  Fresnel(), Fresnel4(), AmbientLight()
  skin_ps20b.fxc                : the skin path that $phong actually selects
  skin_dx9_helper.cpp           : the constant-register packing

Design notes
------------
* The combos are emitted as GLSL #defines with the same names as the STATIC
  combos in the .fxc files (LIGHTWARPTEXTURE, RIMLIGHT, HALFLAMBERT, ...), so
  you can diff the Python against the HLSL line by line.
* The packed registers keep Valve's names: g_EyePos_SpecExponent (xyz = eye,
  w = $phongexponent or -1), g_FresnelRanges_SpecBoost (xyz = re-encoded fresnel
  ranges, w = $phongboost), g_SpecularRimParams, g_ShaderControls, and so on.
* A CPU implementation of the identical math lives at the bottom, so the GPU
  result can be validated numerically and individual pixels can be traced.
"""
from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# GLSL
# ---------------------------------------------------------------------------
VERT_SRC = r"""
#version 330 core
layout(location = 0) in vec3 a_pos;
layout(location = 1) in vec3 a_normal;
layout(location = 2) in vec2 a_uv;
layout(location = 3) in vec3 a_tangent;
layout(location = 4) in vec3 a_bitangent;
// ---------------------------------------------------------------------------
// The face-flex delta stream.
//
// In common_vs_fxc.h the morph delta is *not* read as an attribute on the
// VS_3_0 path -- SampleMorphDelta() tex2Dlod()s it out of a vertex texture --
// but both paths converge on the same one line:
//
//     float3 vPosDelta = vPosFlex.xyz * cFlexScale.x;
//     vPosition.xyz += vPosDelta;
//
// `cFlexScale.x` is documented in that header as "a binary value used to
// switch on/off the addition of the flex delta stream", i.e. it is the
// per-draw on/off switch for THIS vertex program, not a per-flex weight.
// The per-flex weights live in the terrain's flex controller system
// (cFlexWeights[512] on the VS_3_0 path) and are what the .vta deltas are
// already multiplied by before they reach the GPU.  So: one extra vertex
// stream, one scale register, and the geometry deformation is done -- inside
// the same program that also transforms and lights the vertex.
//
// A disabled attribute array reads as (0,0,0,1), so a draw without a flex
// stream (the offline renders) is byte-identical to one with $cFlexScale = 0.
layout(location = 5) in vec3 a_flex;

uniform mat4 u_model;
uniform mat4 u_view;
uniform mat4 u_proj;
uniform mat3 u_normalMat;
uniform float u_cFlexScale;                 // #define cFlexScale.x -> here

out vec3 v_worldPos;
out vec3 v_worldNormal;
out vec2 v_uv;
out mat3 v_tangentSpaceTranspose;   // same name as the HLSL: rows = T,B,N -> world

void main()
{
    // ApplyMorph(): the flex delta is added in *model* space, before the
    // model matrix -- the same place the HLSL does it.
    vec3 pos = a_pos + a_flex * u_cFlexScale;
    vec4 wp = u_model * vec4(pos, 1.0);
    v_worldPos = wp.xyz;
    v_worldNormal = normalize(u_normalMat * a_normal);
    v_uv = a_uv;

    vec3 T = normalize(u_normalMat * a_tangent);
    vec3 B = normalize(u_normalMat * a_bitangent);
    vec3 N = normalize(u_normalMat * a_normal);
    // HLSL: worldSpaceNormal = normalize( mul( i.tangentSpaceTranspose, tangentSpaceNormal ) )
    v_tangentSpaceTranspose = mat3(T, B, N);

    gl_Position = u_proj * u_view * wp;
}
"""

FRAG_SRC = r"""
#version 330 core

// ---- combos, named exactly as the .fxc STATIC combos --------------------
#define SKIN                    __SKIN__
#define HALFLAMBERT             __HALFLAMBERT__
#define LIGHTWARPTEXTURE        __LIGHTWARPTEXTURE__
#define PHONGWARPTEXTURE        __PHONGWARPTEXTURE__
#define PHONG_USE_EXPONENT_FACTOR __PHONG_USE_EXPONENT_FACTOR__
#define RIMLIGHT                __RIMLIGHT__
#define BASEMAPALPHAPHONGMASK   __BASEMAPALPHAPHONGMASK__
#define INVERTPHONGMASK         __INVERTPHONGMASK__
#define CUBEMAP                 __CUBEMAP__
#define ENV_MAP_SCALE           1.0    // common_ps_fxc.h: #define ENV_MAP_SCALE (cLightScale.z)
#define NORMALMAPALPHAENVMAPMASK __NORMALMAPALPHAENVMAPMASK__
#define SELFILLUM               __SELFILLUM__
#define NUM_LIGHTS              __NUM_LIGHTS__
#define AMBIENT_LIGHT           1

in vec3 v_worldPos;
in vec3 v_worldNormal;
in vec2 v_uv;
in mat3 v_tangentSpaceTranspose;

out vec4 fragColor;

// ---- textures ----------------------------------------------------------
uniform sampler2D u_baseTex;
uniform sampler2D u_normalTex;
uniform sampler2D u_exponentTex;
uniform sampler2D u_lightwarpTex;     // sampled with texture(); it is a 256x1 strip
uniform samplerCube u_envCube;        // $envmap env_cubemap (proc-baked here)
uniform vec4 g_EnvMapFresnel_SelfIllumMask;   // x $envmapfresnel

// ---- camera + packed registers (Valve's names kept deliberately) -------
uniform vec4 g_EyePos_SpecExponent;        // xyz eye,    w $phongexponent (-1 = use map)
uniform vec4 g_FresnelRanges_SpecBoost;    // xyz ranges, w $phongboost
uniform vec4 g_SpecularRimParams;          // xyz $phongtint, w $rimlightpower
uniform vec4 g_FlashlightPos_RimBoost;     // xyz flashlight pos, w $rimlightboost
uniform vec4 g_FlashlightAttenuation_RimMask;  // x $rimmask
uniform vec4 g_ShaderControls;             // x basemapAlphaPhongMask, w invertPhongMask
uniform vec4 g_DiffuseModulation;
uniform vec4 g_EnvmapTint_ShadowTweaks;
uniform vec3 u_ambientCube[6];
#if defined(PORT_PROBE_AMBIENT)
uniform sampler3D u_lightgrid;   // the baked probe field (see grid_to_texture())
uniform vec3 u_gridLo;           // world position of probe (0,0,0)
uniform vec3 u_gridCell;         // world size of one probe cell
uniform vec3 u_gridDims;         // nx, ny, nz
#endif
uniform vec4 g_LightPos[4];
uniform vec4 g_LightColor[4];

#define g_FresnelRanges   (g_FresnelRanges_SpecBoost.xyz)
#define g_SpecularBoost   (g_FresnelRanges_SpecBoost.w)
#define g_fInvertPhongMask (g_ShaderControls.w)   // PSREG_CONSTANT_27.w
#define g_SpecularTint    (g_SpecularRimParams.xyz)
#define g_RimExponent     (g_SpecularRimParams.w)
#define g_fRimBoost       (g_FlashlightPos_RimBoost.w)
#define g_RimMaskControl  (g_FlashlightAttenuation_RimMask.x)
#define g_fBaseMapAlphaPhongMask (g_ShaderControls.x)

float saturate(float x) { return clamp(x, 0.0, 1.0); }
vec3  saturate(vec3 x)  { return clamp(x, 0.0, 1.0); }

// ---- common_vertexlitgeneric_dx9.h ------------------------------------
// Traditional fresnel term approximation
float Fresnel(vec3 vNormal, vec3 vEyeDir) {
    float fresnel = saturate(1.0 - dot(vNormal, vEyeDir));
    return fresnel * fresnel;
}
// 4th power version (used by the rim term)
float Fresnel4(vec3 vNormal, vec3 vEyeDir) {
    float fresnel = saturate(1.0 - dot(vNormal, vEyeDir));
    fresnel = fresnel * fresnel;
    return fresnel * fresnel;
}
// Custom Fresnel: vRanges already re-encoded to ((mid-min)*2, mid, (max-mid)*2)
float Fresnel(vec3 vNormal, vec3 vEyeDir, vec3 vRanges) {
    float f = saturate(1.0 - dot(vNormal, vEyeDir));
    f = f * f - 0.5;
    return vRanges.y + (f >= 0.0 ? vRanges.z : vRanges.x) * f;
}

// float3 AmbientLight( const float3 worldNormal )  -- SIGGRAPH 2006, verbatim shape
#if defined(PORT_PROBE_AMBIENT)
// One lobe of the probe field at a world position, with the z axis interpolated
// by hand.
//
// The grid ships as a 3D texture of (nx, ny, nz*6) whose z axis walks
// probe -> lobe -> probe -> lobe:  slice z = probe_z*6 + cube_index.  Hardware
// trilinear filtering would therefore blend *lobes* together wherever the probe
// coordinate is fractional on z -- sampling at (g.z*6 + lobe) mixes this lobe
// with the next one.  So the sampler is pinned to two exact texel rows and the
// two probes are mixed here instead; x and y still filter in hardware, where
// the neighbours really are neighbours.
vec3 probeLobe(vec3 p, float lobe){
    vec3 g = (p - u_gridLo) / u_gridCell;
    float zc = clamp(g.z, 0.0, u_gridDims.z - 1.0);
    float z0 = floor(zc);
    float z1 = min(z0 + 1.0, u_gridDims.z - 1.0);
    float fz = zc - z0;
    vec2 uv = (g.xy + 0.5) / u_gridDims.xy;
    float sz = u_gridDims.z * 6.0;
    vec3 a = texture(u_lightgrid, vec3(uv, (z0*6.0 + lobe + 0.5) / sz)).rgb;
    vec3 b = texture(u_lightgrid, vec3(uv, (z1*6.0 + lobe + 0.5) / sz)).rgb;
    return mix(a, b, fz);
}
#endif

vec3 AmbientLight(vec3 worldNormal) {
    vec3 nSquared = worldNormal * worldNormal;
    // PixelShaderAmbientLight(): isPositive.x * cube[0] + isNegative.x * cube[1] + ...
    // so index = 2*axis + (component < 0)
#if defined(PORT_PROBE_AMBIENT)
    // PORT EXTENSION -- not a Valve combo.
    //
    // Valve resolves the ambient cube *per entity* (LightcacheGetStatic() ->
    // cAmbientCube) and re-uses one cube for every vertex of the model.  This
    // branch is what happens if the same probe field is sampled per *fragment*
    // instead: the cube is re-picked from a 3D texture at the fragment's own
    // world position, trilinearly interpolated between the eight surrounding
    // probes.  Same AmbientLight() algebra, same six lobes -- one lookup table
    // per object versus one per pixel.
    //
    // The texture is lightcache.grid_to_texture()'s packing: slice
    // z = probe_z*6 + cube_index.  Because the lobes share the z axis with the
    // probes, the fetch can't just be left to the sampler -- see probeLobe()
    // above, which pins z to two probes and does that mix by hand.
    // cAmbientCube is stored [+x -x +y -y +z -z], so index = 2*axis + (n<0):
    // a *negative* component selects the odd slice.  (Getting this backwards
    // lights every surface from the lobe behind it -- it looks plausible on a
    // convex blob and very wrong on a room.)
    vec3 c0 = probeLobe(v_worldPos, worldNormal.x < 0.0 ? 1.0 : 0.0);
    vec3 c1 = probeLobe(v_worldPos, worldNormal.y < 0.0 ? 3.0 : 2.0);
    vec3 c2 = probeLobe(v_worldPos, worldNormal.z < 0.0 ? 5.0 : 4.0);
    return nSquared.x*c0 + nSquared.y*c1 + nSquared.z*c2;
#else
    return nSquared.x * u_ambientCube[worldNormal.x < 0.0 ? 1 : 0]
         + nSquared.y * u_ambientCube[worldNormal.y < 0.0 ? 3 : 2]
         + nSquared.z * u_ambientCube[worldNormal.z < 0.0 ? 5 : 4];
#endif
}

// DiffuseTerm(): half-lambert + optional 1D lightwarp lookup
vec3 DiffuseTerm(vec3 worldNormal, vec3 lightDir) {
    float NDotL = dot(worldNormal, lightDir);          // UNSATURATED
#if HALFLAMBERT
    float fResult = saturate(NDotL * 0.5 + 0.5);
  #if !LIGHTWARPTEXTURE
    fResult *= fResult;
  #endif
#else
    float fResult = saturate(NDotL);
#endif
#if LIGHTWARPTEXTURE
    return 2.0 * texture(u_lightwarpTex, vec2(fResult, 0.5)).rgb;   // lightwarps are authored at half brightness
#else
    return vec3(fResult);
#endif
}

// SpecularAndRimTerms()
void SpecularAndRimTerms(vec3 vWorldNormal, vec3 vLightDir, float fSpecularExponent,
                         vec3 vEyeDir, float fFresnel, vec3 color,
                         out vec3 specularLighting, out vec3 rimLighting)
{
    rimLighting = vec3(0.0);
    vec3 vReflect = 2.0 * vWorldNormal * dot(vWorldNormal, vEyeDir) - vEyeDir;
    float LdotR = saturate(dot(vReflect, vLightDir));
    specularLighting = vec3(pow(LdotR, fSpecularExponent));
    specularLighting *= saturate(dot(vWorldNormal, vLightDir));
    specularLighting *= color;
#if RIMLIGHT
    rimLighting  = vec3(pow(LdotR, g_RimExponent));
    rimLighting *= saturate(dot(vWorldNormal, vLightDir));
    rimLighting *= color;
#endif
}

#define LIGHT_ATTEN_DIST 1.0

void main()
{
    vec4 baseColor = texture(u_baseTex, v_uv) * g_DiffuseModulation;
    vec4 normalTexel = texture(u_normalTex, v_uv);

    // skin_ps20b.fxc:199-200
    vec3 tangentSpaceNormal = 2.0 * normalTexel.xyz - 1.0;
    float fSpecMask = normalTexel.a;
    // note: the default is the BUMPMAP's alpha; $basemapalphaphongmask switches source
    tangentSpaceNormal = mix(tangentSpaceNormal, vec3(0.0, 0.0, 1.0), g_fBaseMapAlphaPhongMask);
    fSpecMask = mix(normalTexel.a, baseColor.a, g_fBaseMapAlphaPhongMask);

    vec3 worldSpaceNormal = normalize(v_tangentSpaceTranspose * tangentSpaceNormal);
    vec3 vEyeDir = normalize(g_EyePos_SpecExponent.xyz - v_worldPos);

    float fFresnelRanges = Fresnel(worldSpaceNormal, vEyeDir, g_FresnelRanges);
    float fRimFresnel = Fresnel4(worldSpaceNormal, vEyeDir);

    // ---------------- diffuse: Light Source Parameters 1..N -------------
    vec3 diffuseLighting = vec3(0.0);
    for (int i = 0; i < NUM_LIGHTS; ++i)
    {
        vec3 lightDir = normalize(g_LightPos[i].xyz - v_worldPos);
        float atten = 1.0 / (1.0 + 0.06 * dot(g_LightPos[i].xyz - v_worldPos, g_LightPos[i].xyz - v_worldPos));
        diffuseLighting += g_LightColor[i].rgb * atten * DiffuseTerm(worldSpaceNormal, lightDir);
    }
    diffuseLighting += AmbientLight(worldSpaceNormal);      // the "Ambient Cube" box

    // ---------------- phong: only exists in skin_ps20b.fxc ----------------
    // NOTE: in the engine this is not a combo -- the routing in DrawSkin_DX9()
    // vs DrawVertexLitGeneric_DX9_Internal() decides which *file* runs, and
    // vertexlit_and_unlit_generic_bump_ps2x.fxc has no specular code at all.
    // The port keeps the same structure in one program by gating on SKIN.
    vec3 specularLighting = vec3(0.0);
    vec3 vSpecularTint = vec3(1.0);
#if SKIN
    vec4 vSpecExpMap = texture(u_exponentTex, v_uv);
#if PHONG_USE_EXPONENT_FACTOR
    float fSpecExp = 1.0 + g_EyePos_SpecExponent.w * vSpecExpMap.r;
#else
    float fSpecExp = (g_EyePos_SpecExponent.w >= 0.0)
                   ? g_EyePos_SpecExponent.w
                   : (1.0 + 149.0 * vSpecExpMap.r);
#endif
    vSpecularTint = mix(vec3(1.0), baseColor.rgb, vSpecExpMap.g);
    vSpecularTint = (g_SpecularTint.r >= 0.0) ? g_SpecularTint : vSpecularTint;

    // ---------------- specular over all local lights ----------------
    vec3 rimLighting = vec3(0.0);
    for (int i = 0; i < NUM_LIGHTS; ++i)
    {
        vec3 lightDir = normalize(g_LightPos[i].xyz - v_worldPos);
        float atten = 1.0 / (1.0 + 0.06 * dot(g_LightPos[i].xyz - v_worldPos, g_LightPos[i].xyz - v_worldPos));
        vec3 s, r;
        SpecularAndRimTerms(worldSpaceNormal, lightDir, fSpecExp, vEyeDir,
                            fFresnelRanges, g_LightColor[i].rgb * atten, s, r);
        specularLighting += s;
        rimLighting += r;
    }

    // If we didn't already apply Fresnel to specular warp, modulate the specular
    fSpecMask *= fFresnelRanges;
    // Modulate with spec mask, boost and tint
    specularLighting *= fSpecMask * g_SpecularBoost;

#if RIMLIGHT
    float fRimMask = mix(1.0, vSpecExpMap.a, g_RimMaskControl);
    float fRimMultiply = fRimMask * fRimFresnel;
    rimLighting *= fRimMultiply;
    specularLighting = max(specularLighting, rimLighting);
    vec3 vRimAmbientCubeColor = AmbientLight(vEyeDir);
    specularLighting += (vRimAmbientCubeColor * g_fRimBoost) * saturate(fRimMultiply * worldSpaceNormal.z);
#endif

#endif // SKIN  (end of the skin_ps20b.fxc-only code)

    vec3 albedo = baseColor.rgb;
    vec3 diffuseComponent = diffuseLighting * albedo;

    // ---------------- envmap: skin_ps20b.fxc:229-240 ----------------
    // HL2 2004's whole "shininess" story lives in this block: a masked cubemap
    // reflection, with no light-tracking specular anywhere.
    //   float fEnvMapMask = lerp( baseColor.a, fSpecMask, g_EnvmapTint_ShadowTweaks.w );
    //   envMapColor = (ENV_MAP_SCALE * lerp(1, fFresnelRanges, g_EnvMapFresnel.x)
    //                  * lerp(fEnvMapMask, 1-fEnvMapMask, g_fInvertPhongMask))
    //                 * texCUBE( EnvmapSampler, vReflect ) * g_EnvmapTint_ShadowTweaks.xyz;
    vec3 envMapColor = vec3(0.0);
#if CUBEMAP
    vec3 vReflect = 2.0 * worldSpaceNormal * dot(worldSpaceNormal, vEyeDir) - vEyeDir;
    float fEnvMapMask = mix(baseColor.a, fSpecMask, g_EnvmapTint_ShadowTweaks.w);
    envMapColor = (ENV_MAP_SCALE
                   * mix(1.0, fFresnelRanges, g_EnvMapFresnel_SelfIllumMask.x)
                   * mix(fEnvMapMask, 1.0 - fEnvMapMask, g_fInvertPhongMask))
                  * texture(u_envCube, vReflect).rgb
                  * g_EnvmapTint_ShadowTweaks.xyz;
#endif

    // FINAL LIGHTING
    vec3 result = specularLighting * vSpecularTint + envMapColor + diffuseComponent;
    fragColor = vec4(result, 1.0);
}
"""


def build_fragment_source(combos) -> str:
    src = FRAG_SRC
    d = combos.defines()
    for k, v in d.items():
        src = src.replace(f"__{k}__", v)
    missing = [ln for ln in src.splitlines() if "__" in ln and ln.strip().startswith("#define") is False]
    if missing:
        raise RuntimeError(f"unsubstituted defines: {missing[:3]}")
    return src


# ---------------------------------------------------------------------------
# CPU implementation of the same math (validation + tracing)
# ---------------------------------------------------------------------------
def sample2d(tex: np.ndarray, uv: np.ndarray) -> np.ndarray:
    """Bilinear sample with wrap.  tex (h,w,c) float, uv (...,2).  v=0 at the top
    row, exactly as in the texture file."""
    h, w = tex.shape[:2]
    x = uv[..., 0] * w - 0.5
    y = uv[..., 1] * h - 0.5
    x0 = np.floor(x).astype(np.int64); y0 = np.floor(y).astype(np.int64)
    fx = (x - x0)[..., None]; fy = (y - y0)[..., None]
    x0 %= w; y0 %= h
    x1 = (x0 + 1) % w; y1 = (y0 + 1) % h
    c00 = tex[y0, x0]; c10 = tex[y0, x1]; c01 = tex[y1, x0]; c11 = tex[y1, x1]
    top = c00 * (1 - fx) + c10 * fx
    bot = c01 * (1 - fx) + c11 * fx
    return top * (1 - fy) + bot * fy


def sample_cube(cube_faces: np.ndarray, d: np.ndarray) -> np.ndarray:
    """Nearest-texel cubemap sample.  cube_faces is (6, S, S, 3) in GL face order
    (+X -X +Y -Y +Z -Z); d is (..., 3), not required to be normalised."""
    d = np.asarray(d, np.float32)
    d = d / np.maximum(np.linalg.norm(d, axis=-1, keepdims=True), 1e-9)
    ax = np.argmax(np.abs(d), axis=-1)
    sign = np.take_along_axis(d, ax[..., None], -1)[..., 0] < 0
    face = ax * 2 + sign.astype(np.int64)                # +X -X +Y -Y +Z -Z
    u = np.zeros(d.shape[:-1], np.float32)
    v = np.zeros_like(u)
    x, y, z = d[..., 0], d[..., 1], d[..., 2]
    sel = (ax == 0)
    u[sel], v[sel] = -z[sel] * np.sign(x[sel]), -y[sel] * np.sign(x[sel])
    sel = (ax == 1)
    u[sel], v[sel] = x[sel] * np.sign(y[sel]), z[sel] * np.sign(y[sel])
    sel = (ax == 2)
    u[sel], v[sel] = x[sel] * np.sign(z[sel]), -y[sel] * np.sign(z[sel])
    # map [-1,1] to texel indices of the face the shader picked
    S = cube_faces.shape[1]
    iu = np.clip(((u * 0.5 + 0.5) * (S - 1)).round().astype(np.int64), 0, S - 1)
    iv = np.clip(((v * 0.5 + 0.5) * (S - 1)).round().astype(np.int64), 0, S - 1)
    return cube_faces[face, iv, iu]


class CPUShader:
    """Mirrors FRAG_SRC above, on numpy arrays.  One instance == one compiled
    program (combo set)."""

    def __init__(self, combos, uniforms: dict, textures: dict, num_lights: int,
                 ambient_cube=None, env_faces=None):
        self.c = combos
        self.u = uniforms
        self.t = textures
        self.n = num_lights
        # keep the register names identical to the GLSL, aliases like the #defines
        self.cube = np.asarray(ambient_cube, np.float32)
        # the six baked envmap faces, in GL's (+X -X +Y -Y +Z -Z) order
        self.env_faces = (np.asarray(env_faces, np.float32)
                          if env_faces is not None else None)
        self.base_map_alpha_phong_mask = float(uniforms["ShaderControls"][0])
        self.rim_mask_control = float(uniforms["FlashlightAttenuation_RimMask"][0])
        self.rim_boost = float(uniforms["FlashlightPos_RimBoost"][3])

    # ---- helpers ---------------------------------------------------------
    @staticmethod
    def sat(x):
        return np.clip(x, 0.0, 1.0)

    @staticmethod
    def fresnel(N, V):
        f = CPUShader.sat(1.0 - np.sum(N * V, -1))
        return f * f

    @staticmethod
    def fresnel4(N, V):
        f = CPUShader.sat(1.0 - np.sum(N * V, -1))
        return (f * f) ** 2

    @staticmethod
    def fresnel_ranges(N, V, ranges):
        f = CPUShader.sat(1.0 - np.sum(N * V, -1))
        f = f * f - 0.5
        return ranges[1] + np.where(f >= 0.0, ranges[2], ranges[0]) * f

    def ambient_light(self, N, cube):
        """AmbientLight(): sum n_i^2 * cube_i, index = 2*axis + (n_i < 0)
        i.e. cAmbientCube is stored [+x -x +y -y +z -z]."""
        n2 = N * N
        negx = (N[..., 0:1] < 0.0).astype(np.float32)
        negy = (N[..., 1:2] < 0.0).astype(np.float32)
        negz = (N[..., 2:3] < 0.0).astype(np.float32)
        return (n2[..., 0:1] * (cube[1][None, :] * negx + cube[0][None, :] * (1 - negx))
                + n2[..., 1:2] * (cube[3][None, :] * negy + cube[2][None, :] * (1 - negy))
                + n2[..., 2:3] * (cube[5][None, :] * negz + cube[4][None, :] * (1 - negz)))

    def diffuse_term(self, N, L):
        NDotL = np.sum(N * L, -1)
        if self.c.HALFLAMBERT:
            f = self.sat(NDotL * 0.5 + 0.5)
            if not self.c.LIGHTWARPTEXTURE:
                f = f * f
        else:
            f = self.sat(NDotL)
        if self.c.LIGHTWARPTEXTURE:
            warp = self.t["lightwarp"]
            n = warp.shape[1]
            x = np.clip(f, 0, 1) * (n - 1)
            i0 = np.floor(x).astype(np.int64); i1 = np.minimum(i0 + 1, n - 1)
            fx = (x - i0)[..., None]
            col = warp[0, i0] * (1 - fx) + warp[0, i1] * fx
            return 2.0 * col
        return np.repeat(f[..., None], 3, -1)

    def specular_and_rim(self, N, L, spec_exp, V, fresnel, color):
        R = 2.0 * N * np.sum(N * V, -1)[..., None] - V
        LdotR = self.sat(np.sum(R * L, -1))
        spec = (np.maximum(LdotR, 0.0) ** spec_exp)[..., None] * self.sat(np.sum(N * L, -1))[..., None] * color
        rim = np.zeros_like(spec)
        if self.c.RIMLIGHT:
            rim = ((np.maximum(LdotR, 0.0) ** float(self.u["SpecularRimParams"][3]))[..., None]
                   * self.sat(np.sum(N * L, -1))[..., None] * color)
        return spec, rim

    # ---- the shader ------------------------------------------------------
    def shade(self, gbuf: dict, lights: list[tuple[np.ndarray, np.ndarray]], *,
              trace=None):
        """gbuf: worldPos (H,W,3), normal (H,W,3), T (H,W,3), B (H,W,3), uv (H,W,2).
        lights: [(pos, color)]"""
        u = self.u
        base = sample2d(self.t["base"], gbuf["uv"])
        base[..., :3] *= np.asarray(u["DiffuseModulation"], np.float32)[:3]
        nrm_tex = sample2d(self.t["normal"], gbuf["uv"])
        exp_tex = sample2d(self.t["exponent"], gbuf["uv"])

        tsn = 2.0 * nrm_tex[..., :3] - 1.0
        spec_mask_raw = nrm_tex[..., 3].copy()      # the bumpmap's alpha == PHONG MASK
        spec_mask = spec_mask_raw.copy()

        bmap = self.base_map_alpha_phong_mask
        tsn = tsn * (1 - bmap) + np.array([0.0, 0.0, 1.0]) * bmap
        spec_mask = spec_mask * (1 - bmap) + base[..., 3] * bmap

        # mul(tangentSpaceTranspose, tsn) == T*tsn.x + B*tsn.y + N*tsn.z
        world_n = (gbuf["T"] * tsn[..., 0:1] + gbuf["B"] * tsn[..., 1:2]
                   + gbuf["normal"] * tsn[..., 2:3])
        world_n /= np.maximum(np.linalg.norm(world_n, axis=-1, keepdims=True), 1e-9)

        eye = np.asarray(u["EyePos_SpecExponent"][:3], np.float32)
        V = eye[None, None, :] - gbuf["worldPos"]
        V /= np.maximum(np.linalg.norm(V, axis=-1, keepdims=True), 1e-9)

        ranges = np.asarray(u["FresnelRanges_SpecBoost"], np.float32)
        boost = float(ranges[3])
        f_fresnel = self.fresnel_ranges(world_n, V, ranges[:3])
        f_rim_fresnel = self.fresnel4(world_n, V)

        cube = self.cube

        # Everything below lives in skin_ps20b.fxc only.  Without $phong the
        # material is routed to vertexlit_and_unlit_generic_bump_ps2x.fxc,
        # which has no specular term whatsoever -- so the gate is on routing
        # (SKIN), not on a combo.
        diffuse = np.zeros_like(base[..., :3])   # accumulates over the lights
        if not self.c.SKIN:
            diffuse += self.ambient_light(world_n, cube)
            for pos, col in lights:
                d = pos[None, None, :] - gbuf["worldPos"]
                L = d / np.maximum(np.linalg.norm(d, axis=-1, keepdims=True), 1e-9)
                atten = 1.0 / (1.0 + 0.06 * np.sum(d * d, -1))
                diffuse += col[None, None, :] * atten[..., None] * self.diffuse_term(world_n, L)
            return diffuse * base[..., :3]

        # ---- exponent, computed before the specular loop exactly as the GLSL
        #      computes it before PixelShaderDoSpecularLighting() ----
        w = float(u["EyePos_SpecExponent"][3])
        if self.c.PHONG_USE_EXPONENT_FACTOR:
            spec_exp = 1.0 + w * exp_tex[..., 0]
        else:
            spec_exp = w if w >= 0.0 else (1.0 + 149.0 * exp_tex[..., 0])

        specular = np.zeros_like(diffuse)
        rim = np.zeros_like(diffuse)
        light_dbg = []
        for pos, col in lights:
            d = pos[None, None, :] - gbuf["worldPos"]
            L = d / np.maximum(np.linalg.norm(d, axis=-1, keepdims=True), 1e-9)
            atten = 1.0 / (1.0 + 0.06 * np.sum(d * d, -1))
            diffuse += col[None, None, :] * atten[..., None] * self.diffuse_term(world_n, L)
            s, r = self.specular_and_rim(world_n, L, spec_exp, V, f_fresnel,
                                         col[None, None, :] * atten[..., None])
            specular += s
            rim += r
            light_dbg.append((L, atten))

        diffuse += self.ambient_light(world_n, cube)

        tint_const = np.asarray(u["SpecularRimParams"][:3], np.float32)
        spec_tint = np.where(tint_const[0] >= 0.0, tint_const[None, None, :],
                             base[..., :3])   # albedo tint via exponent green, simplified

        spec_mask = spec_mask * f_fresnel
        specular *= spec_mask[..., None] * boost

        # ---------------- envmap: skin_ps20b.fxc:229-240 ----------------
        #   fEnvMapMask = lerp( baseColor.a, fSpecMask, g_EnvmapTint_ShadowTweaks.w )
        #   envMapColor = (ENV_MAP_SCALE * lerp(1, fFresnelRanges, g_EnvMapFresnel.x)
        #                  * lerp(fEnvMapMask, 1-fEnvMapMask, g_fInvertPhongMask))
        #                 * texCUBE( EnvmapSampler, vReflect ) * g_EnvmapTint_ShadowTweaks.xyz
        env_map_color = np.zeros_like(base[..., :3])
        if self.c.CUBEMAP:
            refl = 2.0 * world_n * np.sum(world_n * V, -1)[..., None] - V
            refl /= np.maximum(np.linalg.norm(refl, axis=-1, keepdims=True), 1e-9)
            mask_ctrl = float(u["EnvmapTint_ShadowTweaks"][3])
            env_mask = spec_mask_raw * mask_ctrl + base[..., 3] * (1.0 - mask_ctrl)
            env_fres = 1.0 * (1 - u["EnvMapFresnel_SelfIllumMask"][0]) + f_fresnel * u["EnvMapFresnel_SelfIllumMask"][0]
            inv = float(u["ShaderControls"][3])
            w = env_mask * (1 - inv) + (1 - env_mask) * inv
            cube_texel = (sample_cube(self.env_faces, refl) if self.env_faces is not None
                          else np.zeros_like(refl))
            env_map_color = (env_fres * w)[..., None] * cube_texel \
                * np.asarray(u["EnvmapTint_ShadowTweaks"][:3], np.float32)[None, None, :]

        if self.c.RIMLIGHT:
            f_rim_mask = 1.0 * (1 - self.rim_mask_control) + exp_tex[..., 3] * self.rim_mask_control
            f_rim_mult = f_rim_mask * f_rim_fresnel
            rim = rim * f_rim_mult[..., None]
            specular = np.maximum(specular, rim)
            rim_cube = self.ambient_light(V, cube)
            specular = specular + (rim_cube * self.rim_boost) * \
                self.sat(f_rim_mult * world_n[..., 2])[..., None]

        albedo = base[..., :3]
        diffuse_component = diffuse * albedo
        result = specular * spec_tint + env_map_color + diffuse_component

        if trace is not None:
            trace.update(dict(base=base, tsn=tsn, spec_mask_raw=nrm_tex[..., 3],
                              world_n=world_n, V=V, f_fresnel=f_fresnel,
                              f_rim_fresnel=f_rim_fresnel, exp_tex=exp_tex,
                              spec_exp=spec_exp, specular=specular, rim=rim,
                              diffuse=diffuse, diffuse_component=diffuse_component,
                              env_map_color=env_map_color,
                              result=result, boost=boost, ranges=ranges))
        return result
