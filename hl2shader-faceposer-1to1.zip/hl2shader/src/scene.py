"""
scene.py -- the test scene: a small room with two lights, mirroring the kind of
setup the shader tree diagram was rendered in (cool room, warm key light).

Anything that both the lightcache baker and the renderer need to agree on lives
here, so the baked probes and the runtime shading can never drift apart.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import numpy as np


@dataclass
class Light:
    pos: np.ndarray
    color: np.ndarray
    name: str = ""


@dataclass
class Box:
    lo: np.ndarray
    hi: np.ndarray
    albedo: np.ndarray = field(default_factory=lambda: np.array([0.5, 0.5, 0.5]))
    name: str = ""


@dataclass
class Scene:
    bounds_lo: np.ndarray
    bounds_hi: np.ndarray
    lights: list
    props: list
    floor_y: float
    wall_z: float
    head_pos: np.ndarray          # where the model sits
    camera_eye: np.ndarray
    camera_target: np.ndarray
    fov_deg: float = 42.0

    # surface albedos used by the world bake
    wall_albedo: float = 0.55
    floor_albedo: float = 0.45


def make_scene() -> Scene:
    return Scene(
        bounds_lo=np.array([-4.0, -1.5, -1.2], np.float32),
        bounds_hi=np.array([4.0, 2.8, 6.0], np.float32),
        lights=[
            # A two-eyed setup, i.e. the "Diffuse 1" / "Diffuse 2" boxes in the
            # shader tree.  Placement matters more than it looks: $phong is a
            # reflection term, so a light behind the head (where the original
            # layout had both of them) produces literally zero specular on the
            # face -- pixel-identical renders for $phong 1 and mat_phong 0.
            # The key sits on the camera side, near the mirror direction
            #     R = 2N(N.V) - V
            # of the eye about the face normal, so the highlight lands where you
            # can see it; the cool fill stays low and to the side for shape.
            Light(pos=np.array([-1.05, 1.55, -2.05], np.float32),
                  color=np.array([1.00, 0.72, 0.45], np.float32) * 3.1, name="key (warm)"),
            Light(pos=np.array([2.35, -0.15, -1.05], np.float32),
                  color=np.array([0.30, 0.52, 0.88], np.float32) * 2.2, name="fill (cool)"),
        ],
        props=[
            Box(lo=np.array([-2.35, -1.5, 0.55], np.float32),
                hi=np.array([-1.45, -0.55, 1.45], np.float32),
                albedo=np.array([0.42, 0.34, 0.26], np.float32), name="crate"),
            Box(lo=np.array([1.85, -1.5, 0.15], np.float32),
                hi=np.array([2.60, 2.8, 0.90], np.float32),
                albedo=np.array([0.46, 0.47, 0.50], np.float32), name="pillar"),
        ],
        floor_y=-1.5,
        wall_z=6.0,
        head_pos=np.array([0.0, 0.10, 0.0], np.float32),
        camera_eye=np.array([0.02, 0.34, -2.30], np.float32),
        camera_target=np.array([0.0, 0.30, 0.0], np.float32),
    )


# ---------------------------------------------------------------------------
# geometry helpers shared by baker + renderer
# ---------------------------------------------------------------------------
def aabb_intersect(origin: np.ndarray, direction: np.ndarray, lo: np.ndarray, hi: np.ndarray):
    """Branchless-ish slab test.  Returns (hit, tmin).  Vectorised over rays."""
    inv = 1.0 / np.where(np.abs(direction) < 1e-9, 1e-9, direction)
    t1 = (lo - origin) * inv
    t2 = (hi - origin) * inv
    tmin = np.maximum.reduce(np.minimum(t1, t2), axis=-1)
    tmax = np.minimum.reduce(np.maximum(t1, t2), axis=-1)
    hit = (tmax >= np.maximum(tmin, 0.0)) & (tmax > 0.0)
    return hit, tmin


def visible(origin: np.ndarray, target: np.ndarray, boxes: list[Box], eps: float = 1e-3):
    """True if nothing blocks the segment origin->target."""
    d = target - origin
    dist = np.linalg.norm(d)
    if dist < eps:
        return True
    d = d / dist
    for b in boxes:
        hit, tmin = aabb_intersect(np.atleast_2d(origin), np.atleast_2d(d), b.lo, b.hi)
        if hit[0] and eps < tmin[0] < dist - eps:
            return False
    return True


def point_light_contribution(pos, normal, light: Light, boxes):
    """Direct lighting of a surface point, Source-style attenuation
    (1 / (1 + 0.06 d^2), the same curve the model shader uses)."""
    d = light.pos - pos
    dist2 = float(np.dot(d, d))
    dist = np.sqrt(dist2)
    if dist < 1e-6:
        return np.zeros(3, np.float32), None
    L = d / dist
    if not visible(pos + normal * 1e-3, light.pos, boxes):
        return np.zeros(3, np.float32), L
    atten = 1.0 / (1.0 + 0.06 * dist2)
    ndotl = max(0.0, float(np.dot(normal, L)))
    return light.color * atten * ndotl, L
