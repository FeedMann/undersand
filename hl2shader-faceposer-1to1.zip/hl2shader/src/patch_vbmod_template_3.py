"""Patch 3: link the VBMOD programs beside the head program, gate the draws on
the model selection, and wire the UI + read-out."""
import io

P = "web_template.html"
s = io.open(P, encoding="utf-8").read()


def sub1(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:60])
    s = s.replace(old, new)


# ---------------------------------------------------------------- linkProg()
sub1("""let progHead=null, progErr="";""",
     """let progHead=null, progErr="", vbmProgErr="";
/* Create+link a program from explicit sources.  Used for the VBMOD4 path, which
   swaps the *vertex* program (the model format) and keeps the fragment program
   (the material) verbatim. */
function linkProg(vs,fs,label){
  const p=gl.createProgram();
  gl.attachShader(p,compile(gl.VERTEX_SHADER,vs,label+" vs"));
  gl.attachShader(p,compile(gl.FRAGMENT_SHADER,fs,label+" fs"));
  gl.linkProgram(p);
  if(!gl.getProgramParameter(p,gl.LINK_STATUS))
    throw new Error(label+" link failed: "+gl.getProgramInfoLog(p));
  return p;
}""")

# ------------------------------------------------- second program, same frag
sub1("""  }catch(e){
    progErr=e.message;
    shaderNote.textContent="";
  }""",
     """  }catch(e){
    progErr=e.message;
    shaderNote.textContent="";
  }
  /* The SAME fragment source on the VBMOD4 vertex program.  This is the entire
     "run the ported shaders on our own format" claim: one line of the pipeline
     changes -- which vertex program feeds the pixel shader -- and nothing else.
     Rebuilt here, beside the head program, so every combo and every term
     isolate works on your model too (and so --check covers both links). */
  if(DATA.vbmod){
    try{
      gpu.vbSkin=linkProg(VBMOD_VS,fragSrc,"vbmod skin");
      gpu.vbEye =linkProg(VBMOD_VS,EYE_FS, "vbmod eye");
      vbmProgErr="";
    }catch(e){ vbmProgErr=e.message; }
    const nb=document.getElementById("vbNote");
    if(nb) nb.textContent = vbmProgErr ? ("link error: "+vbmProgErr)
      : "VBMOD4 vertex program linked with the pixel program above ("+DATA.vbmod.shaderNote+")";
  }""")

# ------------------------------------------------------------------ gate head
sub1("""  // head
  if(progHead){
    const p=progHead;""",
     """  // which model is in the scene: the port's stand-in head, or your .vbmod
  const useVb = !PARITY && state.model.src==="vbmod" && gpu.vb && gpu.vbSkin;
  // head
  if(progHead && !useVb){
    const p=progHead;""")

sub1("""  if(state.model.src==="vbmod" && gpu.vb && gpu.vbSkin){""",
     """  if(useVb){""")

sub1("""  if(!PARITY && state.eye.draw && gpu.eyeProg){
    const E=state.eye, hS=DATA.headScale, hP=DATA.headPos;""",
     """  if(!useVb && !PARITY && state.eye.draw && gpu.eyeProg){
    const E=state.eye, hS=DATA.headScale, hP=DATA.headPos;""")

# ------------------------------------------------------------ UI (a section)
sub1("""    <div class="sec">
      <h2>Face flexes <span class="tag">the other vertex stream</span></h2>""",
     """    <div class="sec">
      <h2>Your model <span class="tag">VBMOD4 + VBFLX1</span></h2>
      <div class="note" style="margin-top:0" id="vbNote">
        loading <code>leanna.vbmod</code>…</div>
      <div class="row"><label>model in the scene</label></div>
      <div class="row">
        <label><input type="radio" name="msrc" id="srcHead"> the port's stand-in head</label>
      </div>
      <div class="row">
        <label><input type="radio" name="msrc" id="srcVb"> leanna.vbmod (your format)</label>
      </div>
      <div class="row"><label for="vbFlexSel">flex target (VBFLX1)</label></div>
      <div class="row"><select id="vbFlexSel" style="width:100%"></select></div>
      <div id="vbFlexParams"></div>
      <div class="ro" id="vbread"></div>
    </div>

    <div class="sec">
      <h2>Face flexes <span class="tag">the other vertex stream</span></h2>""")

# ------------------------------------------------------------- UI wiring
sub1("""  refreshFlexReadout();

  /* ---- eyes: the second material ---------------------------------------- */""",
     """  refreshFlexReadout();

  /* ---- your model: VBMOD4 + VBFLX1 --------------------------------------- */
  if(DATA.vbmod){
    const vss=$("vbFlexSel");
    DATA.vbmod.targets.forEach((t,i)=>{
      const o=document.createElement("option");
      o.value=String(i); o.textContent=t.name+(t.pair?("  \\u2192 "+t.pair+"):"")+", "+t.count+" verts";
      vss.appendChild(o);
    });
    vss.value="0"; state.model.vbSel=0;
    vss.addEventListener("change",()=>{ state.model.vbSel=parseInt(vss.value,10);
      applyVbFlex(); });
    refreshers.push(slider($("vbFlexParams"),"weight  (CPU accumulation, like ApplyFaceFlexTargets)",
      0,1,0.01, ()=>state.model.vbWeight, v=>{ state.model.vbWeight=v; applyVbFlex(); },
      (x)=>x.toFixed(2)));
    refreshers.push(slider($("vbFlexParams"),"mirror the paired target (AU12R \\u2192 AU12L)",0,1,1,
      ()=>state.model.vbMirror?1:0, v=>{ state.model.vbMirror=!!v; applyVbFlex(); },
      (x)=>x.toFixed(0)));
    const setModelSrc=(v)=>{
      state.model.src=v;
      $("srcHead").checked=(v==="head"); $("srcVb").checked=(v==="vbmod");
      const on=(v==="vbmod");
      $("vbFlexSel").disabled=!on;
      applyVbFlex(); refreshVbReadout();
    };
    $("srcHead").addEventListener("change",()=>setModelSrc("head"));
    $("srcVb").addEventListener("change",()=>setModelSrc("vbmod"));
    setModelSrc(PARITY ? "head" : "vbmod");
    refreshVbReadout();
    window.vb={
      data:true, apply:applyVbFlex, modelSrc:setModelSrc,
      target:(n)=>{ const i=(DATA.vbmod.targetIndex||{})[n];
        if(i===undefined) return -1; state.model.vbSel=i;
        $("vbFlexSel").value=String(i); applyVbFlex(); return i; },
      setWeight:(w)=>{ state.model.vbWeight=w; applyVbFlex(); },
      readout:()=>$("vbread").textContent
    };
  } else {
    $("srcVb").disabled=true; $("vbFlexSel").disabled=true;
    $("vbNote").textContent="no VBMOD blob in this build";
    window.vb={data:false};
  }

  /* ---- eyes: the second material ---------------------------------------- */""")

io.open(P, "w", encoding="utf-8").write(s)
print("patch 3 applied")
