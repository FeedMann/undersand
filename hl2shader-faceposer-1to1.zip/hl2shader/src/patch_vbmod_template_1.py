"""Patch web_template.html for the VBMOD4 path: a second vertex program (the
model-format adapter), the buffers/textures it needs, the draw, and the UI.

Run from src/:  python3 ../tools/patch_vbmod_template.py   (or wherever)
"""
import io
import re
import sys

P = "web_template.html"
s = io.open(P, encoding="utf-8").read()
n_before = s.count("#define")

# ---------------------------------------------------------------- 1. the VS
VB_VS = r'''
/* =====================================================================
   VBMOD4 -- the model-format adapter

   Same vertex program *shape* as VERT_SRC (identical varyings, identical
   uniforms), different inputs: a VBMOD vertex record is position, UV, four
   joint indices and four weights, the base normals ride in the VBFLX1
   trailer, and there is no tangent space at all, so the frame the normal map
   needs is built here from a per-vertex tangent plus a handedness sign.

   This is the same split the engine has: the *material* is the pixel shader
   (skin_ps20b.fxc / eye_refract_ps2x.fxc) and the *model format* is the
   vertex shader that feeds it.  Nothing in the fragment shader below knows
   which format the vertices came from.
   ===================================================================== */
const VBMOD_VS = toES(`#version 330 core
layout(location = 0) in vec3 a_pos;       // VBMOD: position
layout(location = 1) in vec3 a_normal;    // VBFLX1 base normals
layout(location = 2) in vec2 a_uv;        // VBMOD: texcoord
layout(location = 3) in vec3 a_tangent;   // built offline from the UVs
layout(location = 4) in float a_sign;     // handedness (w), as an attribute

uniform mat4 u_model;
uniform mat4 u_view;
uniform mat4 u_proj;
uniform mat3 u_normalMat;
uniform float u_cFlexScale;               // unused here: the flexes are applied
                                          // on the CPU, like ApplyFaceFlexTargets()

out vec3 v_worldPos;
out vec3 v_worldNormal;
out vec2 v_uv;
out mat3 v_tangentSpaceTranspose;

void main()
{
    vec4 wp = u_model * vec4(a_pos, 1.0);
    v_worldPos = wp.xyz;
    vec3 N = normalize(u_normalMat * a_normal);
    vec3 T = normalize(u_normalMat * a_tangent);
    T = normalize(T - N * dot(N, T));
    vec3 B = normalize(cross(N, T)) * a_sign;
    v_worldNormal = N;
    v_uv = a_uv;
    v_tangentSpaceTranspose = mat3(T, B, N);
    gl_Position = u_proj * u_view * wp;
}`);
'''

anchor = "/* The room's own shader carries the same guarded probe branch, so it needs one"
if anchor not in s:
    anchor = "/* =====================================================================\n   ROOM"
assert s.count("const PROBE_FS") == 1
# insert right after PROBE_FS's closing backtick-semicolon
i = s.index("const PROBE_FS")
j = s.index("});", i) + 3
s = s[:j] + VB_VS + s[j:]

# ------------------------------------------------------- 2. state + defaults
s = s.replace('''  flex:{sel:0, weight:0.0},''',
'''  flex:{sel:0, weight:0.0},
  model:{src:PARITY?"head":"head", vbSel:0, vbWeight:0.0, vbMirror:true},''', 1)

# ------------------------------------------------------------- 3. boot code
BOOT = r'''
  /* ---- the VBMOD4 model: parse the file's own bytes, no conversion ------ */
  if(DATA.vbmod){
    const vbm=DATA.vbmod;
    const w=vbm.mesh;
    // the file ships HALF_FLOAT vertices; widen them once, here
    const hex=w.verts, n16=hex.length>>2;
    const u16=new Uint16Array(n16);
    for(let i=0;i<n16;i++) u16[i]=parseInt(hex.substr(i*4,4),16);
    const STRIDE=12;
    const base=new Float32Array(w.nverts*STRIDE);
    for(let i=0;i<base.length;i++) base[i]=h2f(u16[i]);
    gpu.vb={
      stride:STRIDE, nverts:w.nverts, base:base,
      pos:new Float32Array(w.nverts*3), nrm:new Float32Array(w.nverts*3),
      live:new Float32Array(base.length),
      meshes:vbm.meshes, targets:vbm.targets, eyes:vbm.eyes, name:vbm.name,
      maps:{}
    };
    for(let i=0;i<w.nverts;i++){
      gpu.vb.pos.set(gpu.vb.base.subarray(i*STRIDE,i*STRIDE+3),i*3);
      gpu.vb.nrm.set(gpu.vb.base.subarray(i*STRIDE+3,i*STRIDE+6),i*3);
    }
    gpu.vb.live.set(base);
    gpu.vbVBO=gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER,gpu.vbVBO);
    gl.bufferData(gl.ARRAY_BUFFER,gpu.vb.live,gl.DYNAMIC_DRAW);
    gpu.vbIBO=gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,gpu.vbIBO);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,b64ToBytes(w.index16?w.idx16:w.idx32),
                  gl.STATIC_DRAW);
    gpu.vbIndexType=w.index16?gl.UNSIGNED_SHORT:gl.UNSIGNED_INT;
    // the maps, uploaded like every other texture here (repeat wrap: a Source
    // UV atlas addresses u,v outside [0,1])
    const mkTex=(uri,wrapRepeat)=>{
      const t=gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D,t);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,
                    new Uint8Array([128,128,255,255]));
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,wrapRepeat?gl.REPEAT:gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,wrapRepeat?gl.REPEAT:gl.CLAMP_TO_EDGE);
      const img=new Image();
      img.onload=()=>{
        gl.bindTexture(gl.TEXTURE_2D,t);
        gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
        gl.generateMipmap(gl.TEXTURE_2D);
      };
      img.src=uri; return t;
    };
    gpu.vb.maps.albedo=mkTex(vbm.maps.albedo,true);
    gpu.vb.maps.bump=mkTex(vbm.maps.normal,true);
    gpu.vb.maps.expo=mkTex(vbm.maps.exponent,true);
    vbm.targetIndex={};
    vbm.targetNames.forEach((n,i)=>{ vbm.targetIndex[n]=i; });
  }
'''
# insert the boot block just before the probe-cloud program is created
marker = "  /* ---- the probe cloud: one point sprite per baked probe ---------------- */"
assert s.count(marker) == 1
s = s.replace(marker, BOOT + marker)
io.open(P, "w", encoding="utf-8").write(s)
print("template: VS + boot block in")
