# hl2shader — the Half-Life 2 skin shader, ported to OpenGL and run headless

This is a **learning artifact**, not a game mod. It takes Alyx's face material —
the real `.vmt`, parsed by real KeyValues code — runs it through the same combo
routing the engine uses, compiles the result to GLSL, and renders it under Xvfb
on llvmpipe so the whole thing runs with no GPU and no window.

Everything you can read in `out/` was produced by `src/` on this machine.

```
cd src
DISPLAY=:99 python3 render.py --size 900 --tex-res 512 --out ../out
```

There is also a **live browser version** of the same thing:

```
python3 src/web_export.py --tex-res 512     # bakes live/index.html (one file, no network)
python3 src/web_export.py --check           # compiles every permutation in real GL first
```

`live/index.html` is a single self-contained file (all textures are data URIs, no
CDN, no server): open it and you get the same head, room and shader, with sliders
for the twelve registers, the combo set, the lights, and a view selector that
replaces the final line of the fragment shader with any single term.

---

## 1. What is real and what is a stand-in

**Real:**

* The material text. `material_set/materials/models/alyx/alyx_faceandhair.vmt`
  is the Episode One face material (`$phong 1`, `$phongexponenttexture`,
  `$phongboost 6`, `$phongfresnelranges "[0.05 0.5 1]"`, `$halflambert 1`).
  It is parsed by `src/vmt.py` — a KeyValues tokenizer with `#base`/`#include`.
  No parameter is hardcoded anywhere in the renderer.
* The shader maths. `src/shader.py` is a line-by-line port of
  `skin_ps20b.fxc` (SDK 2013) plus `common_vertexlitgeneric_dx9.h`
  (`SpecularAndRimTerms`, `Fresnel`, `Fresnel4`, `DiffuseTerm`,
  `PixelShaderAmbientLight`) and `skin_dx9_helper.cpp` (register packing).
  Source file and line are named in the comments next to each block.
* The combo structure. `src/combos.py` uses the `.fxc` STATIC/DYNAMIC combo
  names verbatim (`SKIN`, `CUBEMAP`, `NORMALMAPALPHAENVMAPMASK`,
  `PHONG_USE_EXPONENT_FACTOR`, `RIMLIGHT`, `LIGHTWARPTEXTURE`, …) and mirrors
  `WantsSkinShader()` / `DrawSkin_DX9()` routing.
* The register layout. `PSREG_EYEPOS_SPEC_EXPONENT`, `PSREG_FRESNEL_SPEC_PARAMS`,
  `PSREG_SPEC_RIM_PARAMS`, `PSREG_AMBIENT_CUBE` … with the engine's encoding:
  fresnel `(min,mid,max)` → `((mid-min)*2, mid, (max-mid)*2)`, and
  `cAmbientCube` index order `[+x -x +y -y +z -z]`.
* The light behaviour. `src/lightcache.py` bakes probe grids (ambient cube +
  L1 SH + bounces) and lightmaps, then hands the head's probe to the shader as
  `cAmbientCube` — the same data an `info_lighting` / `light_origin` would supply.
* The container. `src/vtf.py` writes and reads real `.vtf` files (BGRA8888,
  with DXT1/3/5 decoders for reading Valve-authored ones) and the renderer
  proves the round trip before uploading a single texel.

**Stand-in (disclosed, not hidden):**

* **The head.** `models/alyx.mdl` is Valve's content; it is not redistributed
  here and is not downloaded by this project. `src/model.py` builds a
  procedural stand-in that is *built the way her model is built*: a parametric
  surface with explicit per-vertex tangents/bitangents, the face centred on
  `u = 0.5`, a raised hairband, and everything finer than a few mesh columns
  left to the `$bumpmap`. It is not Alyx; it is a body to hang her material on.
* **The textures.** `src/textures.py` synthesises `$basetexture`,
  `$bumpmap` (RGB normal + **alpha = phong mask**), `$phongexponenttexture`
  (R = exponent, G = albedo-tint blend, A = rim mask) and a `$lightwarptexture`
  ramp, with the zone layout her material expects. Real `.vtf` files, synthetic
  pixels.
* **The cubemap.** `$envmap "env_cubemap"` in a shipped map means "whatever the
  nearest `env_cubemap` entity baked". Here it is baked from the same probe the
  ambient cube comes from, so the six lobes carry real relative brightness. The
  browser renders it from six baked faces; the offline path from the same bake.
* **The room.** `lightcache.bake_lightmap(..., which="wall")` is the lightmap the
  walls and floor are lit by, in both renderers. It is a real bake of the test
  room's two lights — not an ambient tint — and `web_export.py` ships it to the
  browser as an 8-bit PNG (its range is 0.09..0.42, so 8 bits cost nothing).

---

## 2. Running it

```
# one-time, per sandbox (not saved in the workspace snapshot)
apt-get install -y xvfb x11-utils mesa-utils libgl1-mesa-dri
pip3 install moderngl glfw numpy pillow
Xvfb :99 -screen 0 1280x1024x24 -ac +extension GLX +render -noreset &

cd src
DISPLAY=:99 python3 render.py --size 900 --tex-res 512     # all five variants + validation
DISPLAY=:99 python3 terms.py  --size 512                   # the per-term sheet
DISPLAY=:99 python3 sheet.py                               # variant + texture contact sheet
DISPLAY=:99 python3 lightcache.py --visualize              # probe slices
```

`render.py` flags: `--variants ep1_phong,ep1_rim` to render a subset,
`--trace 0` to skip the per-pixel traces.

---

## 3. The five variants

Each is a real `.vmt` resolved at runtime — no branching on a hardcoded name.

| output | material | combos | what it shows |
|---|---|---|---|
| `vanilla_2004.png` | `alyx_faceandhair_2004.vmt` | `CUBEMAP, NORMALMAPALPHAENVMAPMASK, HALFLAMBERT` | HL2 2004: `$envmap` + bumpmap-alpha mask, **no `$phong` at all** |
| `ep1_phong.png` | `alyx_faceandhair.vmt` | `SKIN, HALFLAMBERT` | Episode One: exponent map, `$phongboost 6` |
| `ep1_lightwarp.png` | `…_lightwarp.vmt` | `SKIN, LIGHTWARPTEXTURE, HALFLAMBERT` | `$lightwarptexture`: `2 * tex1D(ramp, ndotl*0.5+0.5)` |
| `ep1_rim.png` | `…_rim.vmt` | `SKIN, RIMLIGHT, HALFLAMBERT` | `$rimlight`/`$rimmask`/`$rimlightpower` |
| `phong_off.png` | `alyx_faceandhair.vmt`, `mat_phong 0` | `HALFLAMBERT` | the engine's silent downgrade: `$phong` becomes 0, routing leaves the skin shader |

The `registers_live` count printed per variant is a readout of what the GLSL
compiler kept: `22` for the rim variant, `16` for `mat_phong 0`. A term that
disappeared from the uniform list is a term the combo compiled out.

---

## 4. Validation: CPU vs GPU

`src/shader.py` contains a second, independent implementation of the same maths
in numpy (`CPUShader`), fed the exact same G-buffer the GPU interpolates
(rendered into five float attachments, so both sides see byte-identical
`worldPos`, normal, T, B, uv).

Latest run, 284 877 model pixels:

```
p50 = 0.00043   p99 = 0.00097   max = 0.0021   (0.00% of pixels above 0.01)
```

The residual tail is bilinear-filter rounding on the highest-contrast texel
edges (the filter is exact-linear both times, the rounding is not). `out/cpu_vs_gpu_diff.png`
is the heatmap.

Two bugs this check caught, both invisible in a screenshot:

1. The eye-position register was left at `[0,0,0]` on the Python side, so the
   CPU shaded with the eye at the origin — every reflection vector wrong.
   Source fills `PSREG_EYEPOS_SPEC_EXPONENT.xyz` at draw time via
   `GetWorldSpaceCameraPosition()`; the port now mirrors that into the dict the
   CPU reads.
2. An `IndexError` at `base[..., 3]` — the CPU sampled the base texture as RGB
   when the combo couldn't use the alpha. `$basetexture` has an implicit opaque
   alpha channel, as the envmap and `$basemapalphaphongmask` paths assume.

---

## 4b. Validation: the browser vs the offline renderer

The two paths are not two implementations — `web_export.py` bakes **render.py's
own shader sources** (`VERT_SRC`/`FRAG_SRC`, `POST_VS`/`BRIGHT_FS`/`BLUR_FS`,
`WORLD_VS`/`WORLD_FS`), render.py's own room geometry (`render.build_world()`)
and `lightcache.bake_lightmap()`'s output. The only transformation is
`toES()`, which swaps the `#version` line for ES 3.00 + precision qualifiers.

So they can be compared directly. Headless Chromium (SwiftShader) at exactly the
offline resolution (900x900), same camera, same preset:

| variant | mean abs diff | p99 | pixels > 4/255 |
|---|---|---|---|
| `ep1_phong` | 0.208 | 1 | 0.36% |
| `ep1_lightwarp` | 0.331 | 4 | 1.07% |
| `ep1_rim` | 0.227 | 1 | 0.44% |
| `vanilla_2004` | 0.285 | 1 | 0.67% |
| `phong_off` | 0.196 | 1 | 0.32% |

The mean is a fifth of one 8-bit level. The remaining differences are the on-canvas
HUD text (not in the offline PNGs) and half-float rounding in the bloom chain where
the highlight is brightest — visible in `out/web_vs_offline.png` as the glow edge.

Writing that check paid for itself twice: it found that render.py was drawing the
room with `idx.shape[0]` as a *vertex* count (so the three walls and the second prop
were silently dropped), and that the baked lightmap was being handed to
`png_data_uri()` as a PIL image instead of a float array, turning it white in the
browser. Both are fixed; the offline PNGs in `out/` are regenerated with the walls.

---

## 5. The files

| file | what it is |
|---|---|
| `src/vtf.py` | VTF read/write; DXT1/3/5 decoders; header/format handling |
| `src/vmt.py` | KeyValues tokenizer/parser (`#base`, `#include`), `Material`, defaults table |
| `src/combos.py` | `HWConfig`, the `.fxc` combo set, `WantsSkinShader()` routing, register packing |
| `src/model.py` | the stand-in head; `tangent_frame()` and `encode_tangent_space_normal()` |
| `src/textures.py` | the four maps; the bump bake; the `.vmt`/`.vtf` writer |
| `src/shader.py` | `VERT_SRC` / `FRAG_SRC` (the port) + `CPUShader` (the numpy twin) |
| `src/render.py` | GL context, world + props + G-buffer, bloom, variants, validation |
| `src/trace.py` | per-pixel verbose traces, one line per HLSL line |
| `src/terms.py` | the per-term sheet — each term rendered on its own |
| `src/lightcache.py` | probe grid (ambient cube + L1 SH + bounces), lightmaps, probe slices |
| `src/scene.py` | the test room: two lights, a crate, a pillar, the camera |
| `src/sheet.py` | the contact sheet |
| `src/web_template.html` | the live viewer: ES conversion, JS port of `model.py`, the UI |
| `src/web_export.py` | bakes `live/index.html`; `--check` compiles every permutation |
| `notes/MAP_LIGHTING_AND_MATERIALS.md` | the map→model lighting path and the two-shaders question, with the engine quotes in full |

## 6. Outputs (`out/`)

| file | what to look at |
|---|---|
| `contact_sheet.png` | five variants + the textures that drive them |
| `term_breakdown.png` | twelve terms of `skin_ps20b.fxc`, each rendered alone, tagged with its source line |
| `trace.txt` | four per-pixel traces: the highlight, the strongest mask, a mid-mask pixel, a zero-mask pixel |
| `ep1_*.png`, `vanilla_2004.png`, `phong_off.png` | the renders |
| `cpu_vs_gpu_diff.png` | where the two implementations disagree |
| `probe_slice_ambientcube.png` | the six `cAmbientCube` lobes on a slice through the room, in the shader's own index order |
| `probe_slice_scalar.png` | total baked radiance on the same slice, with the two lights and the head marked |
| `lightcache.json` / `.npz` | the baked probes and lightmaps, with the ambient-cube index order documented |
| `report.json` | combos, active registers, validation numbers, traces |
| `live/index.html` | the live viewer — the same shader, interactive, in a browser |
| `web_vs_offline.png`, `web_vs_offline_sheet.png` | browser vs offline, and the diff between them |
| `web_viewer_ui.png` | the viewer as it looks in a real browser |
| `web_ep1_phong.png` … `web_phong_off.png` | the five presets, captured from the browser |
| `web_canvas_term_*.png` | term views, captured from the browser |
| `web_probes_*.png` | the probe cloud: default, per-pixel probe mode, outward-facing, wide shot |
| `web_eye_*.png` | the eye material, one isolation per term, and the full combine |
| `web_flex_jaw.png`, `web_flex_blink.png` | the two flex streams at full weight |

---

## 7. Things worth knowing before you read the code

* **`$phong` is not a combo.** It decides *which shader file runs*. With
  `$phong 0` (or `mat_phong 0`) the material never reaches `skin_ps20b.fxc`;
  it goes to `vertexlit_and_unlit_generic_bump_ps2x.fxc`, which has no specular
  code at all. The port keeps one program and gates the block on `SKIN`, with
  the routing documented at the gate.
* **The phong mask defaults to the `$bumpmap`'s alpha**, not the base texture's.
  `$basemapalphaphongmask 1` switches the source; `$invertphongmask 1` flips it.
* **Fresnel ranges are re-encoded in C++**, not in the shader:
  `(min,mid,max) -> ((mid-min)*2, mid, (max-mid)*2)` — visible in
  `skin_dx9_helper.cpp` around the `PSREG_FRESNEL_SPEC_PARAMS` write.
* **The specular exponent comes from a texture's red channel** when
  `g_EyePos_SpecExponent.w < 0`: `1 + 149 * texel.r`. `$phongexponent` in the
  VMT overrides it with a constant, `$phongexponentfactor` switches to
  `1 + factor * texel.r`.
* **The 2007 rim term is usually invisible next to `$phongboost 6`** — the code
  is `specularLighting = max(specularLighting, rimLighting)`, so the rim only
  shows where the phong highlight is weak. That is why `ep1_rim.png` and
  `ep1_phong.png` are close to identical, and why the trace is the better tool
  for seeing it.
* **A term view forces the combos it needs.** `PHONG MASK` only exists under
  `SKIN`, `envmap` only under `CUBEMAP`; selecting one switches those on and says
  so in the panel, because in the engine they are compile-time `#define`s and the
  term would not exist otherwise.
* **The viewer's first frame is render.py's camera.** It solves yaw/pitch/distance
  from `camEye -> camTarget` at boot so frame 1 is the picture in `out/`, and only
  diverges once you drag.
* **The lightcache is not just a diffuse ambient.** The same probe feeds
  `cAmbientCube`, the rim's view-ray lookup (`AmbientLight(vEyeDir)`) and the
  `$envmap` cubemap.

---

## 8. The map's baked lighting, and why a model is more than one shader

The long version, with every quote in full, is `notes/MAP_LIGHTING_AND_MATERIALS.md`.
The short version:

**Where a model's light comes from.** A compiled map stores light twice: lightmaps
per surface texel (brushes only) and the lightcache — a 3D lattice of probes that
each hold six colours, one per axis direction. The engine picks **one** probe per
entity, at the entity's origin (a 3×3×3 average of neighbouring probes, which is
`lightcache.sample_cube()`), and uploads it as six vertex-shader constants:

```hlsl
// common_vs_fxc.h
const float3 cAmbientCubeX [ 2 ] : register ( c21 ) ;
const float3 cAmbientCubeY [ 2 ] : register ( c23 ) ;
const float3 cAmbientCubeZ [ 2 ] : register ( c25 ) ;

float3 AmbientLight( const float3 worldNormal )
{
	float3 nSquared = worldNormal * worldNormal;
	int3 isNegative = ( worldNormal < 0.0 );
	float3 linearColor;
	linearColor = nSquared.x * cAmbientCubeX[isNegative.x] +
	              nSquared.y * cAmbientCubeY[isNegative.y] +
	              nSquared.z * cAmbientCubeZ[isNegative.z];
	return linearColor;
}
```

Six numbers are enough to light *any* normal because a normal is a set of weights.
That is the whole "fake lightcache": the data layout is the engine's, the map file
is what is faked (there is no `.bsp` here, so `src/lightcache.py` bakes the same
array and `web_export.py` ships it as a 3D texture).

**How the viewer shows it.** `live/index.html` ships that field and gives you the
three ways a model can consume it — the engine's, a per-pixel extension, and the
naive one:

| "ambient source" | what happens | where |
|---|---|---|
| `per-object cube` *(default)* | one cube per entity, from the map's probe field, uploaded before each draw — `u_ambientCube` in `render.py`, `cAmbientCube` in `skin_ps20b.fxc` | the engine's path |
| `per-pixel probe field` | the same six-lobe sum, but the cube is re-picked per fragment out of the 3D texture (`#define PORT_PROBE_AMBIENT`) | port extension, off by default |
| `flat` | one cube for the whole map — what a shader with a forgotten register upload looks like | the failure mode |

Tick **draw the probe cloud** to see the field itself: one point sprite per probe,
coloured by the light that cell hands a surface facing a chosen direction, read
straight from the same 3D texture the shaders sample (`PROBE_VS`, `gl.POINTS`,
depth-tested so the model occludes the probes inside it). `out/web_probes_wide.png`
is that view. The read-outs under it are evaluated with the shaders' own sample
(`LG.sampleCube` / `LG.sampleAmbient`), so they are the numbers the pixels use —
`head +x 0.229 0.375 0.613`, `crate +x 0.054 0.084 0.134`, `pillar +x 0.020 0.025 0.033`.

**Two shaders?** No — one program per draw, and the face flexes live *inside* it.
`common_vs_fxc.h` adds the deformation in the ordinary vertex shader:

```hlsl
// Only cFlexScale.x is used
// It is a binary value used to switch on/off the addition of the flex delta stream
const float4 cFlexScale					: register( c3 );

bool ApplyMorph( float3 vPosFlex, inout float3 vPosition )
{
	// Flexes coming in from a separate stream
	float3 vPosDelta = vPosFlex.xyz * cFlexScale.x;
	vPosition.xyz += vPosDelta;
	return true;
}
```

The viewer's model vertex shader is the port of exactly that line —
`layout(location = 5) in vec3 a_flex; ... vec3 pos = a_pos + a_flex * u_cFlexScale;`
— with two int8-normalised delta streams in one buffer (`blink`, `jaw_open`),
selected by byte offset. The flex slider scales them; at 0 the attribute array is
disabled and the vertex is `render.py`'s vertex, byte for byte. *The two deltas are
synthesised from the parametric head, not Alyx's `.vta` — the mechanism is Valve's,
the numbers are not.*

What *does* need a second program is a second **lighting model**: a material whose
pixel shader computes something the skin shader cannot express. On Alyx that is the
eyeballs — `models/alyx/alyx_eyes.mdl`, its own VMT, and `eye_refract_ps2x.fxc`
with its own cubemap, a 128-power glint instead of `$phongboost`, iris projection,
cornea refraction and pupil dilation. The viewer draws the model the same way the
engine does: the ported `skin_ps20b.fxc` for the head (face flexes and all), then
`EYE_FS` — a scoped port of `eye_refract_ps2x.fxc` — for the two eyeballs, whose
`g_flAverageAmbient` is the probe field's own value at that eyeball's origin. So
"how many shaders does a model need" has a real answer: **as many as it has
distinct lighting models, and the engine gets them by splitting the model into
materials — or, for the eyes, into a separate mesh with its own animation.**

## 9. The model format, end to end

The third thing in this package is the part that answers "run the ported shaders
on *our* model". Everything is implemented and running:

* `src/vbmod.py` — a VBMOD4 + VBFLX1 reader written against the format's own C++
  (`src/vb/vb_model.cpp`): 103 joints, 3070 vertices, 5168 triangles, 45 flex
  targets, 8585 sparse deltas in the trailer of the shipped `leanna.vbmod`.
* `src/vbmod_skin.py` — the generated skin (there is no texture in the package,
  by its own description): the face frame is *measured* from the eyeball meshes,
  the atlas is rasterised in UV space and painted by 3D position, the mesh-format
  adapter (VBFLX1 normals, UV-derived tangents, the UV remap into the atlas) is
  built here, and `preview_front()` writes a shaded front view straight from the
  baked atlas — a verifier that needs no GPU.
* `src/vbmod_materials.py` — the package's `.vbm` material layer, read as it is,
  mapped onto the ported shaders (`half_lambert → HALFLAMBERT`, `chisel_eye →
  eye_refract_ps2x`, `specularStrength → $phongboost`, …), with the custom-GLSL
  path stubbed to the documented `lit` fallback.
* `live/index.html` — the viewer gained a **model switch** (stand-in head /
  `leanna.vbmod`), a **material panel** showing the package's own `.vbm` JSON,
  **flex sliders** for the format's 45 targets, and a **light panel** that prints
  `cAmbientCube` at the entity origin next to the same lookup at the eyes, with
  per-object vs per-pixel probe sampling and a slider that walks the model across
  the room.

The long-form write-up for another agent is `notes/PORT_TO_OPENGL_AGENT_TASK.txt`
(byte layouts, the adapter table, the ambient-cube order, the traps that were hit
here); `notes/MAP_LIGHTING_AND_MATERIALS.md` Part 3 is the short version.

## 10. Taking it the other way: into FacePoser

`notes/FACEPOSER_1TO1_HANDOVER.md` (and the same text as
`notes/FACEPOSER_1TO1_HANDOVER.txt`) is the handover for the reverse direction:
putting *this* renderer — the ported shaders, the material mapping, the
lightcache and its test rig — inside the FacePoser tool, 1:1.

Its one structural instruction: keep the `.vbm`/`.cmt` material **layer** (file
format, field names, search order, missing-texture fallback) and retire the
placeholder built-in shaders (`lit`, `half_lambert`, `chisel_eye`) by pointing
them at the ported programs — `half_lambert` maps exactly onto Source's
`$halflambert 1`, `chisel_eye` onto the ported `eye_refract_ps2x.fxc`. It then
lists the tool's real integration points (`kMeshVertex`/`kMeshFragment`/
`kEyeFragment`, the per-mesh draw in `FacePoserApp.cpp`, `rb::Shader`,
`material::Definition`, the CPU morph upload, the `1.0f - v` flip), the tasks in
order, and the acceptance criteria for each — including the lightcache *testing*
rig (probe cloud, read-outs, term isolates, CPU-vs-GPU parity) because that is
what makes the port checkable rather than claimed.
