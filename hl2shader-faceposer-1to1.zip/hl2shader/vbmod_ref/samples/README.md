# Leanna: SMD + VTA port

`leanna.vbmod` was built from `../../source/leanna/leanna_reference.smd` and `leanna_reference.vta` by `tools/smd_vta_to_vbmod.py`. The face controllers, rules and visemes come from the compiled `../npc_leanna.vbmod`.

Open it in FacePoser with **File → Open VBMOD (FaceFlex)…**. Then press **F** to frame the head and type a line into **Dialogue**.

| | |
|---|---|
| Skeleton | 103 bones (SK_Root … SK_Hair_*, SK_Dress_*), with real skin weights |
| Geometry | 3,070 vertices, 5,168 triangles; meshes `eyeball_r`, `eyeball_l`, `xana` |
| Face | 45 flex targets (28 VTA frames, stereo pairs split into R/L), 8,585 sparse deltas |
| Rig | 59 controllers, 63 compiled rules, 15 visemes, 5 expression presets |

## Materials

| File | What it is |
|---|---|
| `materials/xana.vbm` | Skin/body, `half_lambert`. Expects `materials/xana.png` (or `.tga`, `.jpg`, `.vtf`). Until that exists, the body uses the plain lit fallback colour |
| `materials/eyeball_r.vbm`, `eyeball_l.vbm` | Procedural `chisel_eye`; needs no texture |

To add the real skin, drop `xana.png` into `materials/` and press **Reload material files**. If you find the original VMT/VTF files, port them with `tools/vmt_to_vbm.py`. See `MATERIALS_HOWTO.md` for both.

## Rebuild

```sh
python3 tools/smd_vta_to_vbmod.py samples/source/leanna/leanna_reference.smd \
  samples/source/leanna/leanna_reference.vta samples/faceflex/leanna/leanna.vbmod \
  --rig samples/faceflex/npc_leanna.vbmod --asset-name Leanna \
  --materials-out samples/faceflex/leanna/materials \
  --summary-json samples/faceflex/leanna/leanna_conversion_report.json
```

Limitations (no hair in this SMD, eyelid/AU42 flexes not wired to `blink`) are listed in `SMD_VTA_TO_VBMOD_GUIDE.md`.
