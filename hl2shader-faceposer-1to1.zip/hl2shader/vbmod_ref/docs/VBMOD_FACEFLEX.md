# VBMOD4 + VBFLX1 FaceFlex format

## What FacePoser reads

A legacy VBMOD4 model stores a skeleton, meshes, indexed vertices, hit groups, hitboxes, attachments, and IK chains. The fixed vertex record contains a position, UV, four joint indices, and four weights; it does not include facial morph targets. This project defines an optional `VBFLX1` trailer for base normals and sparse facial-target deltas. The original VBMOD4 header and tables are unchanged, so ordinary VBMOD4 readers can still read the base model if they ignore trailing data.

A VBANIM v3 remains skeletal animation only. FacePoser stores dialogue and facial cues separately in `.faceflex.scene.json` or `.ffsb` scene files.

## Binary layout

All values are little-endian. The extension follows the original IK-chain table.

### Header — 36 bytes, packed

| Field | Type | Meaning |
|---|---:|---|
| `magic` | `char[8]` | `VBFLX1\0\0` |
| `version` | `uint32` | `1` |
| `headerSize` | `uint32` | `36` |
| `payloadSize` | `uint32` | Bytes following this header |
| `normalCount` | `uint32` | `0` or the VBMOD vertex count |
| `targetCount` | `uint32` | At most 8,192 |
| `deltaCount` | `uint32` | At most 10,000,000 |
| `metadataBytes` | `uint32` | UTF-8 metadata JSON bytes; at most 64 MiB |

### Payload order

1. `normalCount` base normals, each three `float32` values.
2. `targetCount` descriptors, each **164 bytes**: `name[64]`, `pairName[64]`, `int32 descriptorIndex`, `int32 pairIndex` (`-1` means no pair), `float32 targetCurve[4]`, `uint32 firstDelta`, `uint32 deltaCount`, `uint8 vertexAnimType`, and three reserved bytes.
3. `deltaCount` sparse records, each **44 bytes**: `uint16 meshIndex`, `uint16 reserved`, `uint32 vertex`, `uint32 sourceVertexIndex`, `float32 positionDelta[3]`, `float32 normalDelta[3]`, `uint8 speed`, `uint8 side`, `uint8 vertexAnimType`, `uint8 flags`, `int16 wrinkleRaw`, and `uint16 reserved`.
4. Exactly `metadataBytes` UTF-8 bytes containing the FaceFlex metadata JSON.

`payloadSize` must equal the combined payload length. The reader validates the recognized extension's version, sizes, counts, target ranges, vertex references, and finite numeric values; malformed or truncated `VBFLX1` data is rejected. Unknown legacy trailing bytes that are not a `VBFLX1` extension retain the base reader's ignore behavior; saving does not preserve unknown tail data.

The metadata blob can retain FaceFlex mesh/asset descriptors, Source controller and compiled flex-rule data, and phoneme/preset authoring maps. The C++ model reader preserves the blob but does not parse or execute the Source controller-rule virtual machine. FacePoser evaluates its own controller, viseme, expression, and scene layers. `ApplyFaceFlexTargets` applies a supplied linear weight per target to the sparse position/normal deltas.

## JSON and FFXB conversion bridge

`tools/faceflex_vbmod.py` is a standard-library Python bridge for compatible FaceFlex JSON and FFXB assets:

```sh
python3 tools/faceflex_vbmod.py import input.faceflex.json output.vbmod
python3 tools/faceflex_vbmod.py import input.ffxb output.vbmod

python3 tools/faceflex_vbmod.py export output.vbmod output.faceflex.json
python3 tools/faceflex_vbmod.py export output.vbmod output.ffxb
```

The conversion carries base positions, normals, UVs and triangle indices, target names/pairings/curves, sparse source records, and source/authoring metadata. The included sample is a ready-to-open `.vbmod`; the bridge also accepts compatible FaceFlex JSON or FFXB assets supplied separately.

The C++ API is declared in `src/vb/vb_model.h`:

```cpp
bool vbmod::ApplyFaceFlexTargets(
    const vbmod::Model& model,
    const std::vector<float>& weights,
    std::vector<vbmod::Vec3>& positions,
    std::vector<vbmod::Vec3>* normals,
    std::string* error);
```

Weights use `Model::faceFlexTargets` order. Base normals are available through `Model::faceFlexNormals`. Sparse records accumulate linearly; a renderer is responsible for normalizing the resulting normals.

## Included sample and limitations

`samples/faceflex/dad.vbmod` is the supplied Source 1 MDL/VVD/DX90 VTX conversion: **64,639 vertices, 107,018 triangles, 105 joints, 22 meshes, 31 target curves, 60 compiled rules, and 46,389 sparse deltas**. Its complete bodypart/material-slot counts and source checksum are in `samples/faceflex/dad_conversion_report.json`. The converter preserves the LOD0 mesh vertex weights and UVs, flex-controller/rule data, and sparse face deltas.

The Source file is named `alyx.mdl`, but its embedded model-part names contain `KRYSTALFOX2018...`; the package labels the converted asset DAD rather than asserting that it is the stock Alyx character. Three supplied VTFs are monitor/effect/scene images; they do not match the model's 20 material slots. Original VTFs, first-frame PNG previews, and minimal portable `.vbm` wrappers are supplied for reuse, but they are deliberately not attached to the character mesh. A neutral lit fallback is expected until matching character material files are provided.

The `.vbmod` embeds the `VBFLX1` target bank and opens directly in FacePoser. Companion `dad_example.faceflex.scene.json` and `dad_example.faceflex.ffsb` files demonstrate editable generated take formats; scenes store dialogue, timing, and curves separately from the model binary. FacePoser's text-to-viseme output is approximate: use recorded audio with phoneme alignment and manual cue edits for production lip-sync.
