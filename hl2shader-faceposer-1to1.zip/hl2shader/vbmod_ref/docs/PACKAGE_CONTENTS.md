# Current snapshot contents

This ZIP is a point-in-time source/work snapshot, not a final acceptance package.

- `src/faceposer/FacePoserCurves.*` — direct-flex data, curve evaluation,
  guide compilation, exact serialization and legacy materialization.
- `src/faceposer/FlexCurveEditor.*` — editable flex-curve timeline.
- `src/faceposer/FacePoserAudio.*` — Rhubarb process bridge, WAV loader and
  audio-informed generation.
- `src/faceposer/FacePoserEditing.cpp` and `src/faceposer/FacePoserApp.cpp` —
  report, save/unload, model, timeline and authoring UI changes.
- `src/ui/Gui.cpp` — rich-text report hover routing and vertical/horizontal
  scrolling controls.
- `tools/source_mdl_to_vbmod.py` — Source MDL/VVD/VTX to VBMOD4 + VBFLX1
  converter, including fixed-point/binary16 vertex-animation decoding.
- `tools/source_vtf_to_png.py` — VTF preview conversion.
- `samples/source/dad/` — supplied MDL/VVD/DX90 VTX trio, available VTFs and
  portable `.vbm` wrappers.
- `samples/faceflex/` — converted DAD VBMOD, conversion report, generated JSON
  and FFSB sample takes, PNG previews and conversion notes.
- `tests/` — CTest source for direct-flex geometry/runtime validation and VTF
  decode hashes.
- `proof/` — existing Xvfb captures and runtime test summary. They are not a
  fresh acceptance set for the latest save/unload UI changes.
- `STATUS_AND_COMPLETED_WORK.md` — completed work, test results, limitations
  and the remaining manual verification items.
- `docs/MDL_TO_VBMOD_PORTING_GUIDE.md` — Source MDL/VVD/VTX versus VBMOD4/VBFLX1
  comparison, data mapping, encoding details and reproducible port commands.
- `DIRECT_FLEX_README.md`, `FACEPOSER_README.md`, `docs/` — build and usage
  documentation.
- `third_party/rhubarb/win64/` — Rhubarb Lip Sync 1.14.0 Windows x64 engine,
  recognizer resources and notices.

The generated `build/` directory is intentionally excluded. Configure and
build with CMake as documented in `README.md` and `DIRECT_FLEX_README.md`.
