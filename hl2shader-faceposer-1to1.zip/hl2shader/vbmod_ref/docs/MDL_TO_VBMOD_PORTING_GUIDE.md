# Source MDL → VBMOD4 + VBFLX1 porting guide

This is a handoff guide for someone porting another Source 1 character into this FacePoser project. It describes the formats, what the current converter preserves, the DAD conversion result, and the known limitations. The implementation lives in `tools/source_mdl_to_vbmod.py`; the destination reader/writer lives in `src/vb/vb_model.cpp` / `src/vb/vb_model.h`.

## Short version: the formats are not one-to-one

| Source asset | Role in Source | Destination |
|---|---|---|
| `.mdl` (`IDST`) | Header, bones, bodyparts/models/meshes, material slots and skin references, flex descriptors/controllers/rules, sparse flex records | Split across VBMOD base data and VBFLX1 metadata/targets |
| `.vvd` (`IDSV`) | LOD vertex pool: skin weights, positions, normals, UVs, fixups | VBMOD vertices/weights/UVs; VBFLX1 base normals |
| `.dx90.vtx` | Optimized LOD topology, strip groups and triangle indices | VBMOD mesh ranges and 32-bit indices |
| `.vmt` / `.vtf` (if supplied) | Material definitions and texture pixels | Not embedded in VBMOD by this converter; material lookup and VTF image decoding are separate |
| `.vbmod` (`VBMOD4`) | This project's base skinned model format | Skeleton, meshes, vertices, indices and optional standard model tables |
| VBMOD trailer (`VBFLX1`) | This project's optional FaceFlex extension | Base normals, sparse morph targets/deltas and UTF-8 metadata JSON |
| `.faceflex.scene.json` / `.ffsb` | FacePoser performance/take, not a mesh | Kept separate from the model binary |

A `.mdl` alone is not enough to reproduce the renderable Source mesh. The matching VVD and VTX are essential. A `.vbmod` is a custom FacePoser asset, **not** a Source MDL or an engine-ready Source model.

## Input compatibility and matching files

The converter accepts Source 1 studio MDL versions **44 and 48**, a matching VVD **version 4**, and a matching DX90 VTX **version 7**. All three files must carry the same checksum. By default, the converter looks for `<mdl stem>.vvd` and `<mdl stem>.dx90.vtx` next to the MDL; `--vvd` and `--vtx` override those paths.

The parser validates file spans, counts, offsets, checksums, finite numeric values, bone references, mesh ranges and output-size limits. It rejects unsupported or malformed records instead of guessing.

## What the converter does, in order

### 1. Parse the MDL header and skeleton

- Check `IDST`, declared file length, checksum, and version 44/48.
- Read the flags and header tables for bones, material slots, skin families, bodyparts, flex descriptors, flex controllers and flex rules.
- Preserve bone names and parent indices. Source `poseToBone` is the inverse bind transform, so the converter inverts the affine 3×4 matrix to produce VBMOD `bindPose`; the Source matrix is retained as `inverseBind`.
- Keep Source model coordinates. The converted DAD note documents the conventional X-forward/Z-up orientation; the converter does not silently rotate the axes.
- Resolve each mesh's material slot through skin family 0 and retain the resulting material name.

Relevant MDL header locations used by this Source 1 layout include: checksum at byte 8; flags at 152; bone count/offset at 156/160; material count/offset at 204/208; skin-ref count/family count/table offset at 220/224/228; bodypart count/offset at 232/236; flex descriptor count/offset at 260/264; controller count/offset at 268/272; rule count/offset at 276/280; and `vertAnimFixedPointScale` at 392. The code is the authority for field interpretation and range checking.

### 2. Reconstruct LOD0 vertices from the VVD

- Check `IDSV`, version 4, and checksum against the MDL.
- Read the LOD vertex counts and apply LOD0 VVD fixups in their listed order. If no fixups are present, use the LOD0 prefix of the raw pool.
- A Source VVD vertex is 48 bytes: three weight floats, three bone-index bytes, influence-count byte, position (3 floats), normal (3 floats), and UV (2 floats).
- Copy up to three Source bone influences into VBMOD's four influence slots; the unused slot(s) are zero. Preserve position, UV, and base normal. VBMOD's fixed vertex record has no normal field, so base normals go in the VBFLX1 trailer.

### 3. Reconstruct mesh indices from the DX90 VTX

- Check VTX version 7, checksum, LOD count and bodypart count.
- For each MDL bodypart, select **model 0** and **LOD 0**. Within that selection, preserve the MDL mesh ranges/material names.
- Walk VTX strip groups. VTX group-local vertices map back through each entry's original MDL mesh-vertex ID. Convert triangle lists and triangle strips to explicit triangles; odd strip triangles reverse their first two vertices to preserve winding.
- Convert each mesh-local index to the concatenated VBMOD vertex index using the selected body's model base + mesh vertex offset + original mesh vertex ID.
- VTX can contain overlapping alternate hardware/software/flex strip groups. The converter removes duplicate geometric triangles when those groups overlap.

### 4. Port the Source flex targets and deltas

- Read each MDL mesh flex record: descriptor index, four target-curve breakpoints, sparse record count/relative offset, pair descriptor and vertex-animation type.
- Merge matching records across included submeshes by descriptor, pair, four breakpoints and animation type. This makes a target such as an AU apply to its sparse records on all relevant included meshes.
- Convert a record's mesh-local vertex index to the VBMOD global vertex index. Retain its local source index, output mesh index, `speed`, `side`, animation type, flags and raw wrinkle value.
- Store the six decoded components as position delta `(dx,dy,dz)` plus normal delta `(dnx,dny,dnz)`.

#### Important fixed-point versus binary16 rule

Source `studiovertanim_t` uses the same 12 component bytes in one of two encodings. The MDL flag `STUDIOHDR_FLAGS_VERT_ANIM_FIXED_POINT_SCALE` is `0x00200000` in the converter:

- **Flag set:** read six signed 16-bit integers and multiply each by the positive float scale at MDL byte offset 392.
- **Flag clear:** read six IEEE-754 binary16 (half-float) values directly; do **not** reinterpret their bit patterns as signed integers and do not multiply by `1/4096`.

The DAD input has the flag clear, so its encoding is `ieee754-binary16` and the reported extra scale is `1.0`. Treating these half-float bits as shorts caused large, visibly broken polygons; correcting this decoding fixed the conversion artifact. Type-1 wrinkle records have an 18-byte record (the final signed 16-bit wrinkle field); type-0 records are 16 bytes.

### 5. Write the custom VBMOD4 base and VBFLX1 extension

The VBMOD4 base begins with a packed 60-byte header:

| Offset | Field |
|---:|---|
| 0 | 8-byte magic `VBMOD4\0\0` |
| 8 | `uint32` version 4 |
| 12 | `uint32` endian marker `0x01020304` |
| 16 | `uint64` skeleton hash |
| 24 | `float32` presentation yaw offset |
| 28–59 | Eight `uint32` counts: joints, meshes, vertices, indices, hit groups, hitboxes, attachments, IK chains |

The tables follow in this order: joints, meshes, vertices, 32-bit indices, hit groups, hitboxes, attachments, IK chains. This conversion writes the skeleton, meshes, vertices, indices and flex payload; it does not currently synthesize Source hitboxes, attachments, IK chains or skeletal animation clips.

Key base-record layouts from `src/vb/vb_model.cpp`:

- **Joint (164 bytes):** NUL-padded UTF-8 name[64], `int16` parent, reserved `uint16`, 12-float row-major 3×4 bind matrix, 12-float inverse-bind matrix.
- **Mesh (144 bytes):** name[64], material[64], then `firstVertex`, `vertexCount`, `firstIndex`, `indexCount` as four `uint32` values.
- **Vertex (44 bytes):** position[3] `float32`, UV[2] `float32`, four joint indices `uint16`, four weights `float32`.
- **Indices:** `uint32` values addressing the concatenated VBMOD vertex array.

If the file has a VBFLX1 trailer, a legacy reader can still read the VBMOD base if it ignores trailing bytes. This project's reader recognizes the trailer and validates its declared sizes/counts.

### 6. VBFLX1 extension layout

The trailer begins with a packed 36-byte header: magic `VBFLX1\0\0`, version 1, header size, payload size, normal count, target count, sparse delta count and metadata byte count (all integers after the magic are `uint32`). Payload order:

1. `normalCount` base normals, three `float32` values per vertex.
2. `targetCount` 164-byte descriptors: name[64], pair name[64], descriptor index and pair index (`int32` each), four target-curve floats, first-delta and delta-count (`uint32` each), animation type byte and 3 reserved bytes.
3. `deltaCount` 44-byte records: output mesh index (`uint16`), reserved `uint16`, global VBMOD vertex index (`uint32`), source/local vertex index (`uint32`), position delta[3] and normal delta[3] (`float32`), speed, side, animation type, flags (bytes), raw wrinkle (`int16`), reserved `uint16`.
4. Exactly `metadataBytes` UTF-8 JSON bytes.

The four target-curve breakpoints preserve the Source MDL curve mapping for compiled-rule weights. An editable direct F-curve in a FacePoser scene is already a final target weight; it bypasses that Source target-curve mapping. Scene/take data is stored separately in JSON/FFSB files and is not part of the model binary.

## What was ported for the supplied DAD sample

Inputs are `samples/source/dad/alyx.mdl`, `alyx.vvd`, and `alyx.dx90.vtx`. The output is `samples/faceflex/dad.vbmod` plus its detailed `dad_conversion_report.json`.

- 105 joints; 64,639 vertices; 22 meshes; 107,018 triangles.
- 31 merged flex targets and 46,389 sparse deltas; 60 compiled rules; 59 controllers; 68 descriptors; 14 generated viseme recipes and 4 expression presets.
- The Source rule/controller tables are retained in VBFLX metadata and evaluated by FacePoser's rule VM. The DAD report has no unsupported rule opcodes.
- The **14 phoneme recipes and 4 presets are generated AU-based approximations**, not a claim that the Source MDL contained those exact authored recipes. Only names matching target flexes on the model can create visible target weights.
- The filename `alyx.mdl` does not prove the model is stock Alyx: embedded bodypart/model names include `KRYSTALFOX2018...`, so the converted asset is labelled DAD.
- The MDL names 20 material slots, but the supplied three VTFs are monitor/effect/scene images, not matching character skin textures. They are retained and previewed, with portable `.vbm` wrappers, but not attached to the character slots.
- This is not an animation-sequence port. It does not convert Source `.ani`/sequence animation, alternate bodygroup model choices, all LODs, or synthesize hitboxes/attachments/IK chains.

## Re-run the conversion

From the project root, with the matching input triplet in place:

```sh
python3 tools/source_mdl_to_vbmod.py \
  samples/source/dad/alyx.mdl samples/faceflex/dad.vbmod \
  --asset-name DAD --summary-json samples/faceflex/dad_conversion_report.json
```

For another model, pass its matching files explicitly if naming differs:

```sh
python3 tools/source_mdl_to_vbmod.py character.mdl output.vbmod \
  --vvd character.vvd --vtx character.dx90.vtx \
  --asset-name Character --summary-json conversion_report.json
```

## Validation that was run

- Release CMake/Ninja build succeeded; CTest reported 2/2 tests passing.
- `tests/faceposer_runtime_test.cpp` loads JSON and FFSB samples, checks all direct curve target indices/final weights and confirms finite deformation. Each take changed 3,901 vertices; maximum position delta was 0.505782 at 0.827 s.
- `tests/vtf_decoder_test.cpp` verifies the three supplied VTF images against fixed first-frame RGBA hashes.
- `tools/model_metadata_roundtrip_test.py` and `tools/ffsb_roundtrip_test.py` passed; Python tool syntax compilation passed.

See `docs/VBMOD_FACEFLEX.md` for the general VBMOD/VBFLX format spec and `STATUS_AND_COMPLETED_WORK.md` for the overall status, including remaining manual UI checks.
