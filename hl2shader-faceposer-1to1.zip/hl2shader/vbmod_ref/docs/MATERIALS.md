# FacePoser materials and texture lookup

FacePoser keeps images outside the `.vbmod` file. Each mesh carries a material reference, which the app resolves using the model folder and any optional material/game-data roots.

## Search order

1. Model folder.
2. Folder supplied with `--materials DIR`.
3. Folder supplied with `--assets DIR`.

For a material reference, the resolver checks the exact path and the `materials/` path under each root, with `.vbm` and `.cmt` extensions when the reference has no extension. An authored albedo path is checked beside its `.vbm`/`.cmt` file, under each root, and under `textures/`; extensionless paths try PNG, TGA, JPG, JPEG, BMP, and VTF.

The **Materials** tab displays these roots, the full material and texture paths selected, and the full candidate paths checked when a reference cannot be found. A missing texture does not stop FacePoser from loading the mesh; the affected surface uses the built-in neutral lit fallback. Use **Reload material files** after adding a file.

Example:

```text
faceposer models/npc.vbmod --materials "D:/project/materials" --assets "D:/game/gamedata"
```

The material reader accepts `.vbm` definitions, a portable subset of Chisel `.cmt` JSON, and direct image references. Built-in shader types include `lit`, `half_lambert`, and the procedural `chisel_eye` preview. Custom GLSL fragment shaders are supported for advanced users; a compile failure falls back to lit shading so the model remains visible.

Source VTF 7.0–7.2 is decoded directly for VTF DXT1 and common RGB/RGBA formats; animated VTF files display their first high-resolution frame. `tools/source_vtf_to_png.py` can also extract a portable first-frame PNG using only Python's standard library.

The DAD conversion includes three VTFs and minimal portable `.vbm` wrappers. They are effect/monitor/scene textures and do not match the converted model's material-slot names, so the converter intentionally does not bind them to the character. The mesh uses the neutral lit fallback until matching character skin materials are supplied.
