hl2shader -- the HL2 model/world shaders ported to OpenGL, run on the VBMOD
format, plus two handover documents for the next agent
===========================================================================

Start here, in this order:

  1. notes/PORTING_1TO1.md          what to remember to port this 1:1
                                    (notes/PORTING_1TO1.txt is the same text,
                                     plain ASCII, for a terminal)
  2. notes/MAP_LIGHTING_AND_MATERIALS.md
                                    are the walls really lightmapped, is the
                                    model really VertexLitGeneric, how a model
                                    inherits the map's light, and why a
                                    character is more than one material.
                                    Part 3 covers the VBMOD work.
  3. notes/PORT_TO_OPENGL_AGENT_TASK.txt
                                    the guide for another agent: Source shaders
                                    -> this port -> the VBMOD4 + VBFLX1 format
                                    (byte layouts, the format adapter, the
                                    ambient cube, the flex stream, the traps)
  4. notes/FACEPOSER_1TO1_HANDOVER.md / .txt
                                    the reverse direction: porting THIS renderer
                                    1:1 INTO the FacePoser tool -- the shaders,
                                    the material layer mapping, the lightcache
                                    and its test rig.  Its instruction: keep the
                                    .vbm material layer, retire the placeholder
                                    Chisel-style built-ins (lit / half_lambert /
                                    chisel_eye) and point them at the ported
                                    Source programs.
  5. hl2shader/README.md            what the port is, what is real vs stand-in,
                                    and how to run every part of it
  6. hl2shader/live/index.html      open in a browser: the live viewer
                                    (self-contained, no server, no network)

What is in here
---------------

  hl2shader/src/            the port
      vmt.py                KeyValues parser (#base/#include), material defaults
      combos.py             combo set, WantsSkinShader routing, register packing
      shader.py             GLSL source + CPU numpy twin   <- the shader
      model.py              procedural stand-in head (tangent frames, UV layout)
      textures.py           the four maps + .vtf writer, synthesised pixels
      render.py             GL context, room (build_world), lightcache hookup,
                            bloom/tonemap, five variants, CPU-vs-GPU check
      lightcache.py         probe grid (ambient cube + L1 SH), lightmaps, bakes
      scene.py              the test room: two lights, props, camera
      trace.py              verbose per-pixel traces, one line per HLSL line
      terms.py              per-term sheet: each term of the shader, alone
      sheet.py              the contact sheet
      web_template.html     the live viewer (UI + JS port of model.py + ES conv)
      web_export.py         bakes live/index.html; --check compiles all perms
      vbmod.py              VBMOD4 + VBFLX1 reader (the format's own bytes)
      vbmod_skin.py         generated skin for the VBMOD model + the viewer
                            payload + preview_front() (a GPU-free verifier)
      vbmod_materials.py    the .vbm material layer -> ported shader knobs

  hl2shader/vbmod_ref/      the FacePoser material/format reference subset:
      docs/                 VBMOD_FACEFLEX.md, MATERIALS.md,
                            MDL_TO_VBMOD_PORTING_GUIDE.md, PACKAGE_CONTENTS.md
      materials/*.vbm       xana.vbm, eyeball_l.vbm, eyeball_r.vbm (verbatim)
      samples/leanna.vbmod  the model, with its conversion report

  hl2shader/out/            every image and number quoted in the docs
      contact_sheet.png     five material variants + the texture inputs
      term_breakdown.png    twelve terms of the shader, each rendered alone
      trace.txt             four per-pixel traces (the highlight, masks, zero)
      web_vbmod_*.png       the VBMOD model in the live viewer (portrait, the
                            $basetexture isolate, the flex, the move test)
      vbmod_skin_front.png  the generated skin, straight off the baked atlas
      web_vs_offline*.png   browser vs offline render, and the diff
      web_eye_*.png         the eye material, one isolation per term
      report.json           combos, live registers, validation numbers
      lightcache.json/.npz  the baked probes and lightmaps

  hl2shader/material_set/   the .vmt / .vtf set the port actually loads
  hl2shader/live/index.html the live WebGL2 viewer (single file, ~2.5 MB)

  engine-sources/           Valve's shader source, for reference only:
                            skin_ps20b.fxc, eye_refract_ps2x.fxc,
                            skin_dx9_helper.cpp, common_vs_fxc.h,
                            common_vertexlitgeneric_dx9.h, common_fxc.h,
                            common_ps_fxc.h, the vertexlit/bump variants, and
                            the 2007 copies for the Ep1 differences.
                            NOT redistributable as part of a product.

  analysis-html/            the three write-ups:
      alyx_phong_shader_math.html   the maths, quoted line by line
      alyx_vmt_breakdown.html       the VMTs, quoted
      ep1_alyx_phong.html           the Ep1 material, annotated

  reference-shots/          Valve's own reference renders, for comparison

Numbers that were measured, not asserted (details in the notes):
  64 GLSL programs compiled, 0 failed (web_export.py --check)
  browser vs offline, mean/p99/%>4: ep1_phong 0.112/1/0.04, lightwarp
  0.178/1/0.58, rim 0.112/1/0.04, vanilla_2004 0.111/1/0.04, phong_off
  0.111/1/0.04   (900x900, SwiftShader)
  CPU twin vs GPU: p50 0.00043, p99 0.00097, max 0.0021 over 284,877 pixels
  leanna.vbmod: 683 KB, 103 joints, 3070 verts, 5168 tris, 45 flex targets,
  8585 sparse deltas; probe field 26x18x28 = 13,104 probes, cube max 1.656

For learning purposes only.  No Valve asset is redistributed here; the skin,
the eye recipes and the VMTs are generated stand-ins, and the FacePoser
package's own .vbm files are material definitions, not art.
