# Porting the Source skin shader 1:1 to a real OpenGL engine

Notes from the `hl2shader/` port. Written for someone who wants the *engine's*
result, not an approximation of it: what has to be reproduced exactly, what is
allowed to differ, and which traps cost us a debug cycle each.

Quote convention: `file:line` refers to Valve's shader source as vendored in
`src_shaders/` (SDK 2013 `materialsystem/stdshaders/` unless noted). `src/*.py`
refers to this project.

---

## 0. The short version

If you remember five things:

1. **The shader is not one file.** `skin_ps20b.fxc` is the pixels only. Compile-time
   behaviour lives in the combo `#define`s, the *register contract* lives in
   `skin_dx9_helper.cpp`, the reusable math lives in `common_vertexlitgeneric_dx9.h`
   and `common_ps_fxc.h`, and half the inputs come from the **vertex** shader and
   the **model file**. Porting the .fxc alone gives you a function nobody calls.
2. **Source shades in gamma space, but adds lights in linear space.** Static
   lightmaps are gamma-space values premultiplied by `cOOOverbright`, converted
   with `GammaToLinear()` for the add, and the result is sRGB-encoded at the very
   end (`SRGBOutput`, `FinalOutput`). Get this wrong and every highlight is 30%
   off while still looking "plausible".
3. **Tangents come from the model, not from your UVs.** `i.tangentSpaceTranspose`
   is a per-vertex 3×3 built by the engine's exporter. Generating a MikkTSpace TBN
   from the UVs gives a different normal map and therefore a different phong mask,
   a different exponent, and a different highlight.
4. **The constants are packed, not clean.** Four lights live in three
   `PixelShaderLightInfo` records with the fourth spread across the `.w` lanes
   (`common_vertexlitgeneric_dx9.h:139-165`). If you "clean this up", you have
   written a different shader — do it on purpose and document it.
5. **Verify with a diff, not with your eyes.** We caught two real bugs (a broken
   room draw and a white lightmap) only because the browser render and the offline
   render were compared numerically at identical resolution and camera.

---

## 1. What "1:1" can and cannot mean

**Can be 1:1:** the arithmetic (`pow`, `lerp`, `saturate` chains), the combo
selection, the register values, the routing decisions, the texture inputs, the
final output path, the light-vector construction.

**Cannot be 1:1, and you should stop trying:**

| thing | why |
|---|---|
| `ps_2_b` precision | The D3D9 profile is fp24-ish with packed maths. GL fp32 is *more* accurate; a 1:1 look needs the same *formulas*, not the same rounding. Where it matters (exponent up to 150), use `highp`. |
| The lightcache | `vrad` bakes it offline against Valve's map compiler. You can bake your own (we did: `src/lightcache.py`) but it will not equal Valve's for a given map. |
| `texCUBE` cubemap orientation | D3D9 and GL cube maps lay out the same six faces in the same order but not with the same image orientation; see §5.4. Port the *bake*, not a screenshot. |
| The model and textures | `models/alyx.mdl` and her `.vtf`s are Valve's content. We substituted a procedural head (§8.6) and said so. |
| Flashlight / `bFlashlight` branches | The engine drives `g_FlashlightPos_RimBoost`, `g_FlashlightAttenuationFactors_RimMask` and a spotlight texture from the player's flashlight state. Port the non-flashlight path first; the flashlight pass is a second permutation. |

---

## 2. The four layers you have to port together

```
  material (VMT)                 engine C++                    shader                     asset
  ───────────────                ──────────                    ──────                     ─────
  $phong 1                       WantsSkinShader()             skin_ps20b.fxc             .mdl
  $phongexponenttexture          → picks the .fxc              + common_vertexlitgeneric   tangents!
  $phongboost 6                  register packing   ──────►      _dx9.h                     .vtx/.vvd
  $phongfresnelranges            (SetPixelShaderConstant)      + common_ps_fxc.h          .vtf maps
  $halflambert 1                 static light, light list      + combo #defines           lightmap
```

**Layer 1 — the material.** Real KeyValues: `#base`/`#include` chain, `patch`
blocks, quoted values, `[0.05 0.5 1]` vector syntax, `$phongtint "[.1 .1 .1]"`.
Parse it; don't hardcode. `src/vmt.py` is a tokenizer + defaults table, and the
defaults table *is* the shader's own defaults (`$phongboost` 1, `$phongfresnelranges`
`[0 0.5 1]`, `$phongtint` white).

**Layer 2 — the helper C++.** This is where the material becomes numbers:

```cpp
// skin_dx9_helper.cpp:899-918
params[info.m_nPhongFresnelRanges]->GetVecValue( vFresnelRanges_SpecBoost, 3 );
// Change fresnel range encoding from (min, mid, max) to ((mid-min)*2, mid, (max-mid)*2)
vFresnelRanges_SpecBoost[0] = (vFresnelRanges_SpecBoost[1] - vFresnelRanges_SpecBoost[0]) * 2;
vFresnelRanges_SpecBoost[2] = (vFresnelRanges_SpecBoost[2] - vFresnelRanges_SpecBoost[1]) * 2;
...
vFresnelRanges_SpecBoost[3] = params[info.m_nPhongBoost]->GetFloatValue();
...
pShaderAPI->SetPixelShaderConstant( PSREG_EYEPOS_SPEC_EXPONENT,     vEyePos_SpecExponent,   1 );
pShaderAPI->SetPixelShaderConstant( PSREG_FRESNEL_SPEC_PARAMS,      vFresnelRanges_SpecBoost,1 );
pShaderAPI->SetPixelShaderConstant( PSREG_FLASHLIGHT_POSITION_RIM_BOOST, vRimBoost,         1 );
pShaderAPI->SetPixelShaderConstant( PSREG_SPEC_RIM_PARAMS,          vSpecularTint,          1 );
```

Note the re-encode: the shader never sees `(min, mid, max)`. If you pass the raw
triple and don't change the shader, you get a wrong fresnel — and it still looks
like a fresnel. `.w` is `$phongboost`; when `$phong` is off the helper zeroes the
tint (`vSpecularTint[0..2] = 0`), which is why the same code path can be reused.

**Layer 3 — the shader.** Two files matter: `skin_ps20b.fxc` (the pixels) and
`common_vertexlitgeneric_dx9.h` (the reusable math: `Fresnel`, `Fresnel4`,
`DiffuseTerm`, `SpecularAndRimTerms`, `AmbientLight`, `PixelShaderDoLighting`).
Also `common_ps_fxc.h` for `FinalOutput`, `SRGBOutput`, fog, and the `cLightScale`
register.

**Layer 4 — the asset.** Per-vertex tangents, per-vertex UVs, the eye position
(usually the model's attachment/eye origin), the bump map with **alpha = phong
mask**, the exponent texture (**R = exponent, G = albedo-tint blend, A = rim mask**),
and the lightwarp strip (256×1).

---

## 3. The register ABI

The pixel shader declares its inputs by *register slot*
(`skin_ps20b.fxc:69-89`). In GL there are no slots, so the mapping has to be
explicit — a UBO with a hand-checked layout, or named uniforms plus a comment
naming the slot. Ours:

| PSREG slot | HLSL | this port | notes |
|---|---|---|---|
| `PSREG_EYEPOS_SPEC_EXPONENT` | `g_EyePos_SpecExponent` | `g_EyePos_SpecExponent` | xyz eye, **w = exponent or −1** |
| `PSREG_FRESNEL_SPEC_PARAMS` | `g_FresnelSpecParams` | `g_FresnelRanges_SpecBoost` | xyz re-encoded ranges, w `$phongboost` |
| `PSREG_SPEC_RIM_PARAMS` | `g_SpecularRimParams` | `g_SpecularRimParams` | xyz `$phongtint`, w `$rimlightpower` |
| `PSREG_FLASHLIGHT_POSITION_RIM_BOOST` | `g_FlashlightPos_RimBoost` | same | w `$rimlightboost` (non-flashlight pass) |
| `PSREG_FLASHLIGHT_ATTENUATION` | `..._RimMask` | same | **x = rim mask control** on the non-flashlight pass |
| `PSREG_AMBIENT_CUBE` | `cAmbientCube[6]` | `u_ambientCube[6]` | index order `[+x −x +y −y +z −z]` |
| `PSREG_ENVMAP_TINT__SHADOW_TWEAKS` | `g_EnvmapTint_ShadowTweaks` | same | w = which alpha feeds the mask |
| `PSREG_ENVMAP_FRESNEL__SELFILLUMMASK` | `g_EnvMapFresnel` | `g_EnvMapFresnel_SelfIllumMask` | x `$envmapfresnel` |
| `PSREG_CONSTANT_27` | `g_ShaderControls` | `g_ShaderControls` | x basemap-alpha-phong-mask, w invert |
| `PSREG_LIGHT_INFO_ARRAY` | `cLightInfo[3]` | `g_LightPos[4]`/`g_LightColor[4]` | **see below** |
| `c30` | `cLightScale` | (not ported) | `.x` linear scale, `.y` lightmap scale, `.z` `ENV_MAP_SCALE`, `.w` gamma scale |
| `c29` | `g_LinearFogColor` | (not ported) | fog + compressed-depth range |

### 3.1 The light packing trap

```hlsl
// common_vertexlitgeneric_dx9.h:25-30
struct PixelShaderLightInfo { float4 color; float4 pos; };   // 2 registers each
// skin_ps20b.fxc:86
// 2 registers each - 6 registers total (4th light spread across w's)
```

```hlsl
// common_vertexlitgeneric_dx9.h:139-165
if ( nLightIndex == 3 ) {
    float3 vLight3Pos   = float3( cLightInfo[1].pos.w, cLightInfo[2].color.w, cLightInfo[2].pos.w );
    return normalize( vLight3Pos - worldPos );
}
return normalize( cLightInfo[nLightIndex].pos - worldPos );
// and for the colour:
return float3( cLightInfo[0].color.w, cLightInfo[0].pos.w, cLightInfo[1].color.w );
```

Per-light attenuation is *also* packed one scalar per lane: `lightAtten.x/.y/.z/.w`
(`common_vertexlitgeneric_dx9.h:284-311`), and the attenuation itself is computed
**per vertex** in the vertex shader — the pixel shader only re-derives the light
*vector* per pixel and reuses the vertex-level scalar.

This port uses four clean `vec4`s instead and computes attenuation per pixel with a
disclosed stand-in (`1/(1+0.06d²)`). If you want 1:1 numbers you must implement the
engine's attenuation model and keep the `.w` packing, or document the deviation
loudly. Ours is documented in `README.md` and the light sliders show it live.

---

## 4. The maths you must not paraphrase

Every one of these has a variant that is "obviously equivalent" and isn't.

### 4.1 Exponent decode

```hlsl
// skin_ps20b.fxc (skin path), condensed
float fSpecularExponent = g_EyePos_SpecExponent.w;          // -1 → use the map
if ( fSpecularExponent < 0 )                                // PHONG_USE_EXPONENT_FACTOR==0
    fSpecularExponent = 1 + 149 * vSpecExpMap.r;            // 1 + 149*r
```

`$phongexponent > 0` overrides with a constant. `PHONG_USE_EXPONENT_FACTOR` switches
to `1 + factor * r`. Three different formulas, three different combos.

### 4.2 Fresnel (piecewise, and only the re-encoded version is the engine's)

```hlsl
// common_vertexlitgeneric_dx9.h:201-205 (default)     / :208-212 (Fresnel4)
float fresnel = saturate( 1 - dot( vNormal, vEyeDir ) );
// common_vertexlitgeneric_dx9.h:229-241 (the one the skin shader calls)
float f = saturate( 1 - dot( vNormal, vEyeDir ) );
// vRanges is already ((mid-min)*2, mid, (max-mid)*2) when it arrives
```

### 4.3 Ambient cube

```hlsl
// common_vertexlitgeneric_dx9.h — AmbientLight()
// cAmbientCube is [+x -x +y -y +z -z]; the shader squares the normal so it can
// index with a comparison instead of a branch.
```

Ours (`src/shader.py:143`) keeps the same shape:
`n2.x*cube[n.x<0?1:0] + n2.y*cube[n.y<0?3:2] + n2.z*cube[n.z<0?5:4]`.

And note *which* vector gets fed in for the rim ambient:

```hlsl
// skin_ps20b.fxc:186
float3 vRimAmbientCubeColor = PixelShaderAmbientLight( vEyeDir, cAmbientCube );
```

The rim term's ambient is sampled along the **eye ray**, not the normal. Easy to
"fix" into a bug.

### 4.4 Specular + rim

```hlsl
// skin_ps20b.fxc:209-213
float fFresnelRanges = Fresnel( worldSpaceNormal, vEyeDir, g_FresnelRanges );
float fRimFresnel   = Fresnel4( worldSpaceNormal, vEyeDir );
float3 vReflect = 2 * worldSpaceNormal * dot(worldSpaceNormal, vEyeDir) - vEyeDir;
```

`SpecularAndRimTerms` (in `common_vertexlitgeneric_dx9.h`) is where the highlight
is built: `pow(saturate(dot(reflect, lightDir)), exponent)`, optionally warped by a
specular-warp texture, then faded by the fresnel ranges and multiplied by
`$phongboost` and the tint. The rim term is `pow(saturate(1−N·V), rimExponent)` and
the two are combined by the caller:

```hlsl
// skin_ps20b.fxc — Ep1/2007 branch
specularLighting = max( specularLighting, rimLighting );
```

That `max` is why `$rimlight` is nearly invisible at `$phongboost 6`, and why a
"rim should be stronger" bug report is usually not a bug. `$phongboost` is applied
to the *specular*; lowering it is the only way to see the rim.

### 4.5 Envmap

```hlsl
// skin_ps20b.fxc:227-239
float fEnvMapMask = lerp( baseColor.a, fSpecMask, g_EnvmapTint_ShadowTweaks.w );
envMapColor = (ENV_MAP_SCALE *
               lerp(1, fFresnelRanges, g_EnvMapFresnel.x) *
               lerp(fEnvMapMask, 1-fEnvMapMask, g_fInvertPhongMask)) *
               texCUBE( EnvmapSampler, vReflect ) *
               g_EnvmapTint_ShadowTweaks.xyz;
```

`ENV_MAP_SCALE` is `cLightScale.z` — a *register*, not a constant 1.0. In our
stand-alone scene it is 1.0 (`#define ENV_MAP_SCALE 1.0`), and that is an explicit
deviation. `$normalmapalphaenvmapmask` picks bump alpha as the mask;
`$minlight`/`$envmapfresnel`/`$invertphongmask` all interact here.

### 4.6 Half-lambert / lightwarp

```hlsl
// common_vertexlitgeneric_dx9.h — DiffuseTerm()
NDotL = saturate( NDotL );                       // or 0 for full lambert
if ( bHalfLambert ) NDotL = NDotL * 0.5 + 0.5;
if ( bDoLightingWarp ) result = 2.0 * tex1D( lightWarpSampler, NDotL ).rgb;
```

The `2 *` and the 256×1 strip are both required; our `src/shader.py:153` keeps them,
and the contact sheet's `$lightwarptexture` panel shows the authored ramp next to
the no-warp diagonal so the gap is visible.

### 4.7 The final line

```hlsl
// skin_ps20b.fxc:~378
float3 result = specularLighting * vSpecularTint + envMapColor + diffuseComponent;
return FinalOutput( float4( result, alpha ), fogFactor, PIXELFOGTYPE,
                    TONEMAP_SCALE_LINEAR, bWriteDepthToAlpha, vProjPos.z );
```

`FinalOutput` (`common_ps_fxc.h:345`) is part of the shader, not of the pipeline:

```hlsl
result.rgb = vShaderColor.rgb * LINEAR_LIGHT_SCALE;   // cLightScale.x
result.rgb = BlendPixelFog( result.rgb, pixelFogFactor, g_LinearFogColor.rgb, iPIXELFOGTYPE );
result.rgb = SRGBOutput( result.rgb );                // ps2b+: 1D gamma table (s15), if CONVERT_TO_SRGB
```

---

## 5. Conventions that silently change the picture

### 5.1 Clip space

D3D9: z ∈ [0,1], y down in screen space. GL: z ∈ [−1,1], y up. If you port an
engine projection matrix verbatim you must remap z (or use
`glClipControl(GL_LOWER_LEFT, GL_ZERO_TO_ONE)` on GL 4.5+). If you write your own
`perspective()`/`lookAt()` you have already made the choice — just be consistent
between your own renderers (our offline and browser paths share the same formulas,
which is why they diff to 0.2/255).

### 5.2 Winding

D3D9's default front face is **clockwise**; GL's is counter-clockwise. Either set
`glFrontFace(GL_CW)` or reverse your index buffers. We chose CCW and rebuilt the
buffers, and put the reason in a comment next to the floor quad
(`src/render.py:build_world`), because a wrongly-wound room just vanishes.

### 5.3 Texture V

VTF/VMT texture data is authored for the engine's convention (first row = v 0 in the
sense the shader means). `glTexImage2D` takes the first row as v 0 too, so the
correct default is **do not flip** — but any library that flips (PIL-style display,
`UNPACK_FLIP_Y_WEBGL`, most image loaders' "bottom-up" helpers) will silently
mirror every map, and a mirrored normal map mostly still looks like a normal map.
Pick one convention, document it, and remember it applies to *data* textures
(bump/exponent/lightmap) and to pictures a human looks at, differently.

### 5.4 Cubemaps

`env_cubemap` in a VMT means "the nearest `env_cubemap` entity's baked cube".
The six faces come in the order `+X −X +Y −Y +Z −Z` in both APIs, but the
**orientation of the image on each face differs between D3D9 and GL** (the ±Y faces
are the usual casualty), and the reflection vector handedness has to be consistent
with how you baked the faces.

Practical test: bake or synthesise a cube where you know each face's colour (we
generate ours from `lightcache.ambient_light()` in `web_export.bake_env_faces()`),
point the camera at a mirror-ish surface, and check that `reflect()` picks up the
lobe you expect. Fix orientation by flipping V on the offending faces — never by
negating the reflection vector, which hides the problem and breaks the phong
highlight instead.

### 5.5 sRGB framebuffers

Source's pixel shaders do the sRGB encode themselves (`SRGBOutput`). If you also
enable `GL_FRAMEBUFFER_SRGB` you will encode twice and wash the image out. For a 1:1
port: keep the default framebuffer linear, do the gamma conversion where the engine
does it, and don't mark your base textures `GL_SRGB8_ALPHA8` unless you also
linearise everything the engine kept in gamma space.

---

## 6. Colour space, in one diagram

```
  VTF base texture  ──┐
  (gamma space)       │
                      ▼
                 base color  ────────► diffuse * light
  static lightmap ──► GammaToLinear( staticLightingColor * cOverbright )   ← the engine's own line
  ambient cube   ─────► added in LINEAR space
  dynamic lights ─────► added in LINEAR space
                      ▼
                 result = specular*tint + envmap + diffuse
                      ▼
              FinalOutput: * LINEAR_LIGHT_SCALE, fog, SRGBOutput()
                      ▼
                 framebuffer (gamma space)
```

with `const float cOverbright = 2.0f; const float cOOOverbright = 0.5f;`
(`common_vertexlitgeneric_dx9.h:31-32`) and
`LinearToGamma/GammaToLinear = pow(x, 1/2.2) / pow(x, 2.2)`
(`common_fxc.h:174-203`). Note `SrgbGammaToLinear` (the real piecewise curve,
`common_fxc.h:205`) exists too — the engine uses the simple pow for most paths.

For HDR (`mat_hdr_level`, `$phongboost 6` on a bright map) the highlight has to be
allowed to go above 1.0 before the final scale, or the boost does nothing. That is
why our test scene renders into an FP16 target, bright-passes, blurs and tonemaps
(`src/render.py:post`) — that part is *our* stand-in for the engine's HDR pipeline,
and it is labelled as such. A real 1:1 port has to follow the engine's HDR rules
(`LINEAR_LIGHT_SCALE`/`GAMMA_LIGHT_SCALE` from `c30`, exposure per map).

---

## 7. Combos and routing

* The `#define`s in `skin_ps20b.fxc:1-60` are **compile-time**. Toggling one in a
  port means recompiling a permutation, exactly like the engine picks a different
  `.fxc`. There is no runtime branch you can preserve.
* `$phong` does **not** select a combo. `WantsSkinShader()` decides whether the
  material is drawn by `skin_ps20b.fxc` at all; with `$phong 0` (or global
  `mat_phong 0`) it goes to `vertexlit_and_unlit_generic_bump_ps2x.fxc`, which has
  no specular code at all. A port that keeps one program must gate the phong block
  on a combo and say so.
* `$halflambert`, `$lightwarptexture`, `$normalmapalphaenvmapmask`, `$envmap`,
  `$rimlight`, `$basemapalphaphongmask`, `$invertphongmask`, `$phongexponentfactor`
  each map to one define. `src/combos.py` mirrors the names verbatim and
  `resolve()` produces registers the way `skin_dx9_helper.cpp` does.
* Only one or two dozen combos are reachable from a given material, but the
  *product* is large. Compile lazily, cache, and key the cache by the combo mask.

---

## 8. The asset side (where most "why does it look different" comes from)

1. **Tangents.** Studio models carry explicit per-vertex tangents. Use them. If you
   must generate, generate from the *exported* UVs and the *exported* normals, and
   expect a different highlight than any screenshot of the real game.
2. **Bump alpha is the phong mask.** `$bumpmap`'s alpha channel. `$basemapalphaphongmask 1`
   swaps to the base texture's alpha. `$invertphongmask 1` inverts it. This single
   channel decides where the highlight exists at all — a white-alpha bump map is
   why a ported model sometimes has a highlight where the real one has none.
3. **The exponent texture is three things at once**: R = exponent, G = albedo tint
   blend, A = rim mask. Split it, don't average it.
4. **The lightwarp is a 256×1 strip**, sampled with a *clamped* 1D texture.
5. **`$phongexponentfactor`** changes the exponent formula, not the texture.
6. **A stand-in head is fine for learning, but disclose it.** Ours reproduces the
   layout (face centred at `u = 0.5`, hairband, zone-shaped masks) and nothing
   finer; the silhouette-onset artefact in `out/` is a property of that geometry,
   not of the shader.

---

## 9. What the vertex shader owes you

Don't treat the PS as self-contained. It is handed, per vertex:

| input | meaning |
|---|---|
| `worldPos_atten3.xyz` | world position |
| `worldVertToEyeVectorXYZ_tangentSpaceVertToEyeVectorZ` | eye vector, with a tangent-space eye Z packed in `.w` |
| `tangentSpaceTranspose` | 3×3, the model's tangent frame |
| `lightAtten` + `atten3` | per-light attenuation scalars, packed |
| `u/v` | diffuse UV; `uv2` for detail |

and the constants `cLightInfo[3]` + `nNumLights`. The VS also computes the light
vector and (in the 2013 pipeline) the last-light index. A 1:1 port therefore has to
port **both** stages: our offline renderer does the light loop in the fragment
shader for clarity, which is a deliberate, documented deviation that costs nothing
visually in a two-light scene and everything if you want bit-comparable lighting.

---

## 10. A GL skeleton for the real thing

```glsl
// fragment — the shape that matters, not the whole file
layout(std140) uniform Registers {          // one UBO per draw, matching PSREG slots
    vec4 g_EyePos_SpecExponent;
    vec4 g_FresnelRanges_SpecBoost;
    vec4 g_SpecularRimParams;
    vec4 g_FlashlightPos_RimBoost;
    vec4 g_FlashlightAttenuation_RimMask;
    vec4 g_EnvmapTint_ShadowTweaks;
    vec4 g_EnvMapFresnel_SelfIllumMask;
    vec4 g_ShaderControls;
    vec4 cLightInfo[6];                     // 3 lights x (color,pos) — keep the packing
    vec4 cLightAtten;                       // attenuation scalars, one per lane
    vec4 cLightScale;                       // .x linear, .y lightmap, .z envmap, .w gamma
};
```

* **VAO per model**, attributes matching the engine's stream layout (pos, normal,
  tangent, UV, bone weights/indices). `glGetAttribLocation` + explicit
  `layout(location=...)` to keep a stable contract.
* **UBO per draw**, or per-frame + per-material split. Keep the slot order and
  document it next to the PSREG names.
* **Textures**: base, bump(+mask), exponent, lightwarp, envmap cube, lightmap,
  (detail, specular-warp, and the sRGB gamma table if you emulate `SRGBOutput`).
  Sampler bindings are part of the contract in the .fxc (`SHADER_SAMPLER6` for the
  flashlight spotlight, `NormalizeSampler` = s0, etc.) — mirror them.
* **Combos → programs**, cached in a map keyed by the combo bitmask; on GL 4.1+
  store `glGetProgramBinary` blobs to make recompiles cheap.
* **State**: `glFrontFace`/cull, depth test, alpha test (`$alphatest 1` uses
  `texkill`-equivalent `discard`), blending for `$translucent`. Source's state comes
  from the VMT, so your state setup is material-driven, not hardcoded.

---

## 11. Precision

`ps_2_b` is not fp32. Places where that bites in GL/ES:

* exponent `1 + 149*r` and `pow(x, 150)` — `mediump` will visibly band. Use `highp`
  in the fragment shader (and WebGL2 requires the precision qualifiers to be
  declared; see §13.1).
* The accumulated `linearColor` of four lights plus ambient: fp16 targets are fine
  for display, risky for the accumulation. Keep the accumulation in fp32 if you can.
* Normalising a near-zero vector (`dot(v,v) ≈ 0`) differs. `normalize()` of a
  zero-length vector is undefined in both APIs; don't rely on it matching.

---

## 12. Build/validation harness (this is the part people skip)

1. **Compile every permutation you can reach.** `python3 src/web_export.py --check`
   compiles all 60 (5 presets × {full + 11 terms}) in real GL, and the ES variants
   separately. A shader that only fails in the browser is a shader you found in
   production.
2. **Keep a CPU twin.** `src/shader.py` has `CPUShader`, a numpy implementation of
   the same formulas. `render.py` diffs the two on the model pixels
   (`p50 0.00043, p99 0.00097, max 0.0021`). That is how you catch a mistyped
   constant that no screenshot reveals.
3. **Diff two independent renderers at identical camera/resolution.** The browser
   vs offline comparison (`out/web_vs_offline_sheet.png`) is the strongest check
   here: mean 0.2/255 across all five variants. It found (a) the room being drawn
   with `idx.shape[0]` as a vertex count — three walls silently missing, and (b) a
   lightmap handed to the PNG encoder as the wrong type, shipped pure white.
4. **Negative controls.** A validator that accepts anything is worthless: when we
   first proved the ES shader compiled, we also pushed a deliberately broken
   `#version`/precision pair through the same path to make sure it *rejects*.
5. **Anchor your surgery.** Term views splice one line into the fragment shader by
   matching `    fragColor = vec4(result, 1.0);`. Assert the anchor exists — an
   unasserted substitution silently produces a shader that compiles and lies.

---

## 13. Traps we actually hit (the short list)

1. **`#version` must be the first line.** Our Python sources start with a newline;
   desktop Mesa tolerates it, ANGLE/WebGL does not (`ERROR: 0:2: '\n' : #version
   directive must occur on the first line`). Strip leading whitespace when you
   convert to ES.
2. **Uniform types.** Sending a `vec2` with `glUniform1f` is silently dropped in
   WebGL (`GL_INVALID_OPERATION: glUniform1f: Uniform size does not match uniform
   method`) — the pass renders with stale data and looks almost right. Query
   `gl.getActiveUniform` and dispatch on the reported type.
3. **Feedback loops.** Binding a texture *after* the draw call meant the first blur
   pass sampled whatever was bound before — which in a ping-pong is the target
   itself. WebGL reports `Feedback loop formed between Framebuffer and active
   Texture`; desktop GL may just render garbage.
4. **`idx.shape[0]` vs `idx.size`.** With an (n,3) index array, `shape[0]` is the
   triangle count. `moderngl`'s `render(mode, vertices)` takes *vertices*, so the
   three walls and the second prop were being dropped for the whole project.
5. **PNG encoder argument types.** `png_data_uri()` takes a float array; handing it
   a `PIL.Image` produced a pure-white lightmap that still loaded, still tiled and
   still looked like "a lit room" at a glance.
6. **Term views need their combos.** `PHONG MASK` only exists under `SKIN`;
   `envmap` only under `CUBEMAP`. Force the combos for the view, and say so on
   screen — otherwise the term is a black image and you conclude the shader is
   broken.
7. **`saturate` is not `clamp` for NaN** (D3D `saturate(NaN) = 0`, GLSL is
   undefined), and `lerp(a,b,t)` clamps nothing while `mix` doesn't either — but
   D3D's `lerp` is `a + (b-a)*t` while some GLSL optimisers will fuse
   `mix(a,b,t)` into an FMA and give you a different last bit. If you need bit
   equality, write `a + (b-a)*t` yourself.
8. **`tex2D`/`texCUBE` → `texture`**, `frac` → `fract`, `ddx/ddy` → `dFdx/dFdy`,
   `mul(M,v)` → `M * v` (watch the row/column-major flip: HLSL `mul(v, M)` is
   `M * v` in GLSL, and Source's `mul( i.tangentSpaceTranspose, n )` is a
   matrix-vector product with a transposed frame — get it backwards and the
   lighting still "works", it is just wrong).
9. **`$envmaptint "[.1 .1 .1]"` is three floats in a string.** Parse the brackets;
   `m["$envmaptint"]` returns a quoted string, and a naive `split()` gives you
   `['"', '0.1', ...]`.
10. **Front-face default** (§5.2) — a flipped room looks like a missing room.

---

## 14. If you were doing this for real: the order of work

1. Parse VMT properly (KeyValues + defaults). Nothing else can be trusted until
   `resolve()` produces the register block.
2. Port the math into a CPU twin first: `AmbientLight`, `Fresnel`, `DiffuseTerm`,
   `SpecularAndRimTerms`, the exponent decode, the final line. Unit-test them
   against hand-computed values from the HLSL.
3. Port the same formulas to GLSL, and diff CPU vs GPU. Fix until the diff is at
   noise level.
4. Bring up the lightcache (probe grid → ambient cube, SH, lightmaps). Only then
   does the model stop looking like a plastic egg.
5. Add combos + routing, one material at a time, checking which registers the
   compiler keeps live (`len(active_registers)` in our report) — that readout is a
   free map of what a given VMT actually uses.
6. Add the term/verbose views. They are the debugging tool for everything after.
7. Only then optimise: cache permutations, UBOs, avoid per-frame program switches,
   batch by material + combo.
8. License check before you ship anything: the shader source is Valve's, the model
   and textures are Valve's, and neither is redistributable. This project is a
   teaching artefact for exactly that reason.

---

## 15. One-paragraph summary

Port the material text, the helper's register encoding, the shader's arithmetic,
the combo routing, the vertex-stage inputs and the asset conventions — in that
order, keeping a CPU twin and a second renderer to diff against. Keep the engine's
gamma-space/linear-light split, the packed constants, the re-encoded fresnel
triple, the `[+x −x +y −y +z −z]` ambient cube and the `2 * tex1D(lightwarp)`
lookup exactly as written, because every one of them has a plausible-looking
wrong version. Everything else — precision quirks of `ps_2_b`, Valve's baked
lightcache, Valve's model — you reproduce as closely as you can and then label
as an approximation.
