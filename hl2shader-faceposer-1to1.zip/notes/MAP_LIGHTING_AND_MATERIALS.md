# The fake lightcache, and why a model is more than one shader

*Two questions, answered with the engine's own code and with the viewer in
`live/index.html`. Everything quoted below is from the files in
`../engine-sources/` (`common_vs_fxc.h`, `common_vertexlitgeneric_dx9.h`,
`skin_ps20b.fxc`, `eye_refract_ps2x.fxc`), and everything described as running
is in `../src/`. For learning purposes only.*

---

## Part 1 — how a model inherits the map's lighting

### 1.1 Where the light actually lives

A compiled Source map contains no lights as far as a model is concerned. `vrad`
bakes the map's lighting into the `.bsp` as two different things:

| what | where | who reads it |
|---|---|---|
| lightmaps | per-surface texel data (`$lightmap`, `LUMP_LIGHTING`) | world brushes only |
| the lightcache probe grid | per-cell data (`LUMP_LIGHTING` / worldlights) | *everything else*: models, props, decals, particles |

The probe grid is a 3D lattice of cells. Each cell holds **six colours — one for
each axis direction** — which is the whole trick: six numbers is enough to
approximate "how much light arrives from +x, −x, +y, −y, +z, −z", and that is
enough to light any normal, because a normal is just a set of weights.

That is what "fake lightcache" means in this project: not a fake of a *real*
algorithm (it is the real data layout), but a stand-in for the *map file*. There
is no compiled `.bsp` here, so `src/lightcache.py` bakes the same kind of array
itself and ships it.

### 1.2 The cube, per entity, from the map

When the engine draws a model, it does **one** probe lookup for the whole model —
at the entity's origin — and hands the result to the shader as six constants:

```hlsl
// common_vs_fxc.h  (the vertex-shader side of the same data)
const float3 cAmbientCubeX [ 2 ] : register ( c21 ) ;
const float3 cAmbientCubeY [ 2 ] : register ( c23 ) ;
const float3 cAmbientCubeZ [ 2 ] : register ( c25 ) ;
```

and the function that consumes it, verbatim:

```hlsl
// common_vs_fxc.h
float3 AmbientLight( const float3 worldNormal )
{
	float3 nSquared = worldNormal * worldNormal;
	int3 isNegative = ( worldNormal < 0.0 );
	float3 linearColor;
	linearColor = nSquared.x * cAmbientCubeX[isNegative.x] +
	              nSquared.y * cAmbientCubeY[isNegative.y] +
	              nSquared.z * cAmbientCubeZ[isNegative.z];
	return linearColor;
}
```

Read the index: `isNegative.x` is 0 or 1, so the pair `(cAmbientCubeX[0],
cAmbientCubeX[1])` is *+x* and *−x*, and the two-element arrays exist purely so
the three axes can be indexed by a boolean. In flat-index form, which is how the
port stores it and how the browser ships it:

```
[0] = +x   [1] = −x   [2] = +y   [3] = −y   [4] = +z   [5] = −z
index = 2*axis + (component < 0)
```

The pixel-shader side (`common_vertexlitgeneric_dx9.h`'s
`PixelShaderAmbientLight()`, and `skin_ps20b.fxc`'s ambient box) is the same
three lines with the same six registers — the port keeps one copy, in
`src/shader.py`:

```glsl
vec3 AmbientLight(vec3 worldNormal) {
    vec3 nSquared = worldNormal * worldNormal;
    return nSquared.x * u_ambientCube[worldNormal.x < 0.0 ? 1 : 0]
         + nSquared.y * u_ambientCube[worldNormal.y < 0.0 ? 3 : 2]
         + nSquared.z * u_ambientCube[worldNormal.z < 0.0 ? 5 : 4];
}
```

### 1.3 The part your question is really about: *per object*

Two consequences follow from "one probe per entity, in constant registers", and
both are things you can *see* in the viewer:

1. **A model cannot pick its own light per pixel.** Every vertex of the model
   gets the same six colours; only the normal varies. A model standing across a
   light boundary is lit by (at most) one cell's worth of light, smoothed by the
   engine when it picks it — a 3×3×3 average of neighbouring cells, not a single
   cell, which is what `sample_cube()` reproduces:

   ```python
   idx = clip(round((pos - lo) / (hi - lo) * (res - 1)), r, res - 1 - r)
   block = grid["cube"][x-r:x+r+1, y-r:y+r+1, z-r:z+r+1]
   return block.reshape(-1, 6, 3).mean(0)      # <- the cube the entity inherits
   ```

2. **Two entities on different probes cannot be batched.** `cAmbientCube` is a
   *constant register*, not a vertex attribute, so a shader writer cannot put
   per-object light into a shared vertex buffer. The frame is drawn entity by
   entity, each draw preceded by its own constant upload. `src/render.py` does
   exactly that — two props, two draws, two cubes:

   ```python
   for pi in range(len(self.prop_cubes)):
       wprog["u_ambientCube"].write(cube_of(pi).tobytes())
       pva.render(moderngl.TRIANGLES, self.prop_draws[pi][1], first=...)
   ```

   before this revision the port uploaded one cube (the head's) for the whole
   room, which is why the crate and the pillar used to shade identically.

3. **Dynamic lights are a separate system.** The cube is only the baked part.
   Point/spot/directional lights arrive as `LightInfo cLightInfo[4] : register( c27 )`
   (five float4s per light, `w` lanes encoding the light type) and are added on
   top — per pixel in `skin_ps20b.fxc`, per vertex in the plain `VertexLitGeneric`
   path. In the port they are `g_LightPos[4]` / `g_LightColor[4]`.

So the forward renderer's answer to "how is the model lit" is: **one baked cube
from the map, chosen per entity at draw time, plus N dynamic lights resolved per
vertex or per pixel.** Nothing about the model's own geometry is involved in the
baked part — the probes are the map's, the model only *inherits* them at its
origin.

### 1.4 What the viewer does with that, and what it adds

There is no `.bsp`, so the field is baked and shipped
(`src/lightcache.py` → `src/web_export.py` → the page):

```
bake_grid()          26 × 18 × 28 probes over the room's bounds: direct light
                     from the scene's two lights + 3 isotropic bounce passes,
                     per-lobe weights (dot(L, axis)^2), energy-scaled by 0.55
grid_to_texture()    the whole array as a 3D texture, RGB16F, size (nx, ny, nz*6)
                     with slice z = probe_z*6 + lobe, so GL_LINEAR interpolates
                     *between probes* and never between lobes
sample_cube()        what one entity gets  (the 3×3×3 mean above)
AmbientLight()       what a normal gets out of it (the three lines above)
```

`live/index.html` then runs three ambient modes side by side, switchable live:

| mode | what it is | where the code is |
|---|---|---|
| `per-object cube` | the engine's path: one cube per entity, uploaded before its draw | default; `render.py` and the `object` branch of `drawScene()` |
| `per-pixel probe field` | a **port extension**, not a Valve combo: the same six-lobe lookup, but the cube is re-picked per fragment out of the 3D texture (`#define PORT_PROBE_AMBIENT`) | guarded branch inside `AmbientLight()` in `shader.py` and `render.py`'s `WORLD_FS` |
| `flat` | one cube for the entire map — what a naive port (or a shader that forgot to upload the register) produces | the `flat` branch of `drawScene()` |

and a debug view that draws **the probe field itself**: one point sprite per
probe, positioned at the probe's own cell and coloured by the light that cell
hands a surface facing a direction you choose (`+y`, outward from the room
centre, or any of the six lobes). Colour and size come from the same 3D texture
the shaders sample, in the probe-cloud vertex shader — so what you see is the
data, not a re-computation of it. `out/web_probes_wide.png` is that view: the
two lights' falloff, the shadow the props cast into the field, and the room's
own walls all visible in the probes.

Read-outs printed on the page come from the same array, evaluated with the same
sample the shaders use (`LG.sampleCube` / `LG.sampleAmbient` in the template,
which mirror `lightcache.sample_cube` / `ambient_light`):

```
grid     26 × 18 × 28 = 13,104 probes · cell 0.32 × 0.25 × 0.27 · cube max 1.656
head     cube @ [0.00 0.10 0.00]   +x 0.229 0.375 0.613   −z 0.708 0.579 0.483
         AmbientLight(+y) = 0.337 0.251 0.166
crate    cube @ its own origin     +x 0.054 0.084 0.134   −z 0.188 0.150 0.118
pillar   cube @ its own origin     +x 0.020 0.025 0.033   −z 0.263 0.270 0.314
eye L    cube @ the eyeball origin +x 0.261 0.429 0.703   g_flAverageAmbient 0.2728
eye R    cube @ the eyeball origin +x 0.294 0.487 0.800   g_flAverageAmbient 0.2723
```

Three things worth noticing in those numbers, all of them real engine behaviour:

* The crate sits in the key light's shadow → nearly a quarter of the head's
  ambient. The pillar is tall and sees the fill light → brighter, bluer.
* `AmbientLight(+y)` (0.337 0.251 0.166) is *warmer* than the cube's `−z` lobe
  (0.708 0.579 0.483) because it mixes all three axes by the normal's squared
  components — one cube, six lobes, and a different colour for every normal.
* The two eyes get *different* cubes (0.261 vs 0.294 in `+x`), because they are
  sampled at two different points, 0.65 m apart in room space. Valve's eyeball
  shader wants a single scalar for this — `g_flAverageAmbient`
  (`#define g_flAverageAmbient g_vPackedConst0.z`, `eye_refract_ps2x.fxc` line
  61) — so the viewer feeds it the mean of that entity's own cube.

---

## Part 2 — "two shaders": face flexes, phong, and where the second program comes from

### 2.1 One draw = one program = a vertex stage *and* a pixel stage

A "shader" in Source is a *pair* of compiled programs selected together: the
vertex shader has to produce exactly the interpolators the pixel shader reads.
Face flexes and phong highlight are **not** two shaders. They are two stages of
one program, and the vertex stage comes first:

```hlsl
// common_vs_fxc.h, register comment and the helpers
// Only cFlexScale.x is used
// It is a binary value used to switch on/off the addition of the flex delta stream
const float4 cFlexScale					: register( c3 );

bool ApplyMorph( float3 vPosFlex, inout float3 vPosition )
{
	// Flexes coming in from a separate stream
	float3 vPosDelta = vPosFlex.xyz * cFlexScale.x;
	vPosition.xyz += vPosDelta;
	return true;
}

bool ApplyMorph( float4 vPosFlex, float3 vNormalFlex,
	inout float3 vPosition, inout float3 vNormal, inout float3 vTangent, out float flWrinkle )
{
	...
}
```

Read that carefully, because it answers the question directly:

* **The displacement is one line of the *same* vertex shader** that does the
  transform, the skinning and the tangent frame. There is no separate "faceflex
  pass", no second draw, no second material.
* `cFlexScale.x` is documented in that header as *"a binary value used to
  switch on/off the addition of the flex delta stream"* — it is a per-draw
  on/off, not a per-flex weight. (A 2013-SDK variant adds `cFlexWeights[512] :
  register( c1024 )`, but on the VS_3_0 path the deltas arrive already weighted.)
* The last overload exists to also produce `flWrinkle` — the wrinkle map used by
  the face shader; still the same program.
* On the VS_3_0 path the delta is not even at attribute position: it is fetched
  from a **vertex texture** —

  ```hlsl
  float4 SampleMorphDelta( sampler2D vt, const float3 vMorphTargetTextureDim,
                           const float4 vMorphSubrect, const float flVertexID,
                           const float flField )
  {
      float flColumn = floor( flVertexID / vMorphSubrect.w );
      float4 t;
      t.x = vMorphSubrect.x + vMorphTargetTextureDim.z * flColumn + flField + 0.5f;
      t.y = vMorphSubrect.y + flVertexID - flColumn * vMorphSubrect.w + 0.5f;
      t.xy /= vMorphTargetTextureDim.xy;
      t.z = t.w = 0.f;
      return tex2Dlod( vt, t );
  }
  ```

  which is why "the model deforms" never shows up as a separate pipeline stage:
  the .vta data is a texture read inside the ordinary vertex shader.

The phong highlight, meanwhile, is in the **pixel** stage, in a different file —
`skin_ps20b.fxc`, which contains no vertex program at all:

```hlsl
// common_vertexlitgeneric_dx9.h, lines 229-238  -- the fresnel the skin PS calls
float Fresnel( const float3 vNormal, const float3 vEyeDir, float3 vRanges )
{
	// note: vRanges is now encoded as ((mid-min)*2, mid, (max-mid)*2) to optimize math
	float f = saturate( 1 - dot( vNormal, vEyeDir ) );
	f = f*f - 0.5;
	return vRanges.y + (f >= 0.0 ? vRanges.z : vRanges.x) * f;
}
```

```hlsl
// skin_ps20b.fxc, lines 268, 312, 315
fSpecExp = (g_EyePos_SpecExponent.w >= 0.0) ? g_EyePos_SpecExponent.w : (1.0f + 149.0f * vSpecExpMap.r);
...
	// If we didn't already apply Fresnel to specular warp, modulate the specular
	if ( !bDoSpecularWarp )
		fSpecMask *= fFresnelRanges;

	// Modulate with spec mask, boost and tint
	specularLighting *= fSpecMask * g_SpecularBoost;
```

The port's copy of those lines is `shader.py`:

```glsl
    float fSpecExp = (g_EyePos_SpecExponent.w >= 0.0)      // shader.py:289, same branch
                   ? g_EyePos_SpecExponent.w
                   : (1.0 + 149.0 * vSpecExpMap.r);
...
    fSpecMask *= fFresnelRanges;                           // shader.py:310
    specularLighting *= fSpecMask * g_SpecularBoost;       // shader.py:312
```


So: **the deform is a vertex program's business, the highlight is a pixel
program's business, and both live in the one program a skin material draws
with.** When the port's UI shows flexes and `#if SKIN` in the same shader, that
is not a simplification — it is the actual arrangement.

### 2.2 So when do you need a second shader?

When the *lighting model* differs across the surface of the model — that is,
when one program cannot express the look. Alyx is the classic example:

| surface | material / shader | why it cannot reuse the skin program |
|---|---|---|
| face, body | `VertexLitGeneric` + SKIN (`$phong`, `$phongboost 6`, `$phongexponenttexture`, `$phongfresnelranges`, `$halflambert`) | — that *is* the skin program |
| eyeballs | `EyeRefract` (`eye_refract_ps2x.fxc`) | own cubemap, iris/pupil projection, cornea refraction, dilation, 128-power glints |
| hair | `VertexLitGeneric` with `$halflambert 1`, anisotropic-ish highlights, alpha-tested strands | different specular shape |
| teeth, glasses | separate VMTs | their own parameters |

And the eyeballs are not even in the same *model*: they are
`models/alyx/alyx_eyes.mdl`, drawn as their own entity with their own VMT and
its own shader. That is the honest answer to "do we need two shaders": **the
model needs as many programs as it has distinct lighting models, and the engine
gets them by splitting the model into materials — and, for the eyes, into a
whole separate mesh with its own animation.**

The eyeball shader is worth one quote, because it shows what is *not* shared
with the skin path — this is the whole reason it exists:

```hlsl
// eye_refract_ps2x.fxc
float3 cReflection = g_flGlossiness * texCUBE( g_tEyeReflectionCubemapSampler, vCorneaReflectionVector.xyz ).rgb;   // line 396
...
cSpecularHighlights.rgb += pow( saturate( dot( vCorneaReflectionVector.xyz,
    PixelShaderGetLightVector( i.vWorldPosition_ProjPosZ.xyz, g_sLightInfo, 0 ) ) ), 128.0f )
    * i.vLightFalloffCosine01.x * PixelShaderGetLightColor( g_sLightInfo, 0 );                                        // line 415
...
float fPupilDilateFactor = g_flDilationFactor; // This value should be between 0-1                                          // line 309
...
cIrisLighting.rgb += saturate( dot( vIrisTangentNormal.xyz, -vTangentViewVector.xyz ) )
    * g_flAverageAmbient * fIrisHighlightMask * 0.5f;                                                                // line 377
...
float3 cAmbientOcclColor = lerp( g_cAmbientOcclColor, 1.0f, cAmbientOcclFromTexture.rgb ); // Color the ambient occlusion      // line 387
i.cVertexLight.rgb *= cAmbientOcclColor.rgb;                                                                          // line 388
```

Note what appears in there: `g_flAverageAmbient` (the *model's* ambient level —
which the port feeds from the map's probe field, Part 1), `g_sLightInfo` (the
same dynamic lights the skin shader uses, but with a 128-power glint instead of
`$phongboost`), its own cubemap, and an AO texture that tints the vertex light.
Two programs, one scene, two completely different looks for two small spheres.

### 2.3 How the viewer shows it

`live/index.html` now draws the model as **two materials in sequence**, which is
what the engine does with `models/alyx.mdl` + `models/alyx/alyx_eyes.mdl`:

* **skin** — the ported `skin_ps20b.fxc` (`FRAG_SRC`), with a live face-flex
  vertex stream: `layout(location = 5) in vec3 a_flex;` plus
  `uniform float u_cFlexScale; u_flexWeight;` and, in `main()`,

  ```glsl
  // ApplyMorph(): the flex delta is added in *model* space, before the
  // model matrix -- the same place the HLSL does it.
  vec3 pos = a_pos + a_flex * u_cFlexScale;
  vec4 wp  = u_model * vec4(pos, 1.0);
  ```

  The deltas are int8-normalised, two streams (`blink`, `jaw_open`) in one
  buffer, selected by a byte offset — the closest a browser gets to the HLSL
  vertex texture. A disabled attribute array reads `(0,0,0,1)`, so a draw
  without the stream is the vertex `render.py` draws offline, byte for byte.
  *Disclosure: these two deltas are synthesised from the parametric surface, not
  Alyx's `.vta` data — the mechanism is Valve's, the numbers are not.*

* **eyes** — `EYE_FS`, a scoped port of `eye_refract_ps2x.fxc`: the sclera/iris/
  pupil split by the angle from the optical axis, the cube reflection at
  `g_flGlossiness`, the 128-power glints against `g_sLightInfo`, the pupil's
  "cone of darkness" `pow(1.0 - saturate((-tl.z - 0.25)/0.75), 4.0)`, and the
  ambient fallback `saturate(dot(N_iris, -V)) * g_flAverageAmbient * mask * 0.5`
  with `g_flAverageAmbient` taken from the **map's probe field at that eyeball's
  own origin** — Part 1 and Part 2 meeting in one draw call.
  *Disclosed omissions:* no `$corneabumpmap` and no parallax (so the dilation
  expression, kept verbatim as a comment, drives the pupil radius instead of a
  parallax offset), no `$iris`/`$iris2` textures (a stand-in iris colour), no
  caustics, no `$ambientocclusion` texture (a slider supplies the texel).
  The vertex program is shared with the skin material — the real SDK ships a
  separate eye VS for the cornea interpolators; reusing the skin VS keeps the
  point that *the material difference lives in the pixel stage*.

Press `?parity=1` on the URL and both of those switch off, along with the probe
cloud and the per-pixel probe mode: the canvas is then the exact configuration
`render.py` writes to `out/`, which is what the pixel diff in the README checks.

---

## Part 3 — what broke while building this, and what caught it

Every one of these was invisible in a single screenshot and obvious in a
measurement. They are listed because the checks are the useful part.

1. **A `/5` that should have been `/14`.** The JS port of `model.build_head()`
   indexed the second pole vertex as `n + extras.length/5` (left over from an
   older 5-float layout), i.e. one past the end of the buffer. The out-of-range
   vertex comes back as uninitialised data → NaN → and with bloom on, a 19×2
   pixel strip of NaN smeared into a large black rectangle over the crown of the
   head. It only showed on some cameras, and `render.py`'s mesh was never
   affected. Caught by reading the HDR target back and counting non-finite
   values — 81 NaN pixels — not by looking at the picture:

   ```js
   gl.bindFramebuffer(gl.FRAMEBUFFER, hdr.f);
   gl.readPixels(0,0,canvas.width,canvas.height,gl.RGBA,gl.FLOAT,a);
   // then: if(!isFinite(a[i])) ...    -> 81, all inside a 19x2 strip
   ```

2. **`#define` before `#version`.** The probe-mode branch is selected by
   prepending a `#define` to the fragment source; prepending it *before*
   `#version 330 core` makes the whole program fail to compile (WebGL and the
   desktop driver both reject it). The define now goes in on the line after
   `#version`. `web_export.py --check` compiles every permutation including the
   probe ones — 62 programs, 0 failures — which is where this belongs, not in
   the browser.

3. **A leftover name after a rename.** `result = iris;` survived the rename of
   the iris term to `eyeColour`, so the eye program failed to link and the
   eyeballs silently did not draw at all. Nothing in the page complained except
   a `pageerror` string.

4. **A refactor that changed the room.** Making each prop sample its own cube
   changed the offline PNGs; forgetting to re-run `render.py` would have turned
   the parity check into a lie. The rule the project follows: *the same numbers
   must come out of both paths*, and the diff is what proves it.

---

## Part 3 — the same shaders, on the model's own format (VBMOD4 + VBFLX1)

Parts 1 and 2 answer *how Source lights and shades a character*. This part is the
other half of the same question: what it takes to run those exact shaders on
`leanna.vbmod` — the model format this project owns — with no converter in the
middle. Everything here is implemented; `notes/PORT_TO_OPENGL_AGENT_TASK.txt` is
the long version written for another agent, and this is the short one for a
person.

### 3.1 What the format gives, and what it does not

From `src/vb/vb_model.cpp` (the package's own reader) and re-checked by
`src/vbmod.py`, which parses the shipped sample:

```
VBMOD4  683 KB  4  skeleton hash 1f75cbba38a31a93
joints 103 (root SK_Root) · vertices 3070 · indices 15504 · tris 5168
uv     u [-0.603, 1.000]  v [0.317, 2.991]
meshes r (19v/21t -> eyeball_r) · l (19v/21t -> eyeball_l) · xana (3032v/5126t -> xana)
VBFLX1 45 targets · 8585 sparse deltas · 474 KB trailer · base normals present
```

The vertex record is `pos3 | uv2 | joints4 u16 | weights4 f32` — **44 bytes with
no normal, no tangent and no second UV**. The normals are in the VBFLX1 trailer,
and the tangent frame has to be built from the UVs. That is the whole "model
format adapter": three of the five attributes a VertexLitGeneric vertex program
wants are not in the file, and two of them (`normal`, `tangent`) exist only
because the *material* asked for them.

| VBMOD | the renderer wants | where it comes from |
|---|---|---|
| position | `a_pos` | the file |
| — | `a_normal` | VBFLX1 base normals |
| uv | `a_uv` | the file, remapped into the atlas (§3.3) |
| joints4 + weights4 | bone matrices | ignored: the port draws bind pose and uses the flex stream for deformation |
| — | `a_tangent` + handedness | built from the UVs, per mesh |
| `mesh.material` | which pixel program | resolved through the `.vbm` layer (§3.4) |
| VBFLX1 targets | the delta stream | applied per target weight (§3.5) |

### 3.2 Two programs, one model — the same split as Part 2

The viewers' model path is `VBMOD_VS` (a vertex program that knows the format)
feeding the *unchanged* ported fragment program: `skin_ps20b.fxc` for the
`xana` mesh, and `eye_refract_ps2x.fxc` for the eyeballs. The eyes are the second
draw, exactly as `models/alyx/alyx_eyes.mdl` is a separate model. The fragment
program never learns which format the vertices came from — that is the point.

The model's own eyeball meshes are 19-vertex flat lens patches (their UVs are a
planar front projection so a procedural iris can sit in the middle, as the
package's `eyeball_*.vbm` description says). EyeRefract wants a **sphere**, so the
viewer places a unit sphere in each socket: the patch's centroid and mean normal
give the frame, the patch's extent gives the radius (`0.50 × max(span_u, span_z)`,
0.07 world units here), and the cornea bulges 12% of the radius out of the socket.
That is disclosed as an approximation — the file has no sphere to point at.

### 3.3 The generated skin, and why it is baked in UV space

There is no texture in the package: `xana.vbm` says `albedo "xana"` and its own
description says the mesh then draws "the plain lit fallback colour". So the four
maps the ported material wants are generated in `src/vbmod_skin.py`, in the
model's own atlas:

* **the frame comes from the geometry** — the two eyeball meshes give the origin
  (their midpoint), the scale (their separation: 2.71 model units ≈ 63 mm, so
  1 unit ≈ 23 mm) and the lateral axis; the forward axis is *measured*, by taking
  the vertices within 2.8 eye-separations of that midpoint and pointing from
  their centroid through the eyes. Measured extents: crown +1.76, chin −2.14,
  side ±1.30, back 2.50 — in units of the eye separation. Crown +1.76 and mouth
  −0.85 are correct human proportions, which is the check that the axis is right.
* **every texel is mapped back to a 3D point** by barycentric rasterisation of the
  UV triangles, and the face features are painted *there*, at that 3D point. That
  is what lets a 3D-defined look land on an arbitrary UV layout: the model keeps
  its own UVs and the features still go where the face is.
* the maps are: `albedo` (mottling, freckles, brows, lips, blush, hair),
  `normal` + alpha (**the phong mask — bump alpha is what `fSpecMask` reads**),
  `exponent` (what `1 + 149 * r` turns into `$phongexponent`), and the shared
  1×256 `lightwarp` ramp from `textures.synth_lightwarp()`.
* the palette is deliberately the stand-in head's (`textures.py`: skin
  `[0.62 0.44 0.36]`, hair `[0.12 0.10 0.10]`, linear reflectances), so both
  models read as the same character under the same shader.

Two traps worth naming, because they both bit: the atlas image must have the
aspect of the UV rectangle the model actually uses (**1.544:1** here — a
640×1024 bake stretched every feature 2.5× vertically), and the unused texels
between UV islands must be *filled* by dilation or bilinear sampling at an
island edge blends the painted colour with the background (a one-texel hairline
becomes a bald head).

### 3.4 The material layer, as it is

`src/vbmod_materials.py` reads the three `.vbm` files and maps them onto the
ported shaders — `half_lambert → HALFLAMBERT=1`, `specularStrength →
$phongboost`, `shininess → $phongexponent`, `chisel_eye → eye_refract_ps2x`,
`albedo ("xana", a stem) → $basetexture`, and so on, with every unmapped field
named as a stand-in. The package's own files are shipped into the viewer and
printed verbatim; nothing is retyped. The custom-GLSL path is a stub that falls
back to `lit`, which is the policy the package itself documents ("a compile
failure falls back to lit shading so the model remains visible").

### 3.5 The flex stream, from the format's own bytes

45 targets, 8585 sparse deltas, one linear weight each, position *and* normal
deltas. The viewer applies them the way the format's own C++ does: accumulate
`pos += dPos * w`, `nrm += dNorm * w`, renormalise the normals of the moved
vertices, re-upload. That is `ApplyMorph`'s `vPosition.xyz += vPosFlex.xyz *
cFlexScale.x` with the weight folded in on the CPU instead of the GPU — the same
composition Part 2 describes, and the reason a blink changes the *shading* and
not just the silhouette: the normal deltas move the surface normal the pixel
shader sees.

### 3.6 What the viewer shows, in the user's terms

* **model switch**: the port's stand-in head, or `leanna.vbmod` drawn by the same
  ported material — with the eyes as the second material and the flex targets as
  sliders (45 of them, paired L/R mirroring included).
* **material panel**: the package's own `.vbm` JSON, then the mapping used, then
  the stubbed custom path.
* **the light, around the model**: `cAmbientCube @ entity origin` vs the same
  lookup at the eyes, per-object vs per-pixel probe mode, and a slider that walks
  the model across the room so the ambient changes *continuously* in per-pixel
  mode and in voxel-sized steps in per-object mode — which is the whole
  difference between a wall's lightmap and a model's ambient cube.
* **the probe cloud** is drawn from the shipped field, so the data Part 1 talks
  about is visible rather than described.
