# Handover: porting this renderer 1:1 *into* FacePoser

**For:** an AI agent (or a person) picking up the FacePoser codebase.
**From:** the `hl2shader` port package (this zip).
**Companion document:** `notes/PORT_TO_OPENGL_AGENT_TASK.txt` is the *other*
direction (how to run Source's shaders on the VBMOD format in this port). This
document is the reverse: how to take the *port* — the shaders, the material
mapping, the lightcache and its test rig — and put it inside FacePoser, 1:1.

Short version, because it changes what you should write:

> **Do not keep the Chisel-style built-in shaders.** `lit`, `half_lambert` and
> the procedural `chisel_eye` preview were stand-in placeholders for the tool to
> be usable before a real shading model existed. The goal is a 1:1 port of
> Source's model shading, so those three code paths should be *replaced* by the
> ported programs. Keep the `.vbm`/`.cmt` **material layer** — the file format,
> the field names, the resolution order and the missing-texture fallback — as the
> interface; change only what sits behind it.

---

## 0. What "1:1" can mean here, and what it cannot

State this in the tool's own docs when you are done, because it is the kind of
claim that gets over-claimed:

| 1:1, and verifiable | not 1:1, and must be said out loud |
|---|---|
| the maths of `skin_ps20b.fxc` / `eye_refract_ps2x.fxc` / the lightmapped world: every term, every constant, every combo's code path | the shader *instruction* stream: ps_2_b on D3D9 vs GLSL 3.30 on OpenGL. Same maths, different compiler |
| the register layout and *names* (`g_EyePos_SpecExponent`, `g_FresnelRanges_SpecBoost`, `g_DiffuseModulation`, `cAmbientCubeX/Y/Z`, `cLightInfo[4]`) so a VMT/`.vbm` value lands in the same place | the engine's per-frame *feeding* of those registers (entity render colour, flashlight, shadow state, $envmap selection) |
| the ambient-cube lighting model, including the six-lobe order and the `N²` reconstruction | a compiled map: FacePoser has no `.bsp` and no `LUMP_LIGHTING`. The probe field has to be baked from the tool's own stage or loaded from a file |
| the flex composition: the format's own CPU delta application, and the GPU variant (`a_flex` + `cFlexScale.x`) | vertex texture fetch for `SampleMorphDelta()`: GL 3.3 can do it, but an attribute stream is what the port uses and what you should copy |
| the material → program decision (a material *is* a program) | Alyx's own art: no Valve VTF/VMT is redistributed. Textures are either the user's or generated, and the VMTs in this package are synthesised |

Everything in the right column is a *disclosure to keep*, not a blocker.

---

## 1. What FacePoser has today (read this against the code, it is all real)

File references below are from the FacePoser package this handover ships
alongside (`fposer2.zip` layout: `src/`, `docs/`, `tools/`, `samples/`).

**The GL layer** — `src/gl/GLCore.hpp`, namespace `rb`:
`rb::Shader` with `Build(vs, fs, err)`, `Use()`, `Loc()`, `SetMat4`, `SetInt`,
`SetFloat`, `SetVec3`, `SetVec4`. GL 3.3 core, GLEW, SDL2. You will need to add
`SetMat3`, `SetVec3Array` and `SetFloatArray` — the ported shaders take a `mat3`
tangent frame and 4- and 6-element arrays.

**The programs** — `src/faceposer/FacePoserApp.cpp`, built at lines ~295-300:

* `kMeshVertex` — `a_pos, a_normal, a_uv, a_color` in; `u_mvp` out; varyings
  `v_normal, v_position, v_uv, v_color`. No tangent space, no lighting, no
  world-space transform (the model matrix is folded into `u_mvp`).
* `kMeshFragment` — the whole shading model of the tool today, and it is a
  *placeholder*: `u_albedo, u_tint, u_camera_pos, u_specular_strength,
  u_shininess, u_textured, u_unlit, u_half_lambert, u_alpha_clip, u_alpha`, two
  hard-coded lights
  (`key = normalize(vec3(0.42, 0.36, 0.83))`,
  `fill = normalize(vec3(-0.55, -0.30, 0.25))`),
  `hemi = 0.30 + 0.22 * max(n.z, 0.0)`, a Blinn specular, and a fake gamma
  `pow(lit, 0.92)`.
* `kEyeFragment` — the procedural `chisel_eye` preview: sclera/vessel/iris/pupil
  from `EyeRecipe` in screen-UV space, with `u_sclera_specular`/`u_iris_specular`.
* `kLineVertex`/`kLineFragment` — the wire/grid overlay. Untouched by any of this.

**The draw** — same file, around line 1382-1428 (`glDrawElements` at ~1422):
* builds `m_cpuVertices` from `m_positions`/`m_normals` (i.e. **morph targets are
  already applied on the CPU** — VBFLX1 semantics, good) and from
  `m_model.vertices[i].texcoord`, with **`v = 1.0f - texcoord[1]`**;
* uploads with `glBufferSubData` (a single interleaved `rb::SceneVertex`);
* per mesh: picks `m_meshProgram`, `m_eyeProgram` (if
  `definition.shader == ShaderKind::ChiselEye`), or `customProgram`;
* sets every uniform from `material::Definition`; binds one albedo texture;
  applies `noCull` / `transparent` / `alphaClip`;
* draws `GL_UNSIGNED_INT` indices at `mesh.firstIndex * 4`.

**The material layer** — `src/material/MaterialSystem.hpp|.cpp`:
`enum class ShaderKind { Lit, HalfLambert, ChiselEye, CustomFragment }` and

```cpp
struct Definition {
    std::string name;
    std::filesystem::path sourceFile, albedoPath, normalPath, specularPath,
                          fragmentShaderPath;
    std::string albedoReference;
    ShaderKind shader = ShaderKind::Lit;
    bool transparent, alphaClip, noCull;
    float reflectivity;
    float tint[4] = {1,1,1,1};
    float specularStrength = 0.15f, shininess = 32.0f;
    EyeRecipe eye;                       // seed, sclera, vessel, iris, irisRim,
};                                       // fleck, irisSize, pupilSize, ...
```

`MaterialSystem.Load()` resolves a mesh's material reference to `.vbm` / `.cmt` /
a direct image, with the documented search order ("model folder →
`--materials DIR` → `--assets DIR`"), and a missing texture does not stop the
mesh loading — it draws the lit fallback. **All of that stays.**

**The build/tests** — CMake (`cmake -S . -B build -DCMAKE_BUILD_TYPE=Release`),
`ctest --test-dir build --output-on-failure`, `tests/faceposer_runtime_test.cpp`
(flex geometry/runtime) and `tests/vtf_decoder_test.cpp` (VTF hashes), Xvfb
captures in `proof/`.

---

## 2. The integration map (tool side → port side)

Everything in the right column exists in this zip; paths are relative to the
package root (`src/` of `hl2shader`).

| FacePoser | port | what to take |
|---|---|---|
| `kMeshVertex` | `src/shader.py:VERT_SRC` | world-space transform, normal matrix, tangent frame, `a_flex` + `u_cFlexScale` |
| `kMeshFragment` | `src/shader.py:FRAG_SRC` | the whole ported `skin_ps20b.fxc` path: `AmbientLight`, `DiffuseTerm`, `Fresnel`, `SpecularAndRimTerms`, lightwarp, envmap |
| `kEyeFragment` | `src/web_template.html:EYE_FS` | the ported `eye_refract_ps2x.fxc` (self-contained; the port's copy is the one with the traced numbers) |
| *(none)* | `src/render.py:WORLD_VS/WORLD_FS` | optional: if the tool ever gets a room/props, this is the lightmapped brush path (`mix(AmbientLight(N), lightmap, useLightmap)`) |
| the two hard-coded lights + `hemi` | `src/lightcache.py` | the probe grid: `bake_grid`, `sample_cube`, `grid_to_texture`, `bake_lightmap`; and `AmbientLight()` in `shader.py` |
| VMT-ish fields in `Definition` | `src/vbmod_materials.py:FIELD_MAP`, `src/vmt.py` | the field → combo/register mapping, and the real VMT text the port ships |
| the vertex VBO | `src/vbmod_skin.py:tangents()` | per-vertex tangents + handedness built from positions and UVs |
| CPU morph in `m_positions/m_normals` | `src/web_template.html:applyVbFlex()` | the delta accumulation **including normal deltas and renormalisation** |
| `proof/` captures + CTest | `src/shader.py` CPU twin; `web_export.py --check` | the verification rig: CPU-vs-GPU pixel diff, and "compile every permutation" |

---

## 3. The tasks, in order, with acceptance criteria

### T1 — give the vertex program a tangent frame
VBMOD stores no normals in its 44-byte vertex record (they are in the VBFLX1
trailer) and no tangents at all. FacePoser already reads `m_normals`, so normals
are solved; the tangent frame is not. Two options:

* **widen `rb::SceneVertex`** with `tx,ty,tz,sign` and fill them once at load
  time from `src/vbmod_skin.py:tangents()` (accumulate the per-triangle UV
  derivative, Gram-Schmidt against the normal, take the handedness sign from the
  bitangent); or
* build them in the vertex program from `dFdx/dFdy` — do not: it is per-fragment
  work for a per-vertex quantity and it breaks at UV seams.

Acceptance: the tangent frame is orthonormal (|dot(T,N)| < 1e-3) and the normal
map's round trip `world = T*ts.x + B*ts.y + N*ts.z` reproduces the geometric
normal when the map is flat lavender.

### T2 — replace `kMeshVertex`
Take `VERT_SRC` from `src/shader.py`. It expects `a_pos, a_normal, a_uv,
a_tangent, a_bitangent, a_flex` and `u_model/u_view/u_proj/u_normalMat/
u_cFlexScale`. FacePoser has one `u_mvp` and a per-mesh `a_color`; keep
`a_color` and multiply it into `g_DiffuseModulation` (that *is* what Source's
`cDiffuseModulation` is for), and pass `u_mvp` **plus** a model matrix (or keep
`u_mvp` for the transform and add a `u_model` only for the world-space outputs
the lighting needs — `v_worldPos` and the eye vector).

Acceptance: with `SKIN` off and the ambient cube zeroed, the tool's picture is
pixel-identical to today's (the transform must not change).

### T3 — replace `kMeshFragment`, and pick combos from the material
Port `FRAG_SRC` and define the combos the way the tool's materials ask for them:

| `Definition` | combos |
|---|---|
| `shader == Lit` | none (ambient + one N·L per light) |
| `shader == HalfLambert` | `HALFLAMBERT=1` — identical to Source's `$halflambert 1`, so nothing is lost by retiring the built-in |
| `specularStrength > 0 && normalPath` | `SKIN` (`$phong` path: fresnel ranges, exponent map, phong mask from the normal map's alpha) |
| `reflectivity > 0` | `CUBEMAP` (+ `NORMALMAPALPHAENVMAPMASK` if the mask lives in the alpha) |
| any lightwarp in the material (new field, or `specularPath` if you re-purpose it) | `LIGHTWARPTEXTURE` |
| `shader == CustomFragment` | keep the tool's hook, but compile it *on top of* the ported program and fall back to the ported program when it fails — the same policy the package documents ("a compile failure falls back to lit shading so the model remains visible") |

Registers to fill, exactly as `skin_dx9_helper.cpp` packs them:
`g_EyePos_SpecExponent` (xyz = camera, w = `$phongexponent` or −1),
`g_FresnelRanges_SpecBoost` (`((mid−min)*2, mid, (max−mid)*2, specularStrength)`),
`g_SpecularRimParams`, `g_DiffuseModulation`, `g_ShaderControls`,
`g_LightPos[4]`, `g_LightColor[4]`, `g_EnvmapTint_ShadowTweaks`.

Textures: `albedoPath → $basetexture`, `normalPath → $bumpmap` (**its alpha is
the phong mask** — `fSpecMask` reads bump alpha, this is the single most
overlooked link in the whole material system), `specularPath → $phongexponenttexture`
(what `1 + 149 * r` turns into the exponent).

Acceptance: `specularStrength = 0` and no normal map reproduce the old `lit`
look; with a normal map and `specularStrength 6` the highlight tracks the
camera the way the port's `live/index.html` shows.

### T4 — settle the UV convention once, in writing
The tool flips V when it fills the vertex buffer (`1.0f - texcoord[1]`) because
its image loader hands back top-down rows. The port's textures were authored
*without* a flip (`png_data_uri()` in `web_export.py` documents this). Pick one
and write it in the README:

* either drop the flip in `FacePoserApp` and flip images on upload
  (`stbi_set_flip_vertically_on_load`-style) — then the port's UVs and atlases
  work as-is;
* or keep the flip and remember that **every** port-side texture (including a
  generated skin atlas) has to be baked with it.

Acceptance: a deliberately asymmetric test texture (an "L" in one corner) lands
in the same place in FacePoser and in `live/index.html`.

### T5 — the lights: from two hard-coded directions to the ported registers
Replace `key`/`fill`/`hemi` with:
`g_LightPos[4]` / `g_LightColor[4]` (Source packs light `.w` as 1 directional /
0.01 spot / 0 point) and the ambient cube. The port's dynamic-light maths is
`common_vs_fxc.h:VertexAttenInternal` (distance `1/dot(atten.xyz, dst(d², rsqrt(d²)))`,
spot `pow(max(0.0001, (cosTheta − spotParams.z) * spotParams.w), spotParams.x)`);
if you keep lighting in the fragment shader instead, keep the same falloff
functions and say so.

Acceptance: two lights of the same colour and position as the old hard-coded
pair reproduce today's picture within a couple of code values, and the numbers
are printable from a debug panel.

### T6 — the ambient cube, and where its data comes from
This is "the lightcache" in practice:

```glsl
uniform vec3 u_ambientCube[6];      // +x -x +y -y +z -z
// common_vertexlitgeneric_dx9.h:AmbientLight()
vec3 AmbientLight(vec3 n) {
    vec3 n2 = n * n;
    return n2.x * u_ambientCube[n.x >= 0.0 ? 0 : 1]
         + n2.y * u_ambientCube[n.y >= 0.0 ? 2 : 3]
         + n2.z * u_ambientCube[n.z >= 0.0 ? 4 : 5];
}
```

The selector is `2*axis + (component < 0)` and the lobe order is **+x −x +y −y
+z −z**; get either wrong and the model shades inside-out.

Data sources, best-first for a tool with no `.bsp`:

1. **bake a field over the tool's stage** exactly as `lightcache.bake_grid(scene,
   res=(26,18,28), bounces=3)` does — six lobes per probe, cell 0.32×0.25×0.27
   over the room bounds (13,104 probes in this port), then
   `sample_cube(grid, pos, radius_voxels=1)`: round the position to a voxel,
   clamp it, average the (2r+1)³ block;
2. **load a field** from a file next to the model (`<model>.probes`, or a JSON
   export of the same array) so a user with a real map can bring its lightcache;
3. per-pixel option: the same array as a 3D texture, one slice per lobe,
   `(nx, ny, nz*6)`, RGB16F, so GL_LINEAR interpolates between probes and never
   between lobes (`lightcache.grid_to_texture()` documents the exact texel
   centres).

**Resolve the cube per entity, at the entity's origin** — that is the engine's
own model (per-object, `LightcacheGetStatic`). In this port the read-out prints
that number next to the same lookup at the model's *eyes*, and the difference is
large (in this scene: `0.578 0.466 0.376` at the origin vs `0.301 0.226 0.150`
at the eyes) — which is the whole reason a tall model can look flat. Keep both
read-outs; they are the teaching content, not decoration.

Acceptance: the tool can print, for the current model position, the six-lobe cube
it handed the shader, the `AmbientLight(+y)` reconstruction, and the same values
for the per-pixel path; and moving the model changes one continuously and the
other in voxel-sized steps.

### T7 — port the *testing* rig, not just the shading
The user's ask is explicitly "the lightcache testing and other stuff". These are
the four things in this port that make the lighting checkable, and all four are
worth having in a C++ tool:

1. **the probe cloud**: draw the probes as points, coloured by irradiance, so the
   field is visible rather than described (`web_template.html`, the point-sprite
   program over `probeCloud.xyz16`). Add a slice filter and a gain slider —
   a 3D array on a 2D screen is unreadable otherwise.
2. **the read-out panel**: grid dims, cell size, cube max, the cube at the
   entity origin, the resolved registers, the material's combos. The tool already
   has a Materials panel and a log; put them there.
3. **term isolates**: one dropdown that recompiles the fragment program with a
   single line replacing the output (`src/terms.py` is the list: world-space
   normal, N·L, `$basetexture`, ambient cube, half-lambert term, lightwarped
   diffuse, exponent/150, phong mask, fresnel ranges, specular ×5, envmap,
   final). Isolating a term is how anyone actually finds out why a highlight is
   in the wrong place; it costs one string substitution because the port keeps
   the fragment source as text.
4. **the parity harness**: render the same frame twice — GPU and the CPU twin
   (`shader.py`'s `AmbientLight`, `Fresnel`, `SpecularAndRimTerms`) — and diff.
   The port's numbers you should be able to reproduce: CPU-vs-GPU p50 0.00043,
   p99 0.00097, max 0.0021 over 284,877 model pixels; and browser-vs-offline
   per-preset means 0.112 (ep1_phong), 0.178 (lightwarp), 0.112 (rim), 0.111
   (2004), 0.111 (phong_off), p99 = 1 code value. Add the CPU twin as a CTest in
   `tests/` and an Xvfb capture diff beside `proof/`.

Acceptance: a single command prints both the compile matrix (the port's
equivalent is "64 programs compiled, 0 failed") and the parity table.

### T8 — the eyes, as their own program
Retire `ChiselEye`'s fragment and use the ported `eye_refract_ps2x`:
reflection `texCUBE(envmap, reflect(V,N)) * glossiness`, glints
`pow(saturate(dot(R,L)), 128)`, pupil dilation
`lerp(1, saturate(length(uv-0.5)/0.2), saturate(dilation)*2.5 - 1.25)`, the iris
cone-of-darkness, cornea highlight, and ambient
`saturate(dot(N_iris, -V)) * g_flAverageAmbient * mask * 0.5`.
`g_flAverageAmbient` is one scalar per material and comes from the same probe
lookup as T6, at the eyeball's own position.

Two geometry notes: the format's eyeball meshes are 19-vertex **flat lens
patches** (planar front-projected UVs so a procedural iris sits in the centre),
while EyeRefract wants a sphere. The port's rule is in
`src/vbmod_skin.py:viewer_section()`: centre = patch centroid − normal × radius,
`radius = 0.50 × max(span_u, span_z)`, the cornea bulging 12 % of the radius out
of the socket. If the tool keeps the patch instead, say in the docs that the eye
is being drawn by a refraction shader on a flat surface.

Acceptance: with the environment cube zeroed the eye is the iris + pupil the
recipe describes; with it non-zero the reflection moves as the camera orbits.

### T9 — flex: keep the CPU path, and finish it
FacePoser already does the format's own thing (CPU deltas → `glBufferSubData`).
Two gaps against a 1:1 port:

* **normal deltas**: `dNorm3` must be accumulated onto the base normals and
  renormalised, or the lighting does not follow a blink;
* the GPU variant, when you want it: one extra attribute stream and
  `vPosition.xyz += vPosFlex.xyz * cFlexScale.x` (`common_vs_fxc.h:ApplyMorph`),
  where `cFlexScale.x` is a *binary on/off switch for the stream*, not a weight —
  the weights are what the animation system already folded into the deltas.

Acceptance: a blink changes the specular on the eyelid without changing the
silhouette, i.e. the normals moved.

### T10 — retire the placeholders *without breaking file compatibility*
Do not delete the enum values: existing `.vbm`/`.cmt` files say `half_lambert`
and `chisel_eye`. Re-point them:

    Lit              -> ported skin program, no combos
    HalfLambert      -> ported skin program, HALFLAMBERT=1
    ChiselEye        -> ported eye_refract program
    CustomFragment   -> the tool's hook, compiled over the ported program with
                        the documented lit fallback

Then the material layer, the search order, the trace panel and the fallback
behaviour all stay exactly as documented in `MATERIALS.md`, and the shading
stops being a placeholder. Note the honesty item in the tool's docs: the three
`.vbm` files that ship with the sample (`xana.vbm` expects an `xana.png` that
does not exist; `eyeball_*.vbm` are procedural previews) are *definitions*, not
art. Anything drawn in FacePoser from them is a generated stand-in.

---

## 4. Ordering, and what to do first

1. **T4 (UV convention)** — everything else is confusing until this is decided.
2. **T1/T2** — get the ported vertex program in with the *old* fragment still
   producing the picture; that isolates transform bugs from shading bugs.
3. **T3** — the ported fragment program, combos from the material.
4. **T5/T6** — the lights and the ambient cube; this is where the picture jumps.
5. **T7** — the test rig. Build it *before* T8/T9 so you can see what you break.
6. **T8/T9** — eyes, then flex normals.
7. **T10** — re-point the material kinds and update `MATERIALS.md`, the README
   and the status file.

Do the port *in this order* and at every step keep the previous step's picture as
the reference image; the port's own history is that every wrong turn was caught
by a diff, not by reading the shader again.

---

## 5. References

**In this zip** (root `hl2shader-1to1/`):

* `hl2shader/` — the port: `src/shader.py` (ported pixel shader + CPU twin),
  `src/render.py` (offline renderer, world shaders, post chain),
  `src/lightcache.py` (probe-grid baker, `sample_cube`, lightmaps,
  `grid_to_texture`), `src/terms.py` (the term isolates), `src/combos.py`
  (combo resolution), `src/web_template.html` (the live viewer: model switch,
  material panel, flex sliders, probe cloud, ambient-source switch),
  `src/vbmod.py` / `vbmod_skin.py` / `vbmod_materials.py` (the VBMOD4 path),
  `src/web_export.py` (bakes it all into one HTML), `live/index.html` (the
  result), `out/` (screenshots and renders), `material_set/` (the real VMTs and
  VTF-wrapped maps the port ships).
* `hl2shader/vbmod_ref/` — the parts of the FacePoser package this port was
  written against: `docs/` (VBMOD_FACEFLEX, MATERIALS, MDL_TO_VBMOD_PORTING_GUIDE,
  PACKAGE_CONTENTS), `materials/*.vbm`, `samples/leanna.vbmod` +
  `leanna_conversion_report.json`.
* `notes/PORT_TO_OPENGL_AGENT_TASK.txt` — the companion guide (Source shaders →
  this port → the VBMOD format). Read §3 (byte layout), §4 (ambient cube),
  §5 (flex) and §9 (the traps) before you start writing C++.
* `notes/MAP_LIGHTING_AND_MATERIALS.md` — the long answer to "are the walls
  really lightmapped, is the model really VertexLitGeneric, and how do the two
  layers compose", with the engine code quoted.
* `notes/FACEPOSER_1TO1_HANDOVER.md` — this document (`.txt` is a plain-text
  copy).
* `engine-sources/` — the HLSL the port was written against
  (`common_vs_fxc.h`, `common_vertexlitgeneric_dx9.h`, `skin_ps20b.fxc`,
  `eye_refract_ps2x.fxc`, `skin_dx9_helper.cpp`).
* `analysis-html/` — the VMT breakdown and the per-term shader maths as pages.
* `reference-shots/` — renders from the offline path and the viewer.

**In the FacePoser package itself:** `MATERIALS.md` (material layer and search
order), `VBMOD_FACEFLEX.md` and `docs/MDL_TO_VBMOD_PORTING_GUIDE.md` (the
format), `PACKAGE_CONTENTS.md` (what is where), `STATUS_AND_COMPLETED_WORK.md`
(the tool's own limits), `src/vb/vb_model.cpp` (the authority on the bytes),
`src/material/MaterialSystem.*` (the authority on materials),
`src/faceposer/FacePoserApp.cpp` (the placeholder shaders you are replacing).

**Where the numbers in this document come from:** every value quoted above was
produced by this port on the user's own `leanna.vbmod` (683 KB, 103 joints, 3070
vertices, 5168 triangles, 45 flex targets, 8585 sparse deltas) in the scene baked
by `lightcache.bake_grid` (26×18×28 = 13,104 probes, cell 0.32×0.25×0.27, cube
max 1.656). If you reproduce them, you have ported the same thing; if you do not,
the diff will tell you which term is wrong.

*For learning purposes only. Nothing here is shippable art, and no Valve asset is
redistributed with this package.*
